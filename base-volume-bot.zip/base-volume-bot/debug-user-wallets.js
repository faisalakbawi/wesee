/**
 * DEBUG USER WALLETS
 * Check what wallets are actually stored for a user
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function debugUserWallets() {
  console.log('🔍 ========== DEBUG USER WALLETS ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    // Your Telegram user ID (replace with your actual ID)
    const yourUserId = 12345; // Replace this with your actual Telegram user ID
    
    console.log(`🔍 Checking wallets for user: ${yourUserId}`);
    
    // Get all user wallets
    const allWallets = await walletManager.getUserWallets(yourUserId);
    console.log('\n📋 ALL USER WALLETS:');
    console.log(JSON.stringify(allWallets, null, 2));
    
    // Check Base chain specifically
    const baseWallets = await walletManager.getChainWallets(yourUserId, 'base');
    console.log('\n🔵 BASE CHAIN WALLETS:');
    
    if (Object.keys(baseWallets).length === 0) {
      console.log('❌ No wallets found for Base chain');
      console.log('💡 You need to generate wallets first using the bot');
    } else {
      for (let i = 1; i <= 5; i++) {
        const walletSlot = `W${i}`;
        const wallet = baseWallets[walletSlot];
        
        if (wallet) {
          console.log(`\n✅ ${walletSlot}:`);
          console.log(`   Address: ${wallet.address}`);
          console.log(`   Created: ${wallet.createdAt}`);
          console.log(`   Imported: ${wallet.isImported ? 'Yes' : 'No'}`);
          
          // Check balance
          try {
            const balance = await walletManager.getWalletBalance(wallet.address, 'base');
            console.log(`   Balance: ${balance} ETH`);
            
            // Check if this matches your expected address
            if (wallet.address.toLowerCase() === '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'.toLowerCase()) {
              console.log(`   🎯 THIS IS YOUR EXPECTED WALLET!`);
            }
          } catch (error) {
            console.log(`   Balance: Error - ${error.message}`);
          }
        } else {
          console.log(`\n❌ ${walletSlot}: Empty`);
        }
      }
    }
    
    // Check if your expected address exists in any slot
    console.log('\n🔍 SEARCHING FOR YOUR EXPECTED ADDRESS...');
    const expectedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    let foundInSlot = null;
    
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = baseWallets[walletSlot];
      
      if (wallet && wallet.address.toLowerCase() === expectedAddress.toLowerCase()) {
        foundInSlot = walletSlot;
        break;
      }
    }
    
    if (foundInSlot) {
      console.log(`✅ Found your address in slot: ${foundInSlot}`);
    } else {
      console.log(`❌ Your expected address ${expectedAddress} is NOT in any wallet slot`);
      console.log(`💡 This explains why W5 failed - it's probably a different address or empty`);
    }
    
    // Show recommendations
    console.log('\n💡 RECOMMENDATIONS:');
    if (foundInSlot) {
      console.log(`✅ Use wallet ${foundInSlot} instead of W5`);
    } else {
      console.log(`❌ You need to import your private key into one of the wallet slots`);
      console.log(`📝 Use the bot's wallet management feature to import your private key`);
    }

  } catch (error) {
    console.error('❌ ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugUserWallets().then(() => {
  console.log('\n🎉 Debug completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});