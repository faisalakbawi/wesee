/**
 * CHECK TONY TOKEN CONTRACT
 * Analyze the TONY token to see if it has transfer restrictions
 */

const { ethers } = require('ethers');

async function checkTonyToken() {
  console.log(`🪙 ========== TONY TOKEN ANALYSIS ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  console.log(`📍 Token: ${TONY}`);
  
  // Basic ERC20 ABI
  const tokenABI = [
    "function name() external view returns (string)",
    "function symbol() external view returns (string)",
    "function decimals() external view returns (uint8)",
    "function totalSupply() external view returns (uint256)",
    "function balanceOf(address) external view returns (uint256)",
    "function transfer(address to, uint256 amount) external returns (bool)",
    "function allowance(address owner, address spender) external view returns (uint256)",
    "function approve(address spender, uint256 amount) external returns (bool)",
    
    // Common restriction functions
    "function paused() external view returns (bool)",
    "function blacklisted(address) external view returns (bool)",
    "function isBlacklisted(address) external view returns (bool)",
    "function tradingEnabled() external view returns (bool)",
    "function maxTransactionAmount() external view returns (uint256)",
    "function maxWallet() external view returns (uint256)",
    "function owner() external view returns (address)",
    
    // Anti-bot functions
    "function antiBotEnabled() external view returns (bool)",
    "function isBot(address) external view returns (bool)",
    "function launchTime() external view returns (uint256)",
    "function cooldownEnabled() external view returns (bool)"
  ];
  
  const token = new ethers.Contract(TONY, tokenABI, provider);
  
  try {
    // Basic token info
    console.log(`\n📋 Basic Token Info:`);
    const name = await token.name();
    const symbol = await token.symbol();
    const decimals = await token.decimals();
    const totalSupply = await token.totalSupply();
    
    console.log(`  📛 Name: ${name}`);
    console.log(`  🏷️ Symbol: ${symbol}`);
    console.log(`  🔢 Decimals: ${decimals}`);
    console.log(`  📊 Total Supply: ${ethers.utils.formatUnits(totalSupply, decimals)}`);
    
    // Check for restrictions
    console.log(`\n🔍 Checking for restrictions...`);
    
    const restrictionChecks = [
      { name: 'paused', func: 'paused' },
      { name: 'tradingEnabled', func: 'tradingEnabled' },
      { name: 'antiBotEnabled', func: 'antiBotEnabled' },
      { name: 'cooldownEnabled', func: 'cooldownEnabled' },
      { name: 'maxTransactionAmount', func: 'maxTransactionAmount' },
      { name: 'maxWallet', func: 'maxWallet' },
      { name: 'owner', func: 'owner' },
      { name: 'launchTime', func: 'launchTime' }
    ];
    
    for (const check of restrictionChecks) {
      try {
        const result = await token[check.func]();
        console.log(`  ✅ ${check.name}: ${result.toString()}`);
        
        // Analyze specific restrictions
        if (check.name === 'paused' && result === true) {
          console.log(`    ⚠️ TOKEN IS PAUSED! This explains the failures.`);
        }
        if (check.name === 'tradingEnabled' && result === false) {
          console.log(`    ⚠️ TRADING IS DISABLED! This explains the failures.`);
        }
        if (check.name === 'antiBotEnabled' && result === true) {
          console.log(`    ⚠️ ANTI-BOT IS ENABLED! May block automated trading.`);
        }
        if (check.name === 'maxTransactionAmount') {
          const maxTxETH = ethers.utils.formatEther(result);
          console.log(`    📊 Max transaction: ${maxTxETH} ETH equivalent`);
          if (result.lt(ethers.utils.parseEther('0.001'))) {
            console.log(`    ⚠️ MAX TRANSACTION TOO LOW! 0.001 ETH exceeds limit.`);
          }
        }
        
      } catch (error) {
        console.log(`  ❌ ${check.name}: Function not found or reverted`);
      }
    }
    
    // Check specific address restrictions
    console.log(`\n🔍 Checking address restrictions...`);
    const testAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    
    const addressChecks = [
      { name: 'blacklisted', func: 'blacklisted' },
      { name: 'isBlacklisted', func: 'isBlacklisted' },
      { name: 'isBot', func: 'isBot' }
    ];
    
    for (const check of addressChecks) {
      try {
        const result = await token[check.func](testAddress);
        console.log(`  ${result ? '❌' : '✅'} ${check.name}(${testAddress}): ${result}`);
        
        if (result === true) {
          console.log(`    ⚠️ ADDRESS IS RESTRICTED! This explains the failures.`);
        }
      } catch (error) {
        console.log(`  ❌ ${check.name}: Function not found`);
      }
    }
    
    // Check token balance in pool
    console.log(`\n🏊 Checking pool balances...`);
    const poolAddress = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    const poolBalance = await token.balanceOf(poolAddress);
    console.log(`  💧 TONY in pool: ${ethers.utils.formatUnits(poolBalance, decimals)}`);
    
    if (poolBalance.eq(0)) {
      console.log(`    ❌ POOL HAS NO TONY TOKENS! Pool is empty.`);
    }
    
    return {
      name,
      symbol,
      decimals,
      totalSupply: totalSupply.toString(),
      poolBalance: poolBalance.toString()
    };
    
  } catch (error) {
    console.log(`❌ Token analysis failed: ${error.message}`);
    return { error: error.message };
  }
}

// Also check if we can simulate a simple transfer
async function simulateTransfer() {
  console.log(`\n🔄 ========== SIMULATING TRANSFER ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  const tokenABI = [
    "function transfer(address to, uint256 amount) external returns (bool)"
  ];
  
  const token = new ethers.Contract(TONY, tokenABI, provider);
  
  try {
    // Try to simulate a transfer from pool to test address
    const poolAddress = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    const testAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    const amount = ethers.utils.parseUnits('1', 18); // 1 TONY
    
    console.log(`🧪 Simulating transfer:`);
    console.log(`  📤 From: ${poolAddress} (pool)`);
    console.log(`  📥 To: ${testAddress} (test wallet)`);
    console.log(`  💰 Amount: 1 TONY`);
    
    // This will fail if there are transfer restrictions
    const gasEstimate = await token.estimateGas.transfer(testAddress, amount, {
      from: poolAddress
    });
    
    console.log(`  ✅ Transfer simulation successful! Gas: ${gasEstimate.toString()}`);
    console.log(`  🎉 Token transfers are allowed`);
    
    return { success: true, gas: gasEstimate.toString() };
    
  } catch (error) {
    console.log(`  ❌ Transfer simulation failed: ${error.message}`);
    
    if (error.message.includes('paused')) {
      console.log(`  🔍 Analysis: Token is paused`);
    } else if (error.message.includes('blacklist')) {
      console.log(`  🔍 Analysis: Address is blacklisted`);
    } else if (error.message.includes('trading')) {
      console.log(`  🔍 Analysis: Trading is disabled`);
    } else if (error.message.includes('amount')) {
      console.log(`  🔍 Analysis: Amount exceeds limits`);
    } else {
      console.log(`  🔍 Analysis: Unknown transfer restriction`);
    }
    
    return { success: false, error: error.message };
  }
}

// Run all checks
async function runTokenAnalysis() {
  console.log(`🧪 ========== COMPREHENSIVE TOKEN ANALYSIS ==========`);
  
  const tokenInfo = await checkTonyToken();
  const transferTest = await simulateTransfer();
  
  console.log(`\n📊 ========== FINAL DIAGNOSIS ==========`);
  
  if (transferTest.success) {
    console.log(`✅ TOKEN TRANSFERS WORK`);
    console.log(`🔍 The issue is NOT with the token contract`);
    console.log(`💡 Problem might be with router interaction or pool setup`);
  } else {
    console.log(`❌ TOKEN HAS TRANSFER RESTRICTIONS`);
    console.log(`🎯 This explains why all swap attempts fail`);
    console.log(`💡 RECOMMENDATION: Find a different token without restrictions`);
  }
  
  return { tokenInfo, transferTest };
}

runTokenAnalysis().catch(console.error);