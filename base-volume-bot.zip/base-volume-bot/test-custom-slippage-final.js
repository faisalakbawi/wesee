/**
 * FINAL CUSTOM SLIPPAGE TEST
 * Tests the complete custom slippage flow after fixes
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const DatabaseWalletManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.callbacks = [];
    this.deletedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 MOCK BOT SENT MESSAGE:`, text.substring(0, 100) + '...');
    return message;
  }

  async editMessageText(text, options = {}) {
    console.log(`✏️ MOCK BOT EDITED MESSAGE:`, text.substring(0, 100) + '...');
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ MOCK BOT ANSWERED CALLBACK:`, options.text || 'No text');
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ MOCK BOT DELETED MESSAGE: ${messageId}`);
    return true;
  }
}

async function testCustomSlippageFlow() {
  console.log('🧪 ========== TESTING CUSTOM SLIPPAGE FLOW ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const walletManager = new DatabaseWalletManager();
    const trading = new Trading();
    const userStates = new Map();

    // Add test user to auth
    const testUserId = 12345;
    auth.addUser(testUserId);

    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    console.log('✅ Components initialized');

    // Test 1: Custom slippage button click
    console.log('\n📍 TEST 1: Custom slippage button click');
    const customSlippageCallback = {
      id: 'callback_1',
      data: 'slippage_custom_session123',
      from: { id: testUserId },
      message: { message_id: 1001 }
    };

    await callbacks.handle(customSlippageCallback);
    console.log('✅ Custom slippage callback handled');

    // Check if user state was set
    const userState = userStates.get(testUserId);
    if (userState && userState.state === 'awaiting_custom_slippage') {
      console.log('✅ User state set correctly:', userState);
    } else {
      console.log('❌ User state not set correctly:', userState);
    }

    // Check if reply message was sent
    const replyMessages = mockBot.messages.filter(msg => 
      msg.text.includes('Custom Slippage') && msg.text.includes('Reply to this message')
    );
    if (replyMessages.length > 0) {
      console.log('✅ Reply prompt message sent');
    } else {
      console.log('❌ Reply prompt message not sent');
    }

    // Test 2: User replies with custom slippage
    console.log('\n📍 TEST 2: User replies with custom slippage');
    const replyMessage = {
      message_id: 1002,
      chat: { id: testUserId },
      text: '2.5',
      reply_to_message: {
        message_id: replyMessages[0]?.message_id || 1001
      }
    };

    await callbacks.handleCustomSlippageInput(replyMessage);
    console.log('✅ Custom slippage input handled');

    // Check if user state was cleared
    const clearedState = userStates.get(testUserId);
    if (!clearedState) {
      console.log('✅ User state cleared correctly');
    } else {
      console.log('❌ User state not cleared:', clearedState);
    }

    // Test 3: Invalid slippage input
    console.log('\n📍 TEST 3: Invalid slippage input');
    
    // Set state again for invalid test
    userStates.set(testUserId, {
      state: 'awaiting_custom_slippage',
      sessionId: 'session123',
      messageId: 1001,
      replyMessageId: 1001
    });

    const invalidReplyMessage = {
      message_id: 1003,
      chat: { id: testUserId },
      text: 'invalid',
      reply_to_message: { message_id: 1001 }
    };

    await callbacks.handleCustomSlippageInput(invalidReplyMessage);
    console.log('✅ Invalid slippage input handled');

    // Test 4: Out of range slippage
    console.log('\n📍 TEST 4: Out of range slippage');
    
    // Set state again for range test
    userStates.set(testUserId, {
      state: 'awaiting_custom_slippage',
      sessionId: 'session123',
      messageId: 1001,
      replyMessageId: 1001
    });

    const rangeReplyMessage = {
      message_id: 1004,
      chat: { id: testUserId },
      text: '100',
      reply_to_message: { message_id: 1001 }
    };

    await callbacks.handleCustomSlippageInput(rangeReplyMessage);
    console.log('✅ Out of range slippage input handled');

    // Test 5: Check callback routing doesn't conflict
    console.log('\n📍 TEST 5: Check callback routing');
    
    const generalSlippageCallback = {
      id: 'callback_2',
      data: 'slippage_session123',
      from: { id: testUserId },
      message: { message_id: 1005 }
    };

    try {
      await callbacks.handle(generalSlippageCallback);
      console.log('✅ General slippage callback handled without conflict');
    } catch (error) {
      console.log('⚠️ General slippage callback error (expected):', error.message);
    }

    // Summary
    console.log('\n📊 ========== TEST SUMMARY ==========');
    console.log(`📤 Messages sent: ${mockBot.messages.length}`);
    console.log(`✅ Callbacks answered: ${mockBot.callbacks.length}`);
    console.log(`🗑️ Messages deleted: ${mockBot.deletedMessages.length}`);

    // Check for duplicate callback answers
    const callbackAnswers = mockBot.callbacks;
    console.log('📋 Callback answers:', callbackAnswers.map(c => c.options.text || 'No text'));

    console.log('✅ ========== ALL TESTS COMPLETED ==========');

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('❌ TEST STACK:', error.stack);
  }
}

// Run the test
testCustomSlippageFlow().then(() => {
  console.log('🎯 Test completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});