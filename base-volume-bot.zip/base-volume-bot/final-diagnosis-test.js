/**
 * FINAL COMPREHENSIVE DIAGNOSIS
 * Complete analysis of the failed transaction and demonstration of the solution
 * 
 * Failed TX: 0x5dee64ae5a41226c408d5bda84305b61cb9510ca5c7b9a79fb41d2499c054676
 * https://basescan.org/tx/0x5dee64ae5a41226c408d5bda84305b61cb9510ca5c7b9a79fb41d2499c054676
 */

const { ethers } = require('ethers');

class ComprehensiveDiagnosis {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
    
    // Addresses from the failed transaction
    this.FAILED_TX = '0x5dee64ae5a41226c408d5bda84305b61cb9510ca5c7b9a79fb41d2499c054676';
    this.SNIPER_CONTRACT = '0xe111b0C3605aDc45CFb0CD75E5543F63CC3ec425';
    this.WALLET_ADDRESS = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    this.TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';
    this.WETH = '0x4200000000000000000000000000000000000006';
    this.TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    
    // Uniswap V3 addresses
    this.SWAP_ROUTER_02 = '0x2626664c2603336E57B271c5C0b26F421741e481';
    this.QUOTER_V2 = '0x3d4e44Eb1374240CE5F1B871ab261CD16335B76a';
  }

  /**
   * STEP 1: ANALYZE THE FAILED TRANSACTION
   */
  async analyzeFailedTransaction() {
    console.log(`🔍 ========== ANALYZING FAILED TRANSACTION ==========`);
    console.log(`📍 TX Hash: ${this.FAILED_TX}`);
    console.log(`🔗 Basescan: https://basescan.org/tx/${this.FAILED_TX}`);
    
    try {
      const tx = await this.provider.getTransaction(this.FAILED_TX);
      const receipt = await this.provider.getTransactionReceipt(this.FAILED_TX);
      
      console.log(`\n📊 Transaction Analysis:`);
      console.log(`  👤 From: ${tx.from}`);
      console.log(`  📍 To: ${tx.to} (Sniper Contract)`);
      console.log(`  💰 Value: ${ethers.utils.formatEther(tx.value)} ETH`);
      console.log(`  ⛽ Gas Limit: ${tx.gasLimit.toString()}`);
      console.log(`  ⛽ Gas Used: ${receipt.gasUsed.toString()} (${(receipt.gasUsed.toNumber() / tx.gasLimit.toNumber() * 100).toFixed(2)}%)`);
      console.log(`  📊 Status: ${receipt.status === 1 ? '✅ Success' : '❌ Failed'}`);
      
      // Decode the input data
      console.log(`\n📋 Input Data Analysis:`);
      const inputData = tx.data;
      console.log(`  🔧 Function Selector: ${inputData.slice(0, 10)} (execBuy)`);
      console.log(`  📊 Data Length: ${inputData.length} characters`);
      
      // Extract the parameters that were used
      const params = this.decodeExecBuyParams(inputData);
      console.log(`\n🔍 Decoded Parameters:`);
      console.log(`  💰 ETH Amount: ${ethers.utils.formatEther(params.ethAmount)} ETH`);
      console.log(`  🛡️ Min Out: ${ethers.utils.formatEther(params.minOut)} TONY`);
      console.log(`  🎯 Token: ${params.tokenAddress}`);
      
      // The critical insight
      console.log(`\n🎯 CRITICAL INSIGHT:`);
      console.log(`  ❌ The transaction used only ${(receipt.gasUsed.toNumber() / tx.gasLimit.toNumber() * 100).toFixed(2)}% of gas`);
      console.log(`  🔍 This indicates an EARLY REVERT in the sniper contract`);
      console.log(`  💡 The sniper contract rejected the call before doing any real work`);
      
      return {
        gasUsedPercent: (receipt.gasUsed.toNumber() / tx.gasLimit.toNumber() * 100),
        decodedParams: params,
        earlyRevert: true
      };
      
    } catch (error) {
      console.log(`❌ Transaction analysis failed: ${error.message}`);
      return { error: error.message };
    }
  }

  /**
   * DECODE EXECBUY PARAMETERS
   */
  decodeExecBuyParams(inputData) {
    try {
      // Remove function selector (first 4 bytes)
      const params = inputData.slice(10);
      
      // Each parameter is 32 bytes (64 hex characters)
      const chunks = [];
      for (let i = 0; i < params.length; i += 64) {
        chunks.push('0x' + params.slice(i, i + 64));
      }
      
      // Based on the execBuy function signature, extract key parameters
      const ethAmount = ethers.BigNumber.from(chunks[2]); // amountIn
      const minOut = ethers.BigNumber.from(chunks[3]);    // amountOutMin
      const tokenAddress = '0x' + chunks[9].slice(-40);   // token address
      
      return {
        ethAmount,
        minOut,
        tokenAddress
      };
    } catch (error) {
      console.log(`❌ Parameter decoding failed: ${error.message}`);
      return {};
    }
  }

  /**
   * STEP 2: CHECK SNIPER CONTRACT STATUS
   */
  async checkSniperContract() {
    console.log(`\n🔍 ========== SNIPER CONTRACT ANALYSIS ==========`);
    console.log(`📍 Contract: ${this.SNIPER_CONTRACT}`);
    
    try {
      // Check if contract exists
      const code = await this.provider.getCode(this.SNIPER_CONTRACT);
      console.log(`📋 Contract Code: ${code.length} bytes`);
      
      if (code === '0x') {
        console.log(`❌ CONTRACT DOES NOT EXIST!`);
        return { exists: false };
      }
      
      // Check contract balance
      const balance = await this.provider.getBalance(this.SNIPER_CONTRACT);
      console.log(`💰 Contract Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      // Try to call owner function
      try {
        const ownerCall = await this.provider.call({
          to: this.SNIPER_CONTRACT,
          data: '0x8da5cb5b' // owner() selector
        });
        const owner = '0x' + ownerCall.slice(-40);
        console.log(`👤 Owner: ${owner}`);
        
        // Check if our wallet is the owner
        const isOwner = owner.toLowerCase() === this.WALLET_ADDRESS.toLowerCase();
        console.log(`🔑 Is our wallet the owner? ${isOwner ? '✅ Yes' : '❌ No'}`);
        
        if (!isOwner) {
          console.log(`⚠️ ACCESS CONTROL ISSUE: Our wallet is not the owner!`);
          console.log(`💡 This explains why the sniper contract rejects our calls`);
        }
        
        return {
          exists: true,
          balance: balance.toString(),
          owner,
          hasAccess: isOwner
        };
        
      } catch (error) {
        console.log(`❌ Owner check failed: ${error.message}`);
        return { exists: true, accessControlUnknown: true };
      }
      
    } catch (error) {
      console.log(`❌ Contract check failed: ${error.message}`);
      return { error: error.message };
    }
  }

  /**
   * STEP 3: GET CORRECT PRICE FROM QUOTER V2
   */
  async getCorrectPrice() {
    console.log(`\n💰 ========== GETTING CORRECT PRICE ==========`);
    console.log(`🎯 Using QuoterV2 for accurate pricing`);
    
    const quoterABI = [
      {
        "inputs": [
          {"internalType": "address", "name": "tokenIn", "type": "address"},
          {"internalType": "address", "name": "tokenOut", "type": "address"},
          {"internalType": "uint24", "name": "fee", "type": "uint24"},
          {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
          {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
        ],
        "name": "quoteExactInputSingle",
        "outputs": [
          {"internalType": "uint256", "name": "amountOut", "type": "uint256"},
          {"internalType": "uint160", "name": "sqrtPriceX96After", "type": "uint160"},
          {"internalType": "uint32", "name": "initializedTicksCrossed", "type": "uint32"},
          {"internalType": "uint256", "name": "gasEstimate", "type": "uint256"}
        ],
        "stateMutability": "nonpayable",
        "type": "function"
      }
    ];
    
    try {
      const quoter = new ethers.Contract(this.QUOTER_V2, quoterABI, this.provider);
      
      const ethAmount = ethers.utils.parseEther('0.001');
      console.log(`📥 Input: ${ethers.utils.formatEther(ethAmount)} ETH`);
      
      const quote = await quoter.quoteExactInputSingle(
        this.WETH,      // tokenIn
        this.TONY_TOKEN, // tokenOut
        10000,          // fee (1%)
        ethAmount,      // amountIn
        0               // sqrtPriceLimitX96
      );
      
      console.log(`✅ QuoterV2 Results:`);
      console.log(`  📤 Expected Output: ${ethers.utils.formatEther(quote.amountOut)} TONY`);
      console.log(`  ⛽ Gas Estimate: ${quote.gasEstimate.toString()}`);
      
      // Compare with the failed transaction's minOut
      console.log(`\n🔍 Comparison with Failed Transaction:`);
      console.log(`  🤖 Failed TX minOut: ~27-34 TONY (our assumption)`);
      console.log(`  🏊 Actual Pool Output: ${ethers.utils.formatEther(quote.amountOut)} TONY`);
      
      const actualOutput = parseFloat(ethers.utils.formatEther(quote.amountOut));
      const assumedOutput = 34.11;
      const difference = Math.abs(actualOutput - assumedOutput);
      const percentDiff = (difference / assumedOutput) * 100;
      
      console.log(`  📊 Difference: ${difference.toFixed(2)} TONY (${percentDiff.toFixed(0)}%)`);
      
      if (percentDiff > 100) {
        console.log(`  🎯 SMOKING GUN: Our price assumption was ${percentDiff.toFixed(0)}% wrong!`);
        console.log(`  💡 This explains why the swap parameters were invalid`);
      }
      
      return {
        success: true,
        expectedOutput: quote.amountOut.toString(),
        gasEstimate: quote.gasEstimate.toString(),
        percentDifference: percentDiff
      };
      
    } catch (error) {
      console.log(`❌ QuoterV2 failed: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  /**
   * STEP 4: TEST DIRECT UNISWAP V3 WITH CORRECT PRICE
   */
  async testDirectUniswapV3(correctPrice) {
    console.log(`\n🌊 ========== TESTING DIRECT UNISWAP V3 ==========`);
    console.log(`🎯 Using correct price from QuoterV2`);
    
    const routerABI = [
      {
        "inputs": [
          {
            "components": [
              {"internalType": "address", "name": "tokenIn", "type": "address"},
              {"internalType": "address", "name": "tokenOut", "type": "address"},
              {"internalType": "uint24", "name": "fee", "type": "uint24"},
              {"internalType": "address", "name": "recipient", "type": "address"},
              {"internalType": "uint256", "name": "deadline", "type": "uint256"},
              {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
              {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
              {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
            ],
            "internalType": "struct ISwapRouter.ExactInputSingleParams",
            "name": "params",
            "type": "tuple"
          }
        ],
        "name": "exactInputSingle",
        "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
        "stateMutability": "payable",
        "type": "function"
      }
    ];
    
    try {
      const router = new ethers.Contract(this.SWAP_ROUTER_02, routerABI, this.provider);
      
      const ethAmount = ethers.utils.parseEther('0.001');
      const expectedOutput = ethers.BigNumber.from(correctPrice);
      const minOut = expectedOutput.mul(8000).div(10000); // 20% slippage
      
      console.log(`🔧 Swap Parameters:`);
      console.log(`  📥 Amount In: ${ethers.utils.formatEther(ethAmount)} ETH`);
      console.log(`  📤 Expected Out: ${ethers.utils.formatEther(expectedOutput)} TONY`);
      console.log(`  🛡️ Min Out (20% slippage): ${ethers.utils.formatEther(minOut)} TONY`);
      
      const swapParams = {
        tokenIn: this.WETH,
        tokenOut: this.TONY_TOKEN,
        fee: 10000, // 1%
        recipient: this.WALLET_ADDRESS,
        deadline: Math.floor(Date.now() / 1000) + 300,
        amountIn: ethAmount,
        amountOutMinimum: minOut,
        sqrtPriceLimitX96: 0
      };
      
      // Test gas estimation
      const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
        value: ethAmount,
        from: this.WALLET_ADDRESS
      });
      
      console.log(`✅ DIRECT UNISWAP V3 WORKS!`);
      console.log(`⛽ Gas Estimate: ${gasEstimate.toString()}`);
      console.log(`🎉 This proves the issue was with the sniper contract, not the swap itself`);
      
      return {
        success: true,
        gasEstimate: gasEstimate.toString(),
        workingParams: swapParams
      };
      
    } catch (error) {
      console.log(`❌ Direct Uniswap V3 failed: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  /**
   * STEP 5: GENERATE FINAL DIAGNOSIS AND SOLUTION
   */
  generateFinalDiagnosis(results) {
    console.log(`\n📊 ========== FINAL DIAGNOSIS ==========`);
    
    console.log(`🔍 ROOT CAUSE ANALYSIS:`);
    
    // Issue 1: Sniper Contract Access Control
    if (results.sniperAnalysis?.hasAccess === false) {
      console.log(`  1️⃣ ❌ SNIPER CONTRACT ACCESS CONTROL`);
      console.log(`     💡 The sniper contract is owned by someone else`);
      console.log(`     🎯 Our wallet cannot call execBuy() function`);
      console.log(`     ⚡ Solution: Use direct Uniswap V3 Router instead`);
    }
    
    // Issue 2: Wrong Price Calculation
    if (results.priceAnalysis?.percentDifference > 50) {
      console.log(`  2️⃣ ❌ MASSIVE PRICE CALCULATION ERROR`);
      console.log(`     💡 Our price assumption was ${results.priceAnalysis.percentDifference.toFixed(0)}% wrong`);
      console.log(`     🎯 We expected ~34 TONY but pool gives ~${parseFloat(ethers.utils.formatEther(results.priceAnalysis.expectedOutput)).toFixed(0)} TONY`);
      console.log(`     ⚡ Solution: Use QuoterV2 for accurate pricing`);
    }
    
    // Issue 3: Early Revert Pattern
    if (results.txAnalysis?.gasUsedPercent < 10) {
      console.log(`  3️⃣ ❌ EARLY REVERT PATTERN`);
      console.log(`     💡 Transaction used only ${results.txAnalysis.gasUsedPercent.toFixed(2)}% of gas`);
      console.log(`     🎯 Contract rejected the call immediately`);
      console.log(`     ⚡ Solution: Fix access control and parameters`);
    }
    
    console.log(`\n✅ WORKING SOLUTION:`);
    if (results.directUniswap?.success) {
      console.log(`  🌊 Direct Uniswap V3 Router approach WORKS!`);
      console.log(`  ⛽ Gas needed: ${results.directUniswap.gasEstimate}`);
      console.log(`  💰 Correct price: ${ethers.utils.formatEther(results.priceAnalysis.expectedOutput)} TONY for 0.001 ETH`);
      console.log(`  🎯 Use QuoterV2 for pricing + SwapRouter02 for execution`);
    }
    
    console.log(`\n🛠️ IMPLEMENTATION STEPS:`);
    console.log(`  1. Remove dependency on sniper contract`);
    console.log(`  2. Use QuoterV2 for accurate price quotes`);
    console.log(`  3. Use SwapRouter02 for direct swaps`);
    console.log(`  4. Implement proper slippage protection (20%+)`);
    console.log(`  5. Add fallback mechanisms for price calculation`);
    
    return {
      rootCauses: [
        'Sniper contract access control',
        'Wrong price calculation',
        'Early revert pattern'
      ],
      solution: 'Direct Uniswap V3 with QuoterV2 pricing',
      status: results.directUniswap?.success ? 'SOLVED' : 'NEEDS_MORE_WORK'
    };
  }

  /**
   * RUN COMPLETE DIAGNOSIS
   */
  async runCompleteDiagnosis() {
    console.log(`🧠 ========== COMPREHENSIVE DIAGNOSIS STARTING ==========`);
    console.log(`🕐 Started at: ${new Date().toISOString()}`);
    console.log(`🔗 Failed TX: https://basescan.org/tx/${this.FAILED_TX}`);
    
    const results = {};
    
    // Step 1: Analyze the failed transaction
    console.log(`\n1️⃣ ANALYZING FAILED TRANSACTION...`);
    results.txAnalysis = await this.analyzeFailedTransaction();
    
    // Step 2: Check sniper contract status
    console.log(`\n2️⃣ CHECKING SNIPER CONTRACT...`);
    results.sniperAnalysis = await this.checkSniperContract();
    
    // Step 3: Get correct price
    console.log(`\n3️⃣ GETTING CORRECT PRICE...`);
    results.priceAnalysis = await this.getCorrectPrice();
    
    // Step 4: Test direct Uniswap V3
    if (results.priceAnalysis?.success) {
      console.log(`\n4️⃣ TESTING DIRECT UNISWAP V3...`);
      results.directUniswap = await this.testDirectUniswapV3(results.priceAnalysis.expectedOutput);
    }
    
    // Step 5: Generate final diagnosis
    console.log(`\n5️⃣ GENERATING FINAL DIAGNOSIS...`);
    results.finalDiagnosis = this.generateFinalDiagnosis(results);
    
    console.log(`\n✅ DIAGNOSIS COMPLETE!`);
    console.log(`🕐 Finished at: ${new Date().toISOString()}`);
    
    return results;
  }
}

// Run the comprehensive diagnosis
if (require.main === module) {
  const diagnosis = new ComprehensiveDiagnosis();
  
  diagnosis.runCompleteDiagnosis()
    .then(results => {
      console.log(`\n📋 ========== SUMMARY ==========`);
      console.log(`Status: ${results.finalDiagnosis?.status || 'UNKNOWN'}`);
      console.log(`Root Causes: ${results.finalDiagnosis?.rootCauses?.join(', ') || 'Unknown'}`);
      console.log(`Solution: ${results.finalDiagnosis?.solution || 'Unknown'}`);
    })
    .catch(error => {
      console.error(`❌ Diagnosis failed:`, error);
    });
}

module.exports = ComprehensiveDiagnosis;