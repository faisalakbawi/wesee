/**
 * DEBUG IMPORTED WALLET
 * Check the specific wallet that was imported
 */

const Database = require('./database/database');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function debugImportedWallet() {
  console.log('🔍 ========== DEBUG IMPORTED WALLET ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    // Initialize wallet manager (this will also initialize the database)
    await walletManager.initialize();
    
    // The wallet address you mentioned importing
    const importedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    const chain = 'base';
    
    console.log(`🔍 Looking for imported wallet: ${importedAddress}`);
    console.log(`🔍 Chain: ${chain}`);
    
    // Step 1: Check database directly
    console.log(`\n📊 STEP 1: Checking database directly...`);
    
    const client = await walletManager.db.getClient();
    
    // Get all wallets for all users on Base chain
    const allWalletsQuery = `
      SELECT w.*, u.telegram_id, c.chain_id 
      FROM wallets w 
      JOIN users u ON w.user_id = u.id 
      JOIN chains c ON w.chain_id = c.id 
      WHERE c.chain_id = 'base'
      ORDER BY u.telegram_id, w.wallet_slot
    `;
    
    const allWallets = await client.query(allWalletsQuery);
    console.log(`📊 Found ${allWallets.rows.length} total wallets on Base chain:`);
    
    allWallets.rows.forEach(wallet => {
      const isImported = wallet.is_imported ? '📥 IMPORTED' : '🔧 GENERATED';
      const isActive = wallet.is_active ? '✅ ACTIVE' : '❌ INACTIVE';
      console.log(`   User ${wallet.telegram_id} - ${wallet.wallet_slot}: ${wallet.address} ${isImported} ${isActive}`);
    });
    
    // Step 2: Look for the specific imported address
    console.log(`\n🎯 STEP 2: Looking for specific address...`);
    
    const specificWalletQuery = `
      SELECT w.*, u.telegram_id, c.chain_id 
      FROM wallets w 
      JOIN users u ON w.user_id = u.id 
      JOIN chains c ON w.chain_id = c.id 
      WHERE LOWER(w.address) = LOWER($1)
    `;
    
    const specificWallet = await client.query(specificWalletQuery, [importedAddress]);
    
    if (specificWallet.rows.length > 0) {
      console.log(`✅ Found the imported wallet!`);
      const wallet = specificWallet.rows[0];
      console.log(`   User: ${wallet.telegram_id}`);
      console.log(`   Chain: ${wallet.chain_id}`);
      console.log(`   Slot: ${wallet.wallet_slot}`);
      console.log(`   Address: ${wallet.address}`);
      console.log(`   Imported: ${wallet.is_imported ? 'YES' : 'NO'}`);
      console.log(`   Active: ${wallet.is_active ? 'YES' : 'NO'}`);
      console.log(`   Created: ${wallet.created_at}`);
      console.log(`   Updated: ${wallet.updated_at}`);
      
      // Step 3: Check balance for this specific wallet
      console.log(`\n💰 STEP 3: Checking balance for imported wallet...`);
      const balance = await walletManager.getWalletBalance(importedAddress, chain);
      console.log(`💰 Balance: ${balance} ETH`);
      
      if (parseFloat(balance) > 0) {
        console.log(`🎉 GREAT! This wallet has funds: ${balance} ETH`);
      } else {
        console.log(`⚠️ This wallet shows 0 balance`);
        console.log(`💡 Possible reasons:`);
        console.log(`   1. Funds are in tokens, not ETH`);
        console.log(`   2. RPC endpoint issue`);
        console.log(`   3. Network connectivity issue`);
        console.log(`   4. Wallet is on different network`);
      }
      
      // Step 4: Test with the correct user ID
      console.log(`\n🧪 STEP 4: Testing with correct user ID...`);
      const userId = wallet.telegram_id;
      console.log(`👤 Using user ID: ${userId}`);
      
      const chainWallets = await walletManager.getChainWallets(userId, chain);
      console.log(`📊 Wallets for user ${userId} on ${chain}:`);
      
      Object.keys(chainWallets).forEach(slot => {
        const w = chainWallets[slot];
        const isTarget = w.address.toLowerCase() === importedAddress.toLowerCase();
        const marker = isTarget ? '🎯 TARGET' : '';
        console.log(`   ${slot}: ${w.address} ${marker}`);
        console.log(`     Balance: ${w.balance || '0'} ETH`);
        console.log(`     Imported: ${w.isImported ? 'YES' : 'NO'}`);
      });
      
    } else {
      console.log(`❌ Wallet ${importedAddress} not found in database`);
      console.log(`💡 This means the import might have failed or used different address`);
    }
    
    // Step 5: Check if there are any recent imports
    console.log(`\n📅 STEP 5: Checking recent imports...`);
    
    const recentImportsQuery = `
      SELECT w.*, u.telegram_id, c.chain_id 
      FROM wallets w 
      JOIN users u ON w.user_id = u.id 
      JOIN chains c ON w.chain_id = c.id 
      WHERE w.is_imported = true 
      AND w.updated_at > NOW() - INTERVAL '24 hours'
      ORDER BY w.updated_at DESC
    `;
    
    const recentImports = await client.query(recentImportsQuery);
    console.log(`📊 Recent imports (last 24 hours): ${recentImports.rows.length}`);
    
    recentImports.rows.forEach(wallet => {
      console.log(`   ${wallet.updated_at}: User ${wallet.telegram_id} imported ${wallet.address} to ${wallet.wallet_slot} on ${wallet.chain_id}`);
    });
    
    client.release();
    
    console.log(`\n${'='.repeat(60)}`);
    console.log(`🔍 IMPORT DEBUG SUMMARY`);
    console.log(`${'='.repeat(60)}`);
    
    if (specificWallet.rows.length > 0) {
      const wallet = specificWallet.rows[0];
      console.log(`✅ Imported wallet found in database`);
      console.log(`👤 User: ${wallet.telegram_id}`);
      console.log(`🔵 Chain: ${wallet.chain_id}`);
      console.log(`💼 Slot: ${wallet.wallet_slot}`);
      console.log(`📍 Address: ${wallet.address}`);
      
      console.log(`\n🎯 NEXT STEPS:`);
      console.log(`1. Use user ID ${wallet.telegram_id} for testing`);
      console.log(`2. Check wallet ${wallet.wallet_slot} on ${wallet.chain_id}`);
      console.log(`3. Verify balance shows correctly in UI`);
      
    } else {
      console.log(`❌ Imported wallet not found`);
      console.log(`💡 The import process may have failed`);
      console.log(`💡 Or the address was different than expected`);
    }

  } catch (error) {
    console.error('❌ DEBUG ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugImportedWallet().then(() => {
  console.log('\n🎉 Import debug completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});