/**
 * DEBUG TOKEN ANALYSIS
 * Test token analysis to find the exact error
 */

const ChainManager = require('./chains/chain-manager');
const TokenAnalyzer = require('./trading/token-analyzer');

async function debugTokenAnalysis() {
  console.log('🧪 ========== DEBUG TOKEN ANALYSIS ==========');
  
  try {
    // Initialize components
    console.log('🔧 Initializing components...');
    const chainManager = new ChainManager();
    const tokenAnalyzer = new TokenAnalyzer(chainManager);
    
    // Test with USDC on Base (known working token)
    const testAddress = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';
    console.log('🎯 Testing with USDC on Base:', testAddress);
    
    console.log('🔍 Step 1: Detecting blockchain...');
    const blockchainType = tokenAnalyzer.detectBlockchain(testAddress);
    console.log('✅ Blockchain type:', blockchainType);
    
    if (blockchainType === 'evm') {
      console.log('🔍 Step 2: Detecting EVM chain...');
      try {
        const chain = await tokenAnalyzer.detectEVMChain(testAddress);
        console.log('✅ Detected chain:', chain);
        
        console.log('🔍 Step 3: Analyzing EVM token...');
        const result = await tokenAnalyzer.analyzeEVMToken(testAddress, chain);
        console.log('✅ Analysis result:', result);
        
      } catch (chainError) {
        console.error('❌ Chain detection error:', chainError.message);
        console.error('❌ Stack:', chainError.stack);
      }
    }
    
    console.log('🔍 Step 4: Full analysis...');
    const fullAnalysis = await tokenAnalyzer.analyzeToken(testAddress);
    console.log('✅ Full analysis result:', fullAnalysis);
    
    if (fullAnalysis.success) {
      console.log('✅ SUCCESS: Token analysis working correctly');
      console.log('📊 Token data:', fullAnalysis.data);
    } else {
      console.log('❌ FAILED: Token analysis error');
      console.log('❌ Error:', fullAnalysis.error);
    }
    
  } catch (error) {
    console.error('❌ DEBUG ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugTokenAnalysis().then(() => {
  console.log('🎉 Debug completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});