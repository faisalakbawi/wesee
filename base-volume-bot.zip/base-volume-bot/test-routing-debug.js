/**
 * DEBUG ROUTING ISSUE
 * Test if the return statements are working
 */

async function testRouting() {
  const data = 'slippage_custom_session123';
  
  console.log('🧪 Testing routing logic...');
  console.log('🧪 Callback data:', data);
  
  if (data.startsWith('slippage_custom_')) {
    console.log('✅ MATCHED: slippage_custom_');
    console.log('🚀 Would call handleCustomSlippage');
    return; // This should prevent further processing
  }
  else if (data.startsWith('slippage_set_')) {
    console.log('✅ MATCHED: slippage_set_');
    console.log('🚀 Would call handleSlippageSet');
    return;
  }
  else if (data.startsWith('slippage_')) {
    console.log('✅ MATCHED: slippage_');
    console.log('🚀 Would call handleSlippageMenu');
    return;
  }
  
  console.log('❌ No match found');
}

testRouting().then(() => {
  console.log('✅ Test completed');
});