#!/usr/bin/env node

/**
 * ANALYZE LIQUIDITY PROVIDER
 * Check the liquidity provider address to understand the pool better
 */

require('dotenv').config();
const { ethers } = require('ethers');

async function analyzeLiquidityProvider() {
  console.log('🔍 ========== ANALYZING LIQUIDITY PROVIDER ==========');
  
  const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
  
  // Addresses
  const LP_ADDRESS = '0xb3bea12afc263318c16dc16dbfd5ab3a0261dabf';
  const TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
  
  console.log(`🏦 Liquidity Provider: ${LP_ADDRESS}`);
  console.log(`🏊 Pool: ${TONY_POOL}`);
  
  // ABIs
  const ERC20_ABI = [
    'function balanceOf(address account) external view returns (uint256)',
    'function decimals() external view returns (uint8)',
    'function name() external view returns (string)',
    'function symbol() external view returns (string)',
    'function totalSupply() external view returns (uint256)'
  ];
  
  const POOL_ABI = [
    'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
    'function liquidity() external view returns (uint128)',
    'function token0() external view returns (address)',
    'function token1() external view returns (address)',
    'function fee() external view returns (uint24)',
    'function positions(bytes32 key) external view returns (uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)'
  ];
  
  try {
    console.log('\n📊 STEP 1: LP Address Analysis');
    
    // Check if LP address is a contract or EOA
    const lpCode = await provider.getCode(LP_ADDRESS);
    const isContract = lpCode !== '0x';
    
    console.log(`  📍 Address: ${LP_ADDRESS}`);
    console.log(`  🔧 Is Contract: ${isContract}`);
    
    if (isContract) {
      console.log(`  💡 This is a smart contract (possibly a position manager)`);
    } else {
      console.log(`  👤 This is an EOA (externally owned account)`);
    }
    
    // Check ETH balance
    const ethBalance = await provider.getBalance(LP_ADDRESS);
    console.log(`  💰 ETH Balance: ${ethers.utils.formatEther(ethBalance)} ETH`);
    
    // Check token balances
    const tonyToken = new ethers.Contract(TONY_TOKEN, ERC20_ABI, provider);
    const wethToken = new ethers.Contract(WETH, ERC20_ABI, provider);
    
    const [tonyBalance, wethBalance] = await Promise.all([
      tonyToken.balanceOf(LP_ADDRESS),
      wethToken.balanceOf(LP_ADDRESS)
    ]);
    
    console.log(`  🪙 TONY Balance: ${ethers.utils.formatEther(tonyBalance)} TONY`);
    console.log(`  💧 WETH Balance: ${ethers.utils.formatEther(wethBalance)} WETH`);
    
    console.log('\n📊 STEP 2: Pool Position Analysis');
    
    const pool = new ethers.Contract(TONY_POOL, POOL_ABI, provider);
    
    // Get pool info
    const [slot0, totalLiquidity, token0, token1, fee] = await Promise.all([
      pool.slot0(),
      pool.liquidity(),
      pool.token0(),
      pool.token1(),
      pool.fee()
    ]);
    
    console.log(`  🏊 Pool State:`);
    console.log(`    Current Tick: ${slot0.tick}`);
    console.log(`    Total Liquidity: ${totalLiquidity.toString()}`);
    console.log(`    Unlocked: ${slot0.unlocked}`);
    console.log(`    SqrtPriceX96: ${slot0.sqrtPriceX96.toString()}`);
    
    console.log('\n📊 STEP 3: Transaction History Analysis');
    
    // Get recent transactions for this LP
    console.log(`  🔍 Checking recent transactions for LP...`);
    
    try {
      // Get the latest block
      const latestBlock = await provider.getBlockNumber();
      console.log(`  📊 Latest block: ${latestBlock}`);
      
      // Check last 1000 blocks for transactions involving this LP
      const fromBlock = Math.max(0, latestBlock - 1000);
      
      console.log(`  🔍 Searching blocks ${fromBlock} to ${latestBlock}...`);
      
      // This is a simplified search - in production you'd use event logs
      console.log(`  💡 To get full transaction history, we'd need to:`);
      console.log(`    1. Query Uniswap V3 position manager events`);
      console.log(`    2. Check mint/burn/collect events`);
      console.log(`    3. Analyze position NFT if applicable`);
      
    } catch (error) {
      console.log(`  ⚠️ Transaction history check failed: ${error.message}`);
    }
    
    console.log('\n📊 STEP 4: Pool Liquidity Distribution');
    
    // Check current pool token balances
    const [poolTonyBalance, poolWethBalance] = await Promise.all([
      tonyToken.balanceOf(TONY_POOL),
      wethToken.balanceOf(TONY_POOL)
    ]);
    
    console.log(`  🏊 Current Pool Balances:`);
    console.log(`    TONY in pool: ${ethers.utils.formatEther(poolTonyBalance)} TONY`);
    console.log(`    WETH in pool: ${ethers.utils.formatEther(poolWethBalance)} WETH`);
    
    // Calculate if pool is balanced
    const poolHasBothTokens = poolTonyBalance.gt(0) && poolWethBalance.gt(0);
    console.log(`    ✅ Pool has both tokens: ${poolHasBothTokens}`);
    
    if (!poolHasBothTokens) {
      console.log(`    ❌ ISSUE: Pool is imbalanced!`);
      if (poolTonyBalance.gt(0) && poolWethBalance.eq(0)) {
        console.log(`    💡 Pool only has TONY tokens (no WETH)`);
      } else if (poolWethBalance.gt(0) && poolTonyBalance.eq(0)) {
        console.log(`    💡 Pool only has WETH tokens (no TONY)`);
      } else {
        console.log(`    💡 Pool has no tokens at all`);
      }
    }
    
    console.log('\n📊 STEP 5: Alternative Solutions');
    
    if (!poolHasBothTokens) {
      console.log(`  🔧 POTENTIAL SOLUTIONS:`);
      console.log(`    1. Wait for LP to add more liquidity`);
      console.log(`    2. Contact LP to rebalance pool`);
      console.log(`    3. Look for alternative TONY pools`);
      console.log(`    4. Use a different DEX (SushiSwap, PancakeSwap, etc.)`);
      console.log(`    5. Create arbitrage opportunity by adding liquidity`);
    }
    
    console.log('\n📊 STEP 6: LP Behavior Analysis');
    
    // Check if LP has been active recently
    const lpNonce = await provider.getTransactionCount(LP_ADDRESS);
    console.log(`  📊 LP Transaction Count: ${lpNonce}`);
    
    if (lpNonce > 0) {
      console.log(`  ✅ LP has made transactions (active account)`);
    } else {
      console.log(`  ⚠️ LP has never made transactions (inactive or contract)`);
    }
    
    console.log('\n✅ LIQUIDITY PROVIDER ANALYSIS COMPLETE');
    
    // Summary and recommendations
    console.log('\n🎯 SUMMARY:');
    if (poolHasBothTokens) {
      console.log(`✅ Pool has balanced liquidity - trading should work`);
    } else {
      console.log(`❌ Pool is imbalanced - trading will fail`);
      console.log(`💡 The LP needs to add the missing token type`);
    }
    
    console.log('\n💡 NEXT STEPS:');
    console.log(`1. Monitor this LP address for new liquidity additions`);
    console.log(`2. Check other DEXs for TONY trading pairs`);
    console.log(`3. Look for TONY on centralized exchanges`);
    console.log(`4. Consider creating your own liquidity position`);
    
    return {
      lpAddress: LP_ADDRESS,
      isContract,
      ethBalance: ethers.utils.formatEther(ethBalance),
      tonyBalance: ethers.utils.formatEther(tonyBalance),
      wethBalance: ethers.utils.formatEther(wethBalance),
      poolBalanced: poolHasBothTokens,
      poolTonyBalance: ethers.utils.formatEther(poolTonyBalance),
      poolWethBalance: ethers.utils.formatEther(poolWethBalance)
    };
    
  } catch (error) {
    console.error('❌ LP analysis failed:', error.message);
    return { error: error.message };
  }
}

// Run analysis
analyzeLiquidityProvider();