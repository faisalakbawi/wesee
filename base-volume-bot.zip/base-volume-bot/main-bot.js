#!/usr/bin/env node

/**
 * LOOTER.AI CLONE - MAIN BOT
 * Professional structure, clean code, secure and working
 * Exactly like Looter.ai interface and functionality
 */

require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');

// Import all components
const Config = require('./config/config');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager'); // NEW: For real balance fetching
const WalletDBManager = require('./database/wallet-db-manager'); // NEW: Database-powered wallet manager
const Commands = require('./commands/commands');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

class LooterBot {
  constructor() {
    console.log('🚀 Initializing Looter.ai Clone...');
    
    // Core bot
    this.bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { 
      polling: true,
      polling_timeout: 10
    });
    
    // Add polling event listeners
    this.bot.on('polling_error', (error) => {
      console.error('❌ Polling error:', error);
    });
    
    this.bot.on('error', (error) => {
      console.error('❌ Bot error:', error);
    });
    
    // Components
    this.config = new Config();
    this.auth = new Auth();
    this.chainManager = new ChainManager(); // NEW: For real balance fetching
    this.walletManager = new WalletDBManager(this.chainManager); // NEW: Using database wallet manager with chain manager
    this.userStates = new UserStates();
    this.commands = new Commands(this.bot, this.auth, this.walletManager);
    this.trading = new Trading(this.bot, this.walletManager);
    this.callbacks = new Callbacks(this.bot, this.auth, this.walletManager, this.trading, this.userStates);
    
    this.isRunning = false;
  }

  async start() {
    try {
      console.log('🔧 Initializing database connection...');
      
      // Initialize database wallet manager
      await this.walletManager.initialize();
      console.log('✅ Database wallet manager initialized');
      
      console.log('🔧 Setting up bot handlers...');
      
      // Setup command handlers
      this.setupCommands();
      
      // Setup callback handlers
      console.log('🔧 Callbacks object exists:', !!this.callbacks);
      console.log('🔧 Callbacks handle method exists:', typeof this.callbacks.handle);
      this.setupCallbacks();
      
      // Setup error handling
      this.setupErrorHandling();
      
      this.isRunning = true;
      
      console.log('✅ Looter.ai Clone Bot Started Successfully!');
      console.log('🎯 Features: Multi-chain trading, wallet management, sniping');
      console.log('🗄️ Database: PostgreSQL with encrypted wallet storage');
      console.log('💡 Send /start to begin');
      
    } catch (error) {
      console.error('❌ Failed to start bot:', error.message);
      process.exit(1);
    }
  }

  setupCommands() {
    // /start command
    this.bot.onText(/\/start/, (msg) => {
      this.commands.handleStart(msg);
    });

    // /help command
    this.bot.onText(/\/help/, (msg) => {
      this.commands.handleHelp(msg);
    });

    // /wallets command
    this.bot.onText(/\/wallets/, (msg) => {
      this.commands.handleWallets(msg);
    });

    // Handle all messages (expert mode + wallet import)
    this.bot.on('message', (msg) => {
      console.log('📨 MESSAGE RECEIVED:', msg.text);
      this.handleMessage(msg);
    });
  }

  // Handle all incoming messages
  async handleMessage(msg) {
    const chatId = msg.chat.id;
    
    // Skip if it's a command (already handled by command handlers)
    if (msg.text && msg.text.startsWith('/')) {
      return;
    }
    
    // Check if user is in wallet import state
    if (this.userStates.isImporting(chatId)) {
      await this.callbacks.handleWalletImport(msg);
      return;
    }
    
    // Check if user is in transfer state
    if (this.userStates.isTransferring(chatId)) {
      await this.callbacks.handleTransferMessage(msg);
      return;
    }
    
    // Check if user is waiting for custom amount input
    if (this.userStates.isWaitingForCustomAmount(chatId)) {
      await this.callbacks.handleCustomAmountMessage(msg);
      return;
    }
    
    // Check if user is waiting for custom slippage input (both regular and reply messages)
    if (this.userStates.isAwaitingCustomSlippage(chatId)) {
      await this.callbacks.handleCustomSlippageInput(msg);
      return;
    }
    
    // Check if user is waiting for regular slippage input
    if (this.callbacks.buyTokenUI.isAwaitingSlippageInput(chatId)) {
      const state = this.callbacks.buyTokenUI.userStates.get(chatId);
      await this.callbacks.buyTokenUI.handleSlippageInput(msg, state.sessionId, state.messageId);
      return;
    }
    
    // Check if user is waiting for gas input
    if (this.callbacks.buyTokenUI.isAwaitingGasInput(chatId)) {
      const state = this.callbacks.buyTokenUI.userStates.get(chatId);
      await this.callbacks.buyTokenUI.handleGasInput(msg, state.sessionId, state.originalMessageId);
      return;
    }
    
    // Check if user is waiting for contract address (Buy Token flow)
    if (this.callbacks.buyTokenUI.isWaitingForContractAddress(chatId)) {
      await this.callbacks.buyTokenUI.handleContractAddress(msg);
      return;
    }
    
    // Auto-detect contract addresses (even without clicking Buy Token)
    if (this.isContractAddress(msg.text)) {
      await this.callbacks.buyTokenUI.handleContractAddress(msg);
      return;
    }
    
    // Handle expert mode (token detection)
    this.commands.handleExpertMode(msg);
  }

  // Check if text looks like a contract address
  isContractAddress(text) {
    if (!text) return false;
    
    // Clean the text - remove only whitespace, keep 0x prefix
    const cleanText = text.trim();
    
    // Ethereum/EVM contract address (0x + 40 hex characters)
    if (/^0x[a-fA-F0-9]{40}$/.test(cleanText)) {
      return true;
    }
    
    // Solana contract address (base58, 32-44 characters)
    // More flexible validation for Solana addresses
    if (cleanText.length >= 32 && cleanText.length <= 44 && /^[1-9A-HJ-NP-Za-km-z]+$/.test(cleanText)) {
      return true;
    }
    
    return false;
  }

  setupCallbacks() {
    this.bot.on('callback_query', async (callbackQuery) => {
      try {
        console.log('🎯 CALLBACK RECEIVED:', callbackQuery.data);
        console.log('🎯 Full callback object:', JSON.stringify(callbackQuery, null, 2));
        console.log('🎯 About to call this.callbacks.handle()...');
        console.log('🎯 Callbacks object exists:', !!this.callbacks);
        console.log('🎯 Callbacks handle method exists:', typeof this.callbacks.handle);
        await this.callbacks.handle(callbackQuery);
        console.log('🎯 Callbacks.handle() completed successfully');
      } catch (error) {
        console.error('❌ Callback handler error:', error);
        console.error('❌ Error stack:', error.stack);
      }
    });
  }

  setupErrorHandling() {
    this.bot.on('error', (error) => {
      console.error('❌ Bot error:', error.message);
    });

    process.on('uncaughtException', (error) => {
      console.error('❌ Uncaught exception:', error.message);
    });

    process.on('unhandledRejection', (error) => {
      console.error('❌ Unhandled rejection:', error.message);
    });
  }

  async stop() {
    if (this.isRunning) {
      this.bot.stopPolling();
      
      // Close database connection
      if (this.walletManager && this.walletManager.close) {
        await this.walletManager.close();
        console.log('🗄️ Database connection closed');
      }
      
      this.isRunning = false;
      console.log('🛑 Bot stopped');
    }
  }
}

// Start the bot
if (require.main === module) {
  const bot = new LooterBot();
  bot.start();

  // Graceful shutdown
  process.on('SIGINT', async () => {
    console.log('\n🛑 Shutting down gracefully...');
    await bot.stop();
    process.exit(0);
  });
}

module.exports = LooterBot;