/**
 * TEST GAS FUNCTIONALITY
 * Test the new gas button and settings functionality
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 100)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 100)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function testGasFunctionality() {
  console.log('⛽ ========== GAS FUNCTIONALITY TEST ==========');

  try {
    // Initialize all components
    console.log('🔧 Initializing components...');
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ All components initialized successfully');

    // Test 1: Send token address and check gas button
    console.log('\n📍 TEST 1: Token Analysis with Gas Button');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    console.log('🎯 Sending token address...');
    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Check if gas button appears in keyboard
    const tokenDisplays = mockBot.edits.filter(edit => 
      edit.text && edit.text.includes('Gas:') && edit.options.reply_markup
    );
    
    if (tokenDisplays.length > 0) {
      const keyboard = tokenDisplays[0].options.reply_markup.inline_keyboard;
      const gasButton = keyboard.flat().find(btn => btn.text.includes('⛽ Gas'));
      
      if (gasButton) {
        console.log('✅ Gas button found:', gasButton.text);
        console.log('✅ Gas callback:', gasButton.callback_data);
        
        // Test 2: Click gas button
        console.log('\n📍 TEST 2: Gas Button Click');
        
        const gasCallback = {
          id: 'test_callback_2',
          from: { id: testUserId },
          message: { message_id: 1001 },
          data: gasButton.callback_data
        };
        
        await callbacks.buyTokenUI.handleGasMenu(gasCallback);
        
        // Check if gas menu appears
        const gasMenus = mockBot.edits.filter(edit => 
          edit.text && edit.text.includes('Gas Settings')
        );
        
        if (gasMenus.length > 0) {
          console.log('✅ Gas menu displayed successfully');
          console.log('📊 Gas menu content:', gasMenus[0].text.substring(0, 200));
          
          // Test 3: Select gas option
          console.log('\n📍 TEST 3: Gas Option Selection');
          
          const gasSetCallback = {
            id: 'test_callback_3',
            from: { id: testUserId },
            message: { message_id: 1001 },
            data: 'gas_set_t1_fast' // Assuming session ID is t1
          };
          
          await callbacks.buyTokenUI.handleGasSet(gasSetCallback);
          
          // Check if returned to token page with updated gas
          const updatedTokenDisplays = mockBot.edits.filter(edit => 
            edit.text && edit.text.includes('USD Coin')
          );
          
          if (updatedTokenDisplays.length > 1) {
            console.log('✅ Returned to token page after gas setting');
            
            // Check if gas button text updated
            const lastDisplay = updatedTokenDisplays[updatedTokenDisplays.length - 1];
            if (lastDisplay.options.reply_markup) {
              const updatedKeyboard = lastDisplay.options.reply_markup.inline_keyboard;
              const updatedGasButton = updatedKeyboard.flat().find(btn => btn.text.includes('⛽ Gas'));
              
              if (updatedGasButton) {
                console.log('✅ Gas button updated:', updatedGasButton.text);
              }
            }
          }
          
        } else {
          console.log('❌ Gas menu not displayed');
          return false;
        }
        
      } else {
        console.log('❌ Gas button not found in keyboard');
        return false;
      }
    } else {
      console.log('❌ Token display with gas info not found');
      return false;
    }

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log(`📤 Total messages: ${mockBot.messages.length}`);
    console.log(`✏️ Total edits: ${mockBot.edits.length}`);
    console.log(`✅ Total callbacks: ${mockBot.callbacks.length}`);
    
    // Check for gas-related content
    const gasRelatedEdits = mockBot.edits.filter(edit => 
      edit.text && (edit.text.includes('Gas') || edit.text.includes('gwei'))
    );
    
    console.log(`⛽ Gas-related edits: ${gasRelatedEdits.length}`);
    
    if (gasRelatedEdits.length >= 2) {
      console.log('✅ Gas functionality working correctly!');
      return true;
    } else {
      console.log('❌ Gas functionality incomplete');
      return false;
    }

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
testGasFunctionality().then(success => {
  if (success) {
    console.log('\n🎉 ========== GAS FUNCTIONALITY TEST PASSED! ==========');
    console.log('✅ Gas button appears in token interface');
    console.log('✅ Gas menu opens when clicked');
    console.log('✅ Gas settings can be changed');
    console.log('✅ Gas button text updates after selection');
    console.log('🚀 Gas functionality is working correctly!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== GAS FUNCTIONALITY TEST FAILED ==========');
    console.log('❌ Some gas features are not working properly');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});