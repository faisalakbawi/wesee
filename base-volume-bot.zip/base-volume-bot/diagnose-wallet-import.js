/**
 * DIAGNOSE WALLET IMPORT
 * Check what happened with the original wallet import
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Database = require('./database/database');

async function diagnoseWalletImport() {
  console.log('🔍 ========== DIAGNOSE WALLET IMPORT ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const db = new Database();
    await db.initialize();
    
    // Your details
    const yourUserId = 12345; // Replace with your actual Telegram user ID
    const expectedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    const chain = 'base';
    
    console.log(`🔍 Diagnosing for user: ${yourUserId}`);
    console.log(`🔍 Expected address: ${expectedAddress}`);
    console.log(`🔍 Chain: ${chain}`);
    
    // 1. Check if user exists in database
    console.log('\n📋 STEP 1: Checking user in database...');
    const user = await walletManager.getUser(yourUserId);
    if (user) {
      console.log(`✅ User found in database:`);
      console.log(`   ID: ${user.id}`);
      console.log(`   Telegram ID: ${user.telegram_id}`);
      console.log(`   Created: ${user.created_at}`);
      console.log(`   Last active: ${user.last_active}`);
    } else {
      console.log(`❌ User NOT found in database`);
      console.log(`💡 This might be why wallet import failed`);
      return;
    }
    
    // 2. Check all wallets in database for this user
    console.log('\n📋 STEP 2: Checking all wallets in database...');
    const allWallets = await db.getAllUserWallets(user.id);
    console.log(`📊 Total wallets found: ${allWallets.length}`);
    
    if (allWallets.length > 0) {
      console.log('\n🗂️ ALL WALLETS IN DATABASE:');
      allWallets.forEach((wallet, index) => {
        console.log(`\n${index + 1}. Wallet Details:`);
        console.log(`   Address: ${wallet.address}`);
        console.log(`   Chain: ${wallet.chain_id}`);
        console.log(`   Slot: ${wallet.wallet_slot}`);
        console.log(`   Created: ${wallet.created_at}`);
        console.log(`   Imported: ${wallet.is_imported ? 'Yes' : 'No'}`);
        console.log(`   Has Private Key: ${wallet.private_key ? 'Yes' : 'No'}`);
        
        // Check if this is your expected address
        if (wallet.address.toLowerCase() === expectedAddress.toLowerCase()) {
          console.log(`   🎯 THIS IS YOUR EXPECTED WALLET!`);
          console.log(`   🎯 Found in slot: ${wallet.wallet_slot}`);
          console.log(`   🎯 On chain: ${wallet.chain_id}`);
        }
      });
    }
    
    // 3. Check current wallet manager state
    console.log('\n📋 STEP 3: Checking wallet manager state...');
    const currentWallets = await walletManager.getChainWallets(yourUserId, chain);
    console.log(`📊 Wallets returned by getChainWallets: ${Object.keys(currentWallets).length}`);
    
    // 4. Search for your address across all chains
    console.log('\n📋 STEP 4: Searching for your address across all chains...');
    const chains = ['ethereum', 'base', 'bsc', 'arbitrum', 'polygon', 'avalanche', 'solana'];
    let foundInChain = null;
    let foundInSlot = null;
    
    for (const searchChain of chains) {
      const chainWallets = await walletManager.getChainWallets(yourUserId, searchChain);
      for (let i = 1; i <= 5; i++) {
        const walletSlot = `W${i}`;
        const wallet = chainWallets[walletSlot];
        if (wallet && wallet.address.toLowerCase() === expectedAddress.toLowerCase()) {
          foundInChain = searchChain;
          foundInSlot = walletSlot;
          console.log(`🎯 FOUND YOUR ADDRESS!`);
          console.log(`   Chain: ${searchChain}`);
          console.log(`   Slot: ${walletSlot}`);
          console.log(`   Address: ${wallet.address}`);
          break;
        }
      }
      if (foundInChain) break;
    }
    
    if (!foundInChain) {
      console.log(`❌ Your address ${expectedAddress} was NOT found in any chain/slot`);
    }
    
    // 5. Check import history/logs
    console.log('\n📋 STEP 5: Checking recent database activity...');
    try {
      // Check recent wallet creations
      const recentWallets = await db.query(`
        SELECT w.*, u.telegram_id 
        FROM wallets w 
        JOIN users u ON w.user_id = u.id 
        WHERE u.telegram_id = $1 
        ORDER BY w.created_at DESC 
        LIMIT 10
      `, [yourUserId]);
      
      console.log(`📊 Recent wallet activity (last 10):`);
      recentWallets.rows.forEach((wallet, index) => {
        console.log(`\n${index + 1}. ${wallet.created_at}:`);
        console.log(`   Address: ${wallet.address}`);
        console.log(`   Chain: ${wallet.chain_id}`);
        console.log(`   Slot: ${wallet.wallet_slot}`);
        console.log(`   Imported: ${wallet.is_imported ? 'Yes' : 'No'}`);
      });
    } catch (error) {
      console.log(`❌ Could not check database activity: ${error.message}`);
    }
    
    // 6. Summary and recommendations
    console.log('\n📋 STEP 6: DIAGNOSIS SUMMARY');
    console.log('='.repeat(50));
    
    if (foundInChain && foundInSlot) {
      console.log(`✅ GOOD NEWS: Your wallet was found!`);
      console.log(`   Location: ${foundInChain} chain, slot ${foundInSlot}`);
      if (foundInChain !== chain) {
        console.log(`⚠️  ISSUE: Wallet is on ${foundInChain} but you're trying to trade on ${chain}`);
        console.log(`💡 SOLUTION: Either trade on ${foundInChain} or move wallet to ${chain}`);
      }
      if (foundInSlot !== 'W5') {
        console.log(`⚠️  ISSUE: Wallet is in ${foundInSlot} but you selected W5`);
        console.log(`💡 SOLUTION: Select ${foundInSlot} instead of W5 when trading`);
      }
    } else {
      console.log(`❌ PROBLEM: Your wallet was not imported successfully`);
      console.log(`💡 POSSIBLE CAUSES:`);
      console.log(`   1. Import process was interrupted`);
      console.log(`   2. Wrong private key was used`);
      console.log(`   3. Database error during import`);
      console.log(`   4. User state was not set correctly`);
      console.log(`💡 SOLUTION: Re-import the wallet using the fix script`);
    }
    
    console.log('\n🔧 NEXT STEPS:');
    console.log('1. Run the fix script to import your wallet correctly');
    console.log('2. Verify the import worked');
    console.log('3. Test trading with the correct wallet slot');

  } catch (error) {
    console.error('❌ DIAGNOSIS ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

diagnoseWalletImport().then(() => {
  console.log('\n🎉 Diagnosis completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Diagnosis failed:', error);
  process.exit(1);
});