/**
 * TEST LIVE BOT TO VERIFY CUSTOM SLIPPAGE
 */

const fs = require('fs');

// Check if the current code has the custom slippage functionality
function checkCode() {
  console.log('🔍 ========== CHECKING CURRENT CODE ==========');
  
  // Check callbacks.js for custom slippage routing
  const callbacksCode = fs.readFileSync('./callbacks/callbacks.js', 'utf8');
  
  const hasCustomSlippageRouting = callbacksCode.includes("data.startsWith('slippage_custom_')");
  const hasCustomSlippageHandler = callbacksCode.includes('handleCustomSlippage');
  const hasCustomSlippageInputHandler = callbacksCode.includes('handleCustomSlippageInput');
  
  console.log('✅ Custom slippage routing:', hasCustomSlippageRouting);
  console.log('✅ Custom slippage handler:', hasCustomSlippageHandler);
  console.log('✅ Custom slippage input handler:', hasCustomSlippageInputHandler);
  
  // Check buy-token-ui.js for custom button
  const buyTokenUICode = fs.readFileSync('./callbacks/buy-token-ui.js', 'utf8');
  
  const hasCustomButton = buyTokenUICode.includes('💡 Custom %');
  const hasCustomCallback = buyTokenUICode.includes('slippage_custom_');
  
  console.log('✅ Custom % button:', hasCustomButton);
  console.log('✅ Custom callback data:', hasCustomCallback);
  
  // Check user-states.js for custom slippage state
  const userStatesCode = fs.readFileSync('./utils/user-states.js', 'utf8');
  
  const hasCustomSlippageState = userStatesCode.includes('isAwaitingCustomSlippage');
  const hasGetMethod = userStatesCode.includes('get(chatId)');
  const hasDeleteMethod = userStatesCode.includes('delete(chatId)');
  
  console.log('✅ Custom slippage state check:', hasCustomSlippageState);
  console.log('✅ Get method:', hasGetMethod);
  console.log('✅ Delete method:', hasDeleteMethod);
  
  // Check main-bot.js for message handler
  const mainBotCode = fs.readFileSync('./main-bot.js', 'utf8');
  
  const hasCustomSlippageMessageHandler = mainBotCode.includes('isAwaitingCustomSlippage');
  const hasCustomSlippageInputCall = mainBotCode.includes('handleCustomSlippageInput');
  
  console.log('✅ Custom slippage message handler:', hasCustomSlippageMessageHandler);
  console.log('✅ Custom slippage input call:', hasCustomSlippageInputCall);
  
  console.log('\n🎯 ========== SUMMARY ==========');
  
  const allChecks = [
    hasCustomSlippageRouting,
    hasCustomSlippageHandler,
    hasCustomSlippageInputHandler,
    hasCustomButton,
    hasCustomCallback,
    hasCustomSlippageState,
    hasGetMethod,
    hasDeleteMethod,
    hasCustomSlippageMessageHandler,
    hasCustomSlippageInputCall
  ];
  
  const passedChecks = allChecks.filter(check => check).length;
  const totalChecks = allChecks.length;
  
  console.log(`✅ Passed: ${passedChecks}/${totalChecks} checks`);
  
  if (passedChecks === totalChecks) {
    console.log('🎉 ALL CUSTOM SLIPPAGE CODE IS PRESENT!');
    return true;
  } else {
    console.log('❌ SOME CUSTOM SLIPPAGE CODE IS MISSING!');
    return false;
  }
}

checkCode();