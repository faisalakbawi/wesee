/**
 * TEST IMPROVED GAS FUNCTIONALITY
 * Test the new gas button behavior:
 * 1. Default button shows "GAS"
 * 2. Default behavior is Fast (🚀 Fast)
 * 3. Button updates to show selection (🚀 Fast, 🐌 Standard, ⚡ Instant, 💡 25)
 * 4. Custom gas sends reply message
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
    this.deletedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 80)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 80)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ DELETED: Message ${messageId}`);
    return true;
  }
}

async function testImprovedGasFunctionality() {
  console.log('⛽ ========== IMPROVED GAS FUNCTIONALITY TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // Test 1: Default gas button shows "GAS"
    console.log('\n📍 TEST 1: Default Gas Button Text');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find the token display with keyboard
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    let gasButton = null;
    if (tokenDisplay) {
      const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
      gasButton = keyboard.flat().find(btn => btn.text.includes('GAS') || btn.text.includes('⛽'));
      
      console.log('✅ Default gas button:', gasButton.text);
      
      if (gasButton.text === 'GAS') {
        console.log('✅ PASS: Default gas button shows "GAS"');
      } else {
        console.log('❌ FAIL: Expected "GAS", got:', gasButton.text);
        return false;
      }
    }

    // Test 2: Click gas button - should open menu with Fast as default behavior
    console.log('\n📍 TEST 2: Gas Menu with Fast Default');
    
    const gasCallback = {
      id: 'test_callback_2',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: gasButton.callback_data
    };
    
    await callbacks.buyTokenUI.handleGasMenu(gasCallback);
    
    // Find gas menu
    const gasMenu = mockBot.edits.find(edit => 
      edit.text && edit.text.includes('Gas Settings')
    );
    
    if (gasMenu) {
      console.log('✅ Gas menu opened');
      console.log('📊 Menu content:', gasMenu.text.substring(0, 200));
    }

    // Test 3: Select Fast gas option
    console.log('\n📍 TEST 3: Select Fast Gas Option');
    
    const fastGasCallback = {
      id: 'test_callback_3',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_set_t1_fast'
    };
    
    await callbacks.buyTokenUI.handleGasSet(fastGasCallback);
    
    // Check if button updated to show "🚀 Fast"
    const updatedDisplay = mockBot.edits[mockBot.edits.length - 1];
    if (updatedDisplay.options.reply_markup) {
      const updatedKeyboard = updatedDisplay.options.reply_markup.inline_keyboard;
      const updatedGasButton = updatedKeyboard.flat().find(btn => 
        btn.text.includes('🚀') || btn.text.includes('Fast')
      );
      
      if (updatedGasButton) {
        console.log('✅ Updated gas button:', updatedGasButton.text);
        
        if (updatedGasButton.text === '🚀 Fast') {
          console.log('✅ PASS: Gas button updated to "🚀 Fast"');
        } else {
          console.log('❌ FAIL: Expected "🚀 Fast", got:', updatedGasButton.text);
          return false;
        }
      }
    }

    // Test 4: Select Standard gas option
    console.log('\n📍 TEST 4: Select Standard Gas Option');
    
    // First open gas menu again
    await callbacks.buyTokenUI.handleGasMenu({
      id: 'test_callback_4a',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_t1'
    });
    
    const standardGasCallback = {
      id: 'test_callback_4b',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_set_t1_standard'
    };
    
    await callbacks.buyTokenUI.handleGasSet(standardGasCallback);
    
    // Check if button updated to show "🐌 Standard"
    const standardDisplay = mockBot.edits[mockBot.edits.length - 1];
    if (standardDisplay.options.reply_markup) {
      const keyboard = standardDisplay.options.reply_markup.inline_keyboard;
      const gasBtn = keyboard.flat().find(btn => 
        btn.text.includes('🐌') || btn.text.includes('Standard')
      );
      
      if (gasBtn && gasBtn.text === '🐌 Standard') {
        console.log('✅ PASS: Gas button updated to "🐌 Standard"');
      } else {
        console.log('❌ FAIL: Expected "🐌 Standard", got:', gasBtn?.text);
        return false;
      }
    }

    // Test 5: Select Instant gas option
    console.log('\n📍 TEST 5: Select Instant Gas Option');
    
    // Open gas menu again
    await callbacks.buyTokenUI.handleGasMenu({
      id: 'test_callback_5a',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_t1'
    });
    
    const instantGasCallback = {
      id: 'test_callback_5b',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_set_t1_instant'
    };
    
    await callbacks.buyTokenUI.handleGasSet(instantGasCallback);
    
    // Check if button updated to show "⚡ Instant"
    const instantDisplay = mockBot.edits[mockBot.edits.length - 1];
    if (instantDisplay.options.reply_markup) {
      const keyboard = instantDisplay.options.reply_markup.inline_keyboard;
      const gasBtn = keyboard.flat().find(btn => 
        btn.text.includes('⚡') || btn.text.includes('Instant')
      );
      
      if (gasBtn && gasBtn.text === '⚡ Instant') {
        console.log('✅ PASS: Gas button updated to "⚡ Instant"');
      } else {
        console.log('❌ FAIL: Expected "⚡ Instant", got:', gasBtn?.text);
        return false;
      }
    }

    // Test 6: Custom gas - should send reply message
    console.log('\n📍 TEST 6: Custom Gas Reply Message');
    
    // Open gas menu again
    await callbacks.buyTokenUI.handleGasMenu({
      id: 'test_callback_6a',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_t1'
    });
    
    const customGasCallback = {
      id: 'test_callback_6b',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_custom_t1'
    };
    
    await callbacks.buyTokenUI.handleCustomGas(customGasCallback);
    
    // Check if reply message was sent
    const replyMessages = mockBot.messages.filter(msg => 
      msg.text && msg.text.includes('Custom Gas Price') && msg.reply_to_message_id
    );
    
    if (replyMessages.length > 0) {
      console.log('✅ PASS: Reply message sent for custom gas input');
      console.log('📤 Reply message:', replyMessages[0].text.substring(0, 100));
    } else {
      console.log('❌ FAIL: No reply message sent for custom gas');
      return false;
    }

    // Test 7: Simulate custom gas input
    console.log('\n📍 TEST 7: Custom Gas Input Processing');
    
    const customGasInput = {
      message_id: 2001,
      chat: { id: testUserId },
      text: '25',
      from: { id: testUserId }
    };
    
    await callbacks.buyTokenUI.handleGasInput(customGasInput, 't1', 1001);
    
    // Check if confirmation message was sent
    const confirmMessages = mockBot.messages.filter(msg => 
      msg.text && msg.text.includes('Custom gas set to 25 gwei')
    );
    
    if (confirmMessages.length > 0) {
      console.log('✅ PASS: Custom gas confirmation sent');
    }

    // Check if gas button updated to show custom value
    const finalDisplay = mockBot.edits[mockBot.edits.length - 1];
    if (finalDisplay.options.reply_markup) {
      const keyboard = finalDisplay.options.reply_markup.inline_keyboard;
      const gasBtn = keyboard.flat().find(btn => 
        btn.text.includes('💡') && btn.text.includes('25')
      );
      
      if (gasBtn && gasBtn.text === '💡 25') {
        console.log('✅ PASS: Gas button updated to "💡 25"');
      } else {
        console.log('❌ FAIL: Expected "💡 25", got:', gasBtn?.text);
        return false;
      }
    }

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log(`📤 Total messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Total message edits: ${mockBot.edits.length}`);
    console.log(`✅ Total callback responses: ${mockBot.callbacks.length}`);
    console.log(`🗑️ Total deleted messages: ${mockBot.deletedMessages.length}`);
    
    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
testImprovedGasFunctionality().then(success => {
  if (success) {
    console.log('\n🎉 ========== IMPROVED GAS FUNCTIONALITY TEST PASSED! ==========');
    console.log('✅ Default button shows "GAS"');
    console.log('✅ Default behavior is Fast (internally)');
    console.log('✅ Button updates show selections: 🚀 Fast, 🐌 Standard, ⚡ Instant');
    console.log('✅ Custom gas shows number: 💡 25');
    console.log('✅ Custom gas sends reply message');
    console.log('✅ All gas functionality working perfectly!');
    console.log('🚀 Ready for production use!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== IMPROVED GAS FUNCTIONALITY TEST FAILED ==========');
    console.log('❌ Some gas features are not working as expected');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});