/**
 * COMPREHENSIVE CUSTOM SLIPPAGE TEST
 * Test the complete flow including real bot integration
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot that simulates real Telegram behavior
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== MESSAGE EDITED ==========');
    console.log('📝 Text preview:', text.substring(0, 150) + '...');
    console.log('📝 Has reply_markup:', !!options.reply_markup);
    if (options.reply_markup?.inline_keyboard) {
      console.log('📝 Buttons:');
      options.reply_markup.inline_keyboard.forEach((row, i) => {
        const buttonTexts = row.map(btn => `"${btn.text}"`).join(' | ');
        console.log(`     Row ${i + 1}: ${buttonTexts}`);
      });
    }
    console.log('📝 ===================================');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text) => {
    console.log('📤 ========== NEW MESSAGE SENT ==========');
    console.log('📤 To:', chatId);
    console.log('📤 Text:', text);
    console.log('📤 ====================================');
    return { message_id: 124 };
  },
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ Callback answered:', options?.text || 'OK');
  },
  deleteMessage: async (chatId, messageId) => {
    console.log('🗑️ Message deleted:', messageId);
  }
};

async function testFullCustomSlippage() {
  console.log('🧪 ========== COMPREHENSIVE CUSTOM SLIPPAGE TEST ==========');
  
  try {
    // Initialize components
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    const mockTrading = { chainManager: chainManager };
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    const buyTokenUI = callbacks.buyTokenUI;
    
    await walletManager.initialize();
    
    const testChatId = '6537510183';
    const testMessageId = 123;
    
    console.log('✅ Components initialized');
    
    // Step 1: Create token session
    console.log('\n1️⃣ Creating token session...');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await buyTokenUI.handleContractAddress(contractMsg);
    
    // Get session ID
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 2: Test slippage menu
    console.log('\n2️⃣ Testing slippage menu...');
    const slippageCallback = {
      id: 'test_123',
      data: `slippage_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('🔍 Slippage callback data:', slippageCallback.data);
    await callbacks.handle(slippageCallback);
    console.log('✅ Slippage menu should show "💡 Custom %" button');
    
    // Step 3: Test custom slippage button
    console.log('\n3️⃣ Testing "💡 Custom %" button click...');
    const customSlippageCallback = {
      id: 'test_124',
      data: `slippage_custom_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('🔍 Custom slippage callback data:', customSlippageCallback.data);
    console.log('🔍 About to call callbacks.handle()...');
    
    try {
      await callbacks.handle(customSlippageCallback);
      console.log('✅ Custom slippage button handled successfully');
    } catch (error) {
      console.error('❌ Error handling custom slippage button:', error.message);
      console.error('❌ Stack:', error.stack);
      throw error;
    }
    
    // Step 4: Check user state
    console.log('\n4️⃣ Checking user state...');
    const userState = userStates.get(testChatId);
    console.log('🔍 User state:', userState);
    
    if (!userState || userState.state !== 'awaiting_custom_slippage') {
      throw new Error('User state not set correctly for custom slippage input');
    }
    console.log('✅ User state set correctly');
    
    // Step 5: Test custom slippage input
    console.log('\n5️⃣ Testing custom slippage input...');
    const customInputMsg = {
      chat: { id: testChatId },
      text: '2.5',
      message_id: 125
    };
    
    console.log('🔍 User input:', customInputMsg.text);
    console.log('🔍 About to call handleCustomSlippageInput()...');
    
    try {
      await callbacks.handleCustomSlippageInput(customInputMsg);
      console.log('✅ Custom slippage input handled successfully');
    } catch (error) {
      console.error('❌ Error handling custom slippage input:', error.message);
      console.error('❌ Stack:', error.stack);
      throw error;
    }
    
    // Step 6: Verify slippage was set
    console.log('\n6️⃣ Verifying slippage was set...');
    const currentSlippage = buyTokenUI.getTokenSlippage(testChatId, sessionId);
    console.log('🔍 Current slippage after setting custom:', currentSlippage + '%');
    
    if (currentSlippage === 2.5) {
      console.log('✅ Custom slippage set correctly!');
    } else {
      throw new Error(`Expected 2.5%, got ${currentSlippage}%`);
    }
    
    // Step 7: Test callback routing specifically
    console.log('\n7️⃣ Testing callback routing...');
    
    // Test that slippage_custom_ is routed correctly
    const routingTestCallback = {
      id: 'test_routing',
      data: `slippage_custom_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('🔍 Testing routing for:', routingTestCallback.data);
    
    // Reset user state first
    userStates.delete(testChatId);
    
    try {
      await callbacks.handle(routingTestCallback);
      console.log('✅ Callback routing works correctly');
    } catch (error) {
      console.error('❌ Callback routing failed:', error.message);
      throw error;
    }
    
    // Step 8: Test invalid inputs
    console.log('\n8️⃣ Testing invalid inputs...');
    
    const invalidInputs = ['abc', '100', '-5', '0'];
    
    for (const invalidInput of invalidInputs) {
      console.log(`🔍 Testing invalid input: "${invalidInput}"`);
      
      // Set state for testing
      userStates.set(testChatId, {
        state: 'awaiting_custom_slippage',
        sessionId: sessionId,
        messageId: testMessageId
      });
      
      const invalidMsg = {
        chat: { id: testChatId },
        text: invalidInput,
        message_id: 126
      };
      
      try {
        await callbacks.handleCustomSlippageInput(invalidMsg);
        console.log(`✅ Invalid input "${invalidInput}" handled correctly`);
      } catch (error) {
        console.error(`❌ Error handling invalid input "${invalidInput}":`, error.message);
      }
    }
    
    console.log('\n🎉 ========== TEST RESULTS ==========');
    console.log('✅ Token session creation: WORKING');
    console.log('✅ Slippage menu display: WORKING');
    console.log('✅ Custom slippage button: WORKING');
    console.log('✅ User state management: WORKING');
    console.log('✅ Custom slippage input: WORKING');
    console.log('✅ Slippage value storage: WORKING');
    console.log('✅ Callback routing: WORKING');
    console.log('✅ Invalid input handling: WORKING');
    console.log('\n🚀 ALL CUSTOM SLIPPAGE FUNCTIONALITY IS WORKING!');
    
    console.log('\n📋 ========== DEBUGGING INFO ==========');
    console.log('🔍 Session ID used:', sessionId);
    console.log('🔍 Final slippage value:', buyTokenUI.getTokenSlippage(testChatId, sessionId) + '%');
    console.log('🔍 User state cleared:', !userStates.get(testChatId));
    
  } catch (error) {
    console.error('\n❌ ========== TEST FAILED ==========');
    console.error('❌ Error:', error.message);
    console.error('❌ Stack:', error.stack);
    
    console.error('\n🔧 DEBUGGING INFO:');
    console.error('🔧 This indicates where the issue is in the flow');
  }
  
  process.exit(0);
}

testFullCustomSlippage();