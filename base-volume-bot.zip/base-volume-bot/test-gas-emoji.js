/**
 * TEST GAS BUTTON WITH EMOJI
 * Verify the gas button now shows "⛽ GAS" with the emoji
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT MESSAGE`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED MESSAGE`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK ANSWERED`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED MESSAGE`);
    return true;
  }
}

async function testGasEmoji() {
  console.log('⛽ ========== GAS EMOJI TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // Test: Send token address and check gas button
    console.log('\n📍 TEST: Gas Button with Emoji');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find the token display with keyboard
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    if (tokenDisplay) {
      const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
      const gasButton = keyboard.flat().find(btn => 
        btn.text.includes('⛽') && btn.text.includes('GAS')
      );
      
      if (gasButton) {
        console.log('✅ FOUND GAS BUTTON:', gasButton.text);
        
        if (gasButton.text === '⛽ GAS') {
          console.log('🎉 SUCCESS: Gas button shows "⛽ GAS" with emoji!');
          return true;
        } else {
          console.log('❌ FAIL: Expected "⛽ GAS", got:', gasButton.text);
          return false;
        }
      } else {
        console.log('❌ FAIL: Gas button with emoji not found');
        return false;
      }
    } else {
      console.log('❌ FAIL: Token display not found');
      return false;
    }

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    return false;
  }
}

// Run the test
testGasEmoji().then(success => {
  if (success) {
    console.log('\n🎉 ========== GAS EMOJI TEST PASSED! ==========');
    console.log('✅ Gas button now shows: "⛽ GAS"');
    console.log('✅ Emoji added successfully');
    console.log('✅ Button looks perfect!');
    console.log('🚀 Ready for users!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== GAS EMOJI TEST FAILED ==========');
    console.log('❌ Gas button emoji not working correctly');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});