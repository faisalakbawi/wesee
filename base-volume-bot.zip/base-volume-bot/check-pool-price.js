/**
 * CHECK ACTUAL POOL PRICE
 * Get the real price from the Uniswap V3 pool
 */

const { ethers } = require('ethers');

async function checkPoolPrice() {
  console.log(`🏊 ========== CHECKING ACTUAL POOL PRICE ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  const TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  // Pool ABI for getting current state
  const poolABI = [
    "function token0() external view returns (address)",
    "function token1() external view returns (address)",
    "function fee() external view returns (uint24)",
    "function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)"
  ];
  
  const pool = new ethers.Contract(TONY_POOL, poolABI, provider);
  
  try {
    console.log(`📍 Pool: ${TONY_POOL}`);
    
    // Get pool info
    const token0 = await pool.token0();
    const token1 = await pool.token1();
    const fee = await pool.fee();
    const slot0 = await pool.slot0();
    
    console.log(`\n📊 Pool Info:`);
    console.log(`  🪙 Token0: ${token0}`);
    console.log(`  🪙 Token1: ${token1}`);
    console.log(`  💸 Fee: ${fee} (${fee / 10000}%)`);
    console.log(`  🔢 SqrtPriceX96: ${slot0.sqrtPriceX96.toString()}`);
    console.log(`  📊 Tick: ${slot0.tick}`);
    console.log(`  🔓 Unlocked: ${slot0.unlocked}`);
    
    // Determine which token is which
    const isToken0TONY = token0.toLowerCase() === TONY.toLowerCase();
    const isToken0WETH = token0.toLowerCase() === WETH.toLowerCase();
    
    console.log(`\n🔍 Token Analysis:`);
    console.log(`  ${isToken0TONY ? '✅' : '❌'} Token0 is TONY: ${isToken0TONY}`);
    console.log(`  ${isToken0WETH ? '✅' : '❌'} Token0 is WETH: ${isToken0WETH}`);
    
    if (!slot0.unlocked) {
      console.log(`❌ POOL IS LOCKED! This explains the swap failures.`);
      return { locked: true };
    }
    
    // Calculate actual price from sqrtPriceX96
    const sqrtPriceX96 = slot0.sqrtPriceX96;
    const price = sqrtPriceX96.mul(sqrtPriceX96).div(ethers.BigNumber.from(2).pow(192));
    
    console.log(`\n💰 Price Calculation:`);
    console.log(`  🔢 Raw price: ${price.toString()}`);
    
    // Calculate human-readable price
    let ethPerTony, tonyPerEth;
    
    if (isToken0TONY) {
      // Token0 = TONY, Token1 = WETH
      // Price = Token1/Token0 = WETH/TONY
      ethPerTony = price;
      tonyPerEth = ethers.BigNumber.from(10).pow(36).div(price);
      
      console.log(`  📊 1 TONY = ${ethers.utils.formatEther(ethPerTony)} ETH`);
      console.log(`  📊 1 ETH = ${ethers.utils.formatUnits(tonyPerEth, 18)} TONY`);
      
    } else {
      // Token0 = WETH, Token1 = TONY  
      // Price = Token1/Token0 = TONY/WETH
      tonyPerEth = price;
      ethPerTony = ethers.BigNumber.from(10).pow(36).div(price);
      
      console.log(`  📊 1 ETH = ${ethers.utils.formatUnits(tonyPerEth, 18)} TONY`);
      console.log(`  📊 1 TONY = ${ethers.utils.formatEther(ethPerTony)} ETH`);
    }
    
    // Calculate expected output for 0.001 ETH
    const ethAmount = ethers.utils.parseEther('0.001');
    const expectedTony = ethAmount.mul(tonyPerEth).div(ethers.utils.parseEther('1'));
    
    console.log(`\n🧮 Expected Output for 0.001 ETH:`);
    console.log(`  📥 Input: 0.001 ETH`);
    console.log(`  📤 Expected: ${ethers.utils.formatUnits(expectedTony, 18)} TONY`);
    
    // Compare with our assumption
    const ourAssumption = ethers.utils.parseUnits('34.11', 18);
    const difference = expectedTony.sub(ourAssumption).abs();
    const percentDiff = difference.mul(100).div(ourAssumption);
    
    console.log(`\n🔍 Comparison with our assumption:`);
    console.log(`  🤖 Our assumption: 34.11 TONY`);
    console.log(`  🏊 Pool reality: ${ethers.utils.formatUnits(expectedTony, 18)} TONY`);
    console.log(`  📊 Difference: ${percentDiff.toString()}%`);
    
    if (percentDiff.gt(50)) {
      console.log(`  ⚠️ HUGE PRICE DIFFERENCE! Our assumption is way off.`);
    }
    
    return {
      token0,
      token1,
      fee,
      sqrtPriceX96: sqrtPriceX96.toString(),
      tick: slot0.tick,
      unlocked: slot0.unlocked,
      expectedTony: expectedTony.toString(),
      isToken0TONY
    };
    
  } catch (error) {
    console.log(`❌ Pool price check failed: ${error.message}`);
    return { error: error.message };
  }
}

// Test swap with correct price
async function testSwapWithCorrectPrice(expectedTony, isToken0TONY) {
  console.log(`\n🧪 ========== TESTING SWAP WITH CORRECT PRICE ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const SWAP_ROUTER_02 = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  const router = new ethers.Contract(SWAP_ROUTER_02, routerABI, provider);
  
  // Use the correct expected amount with 50% slippage
  const expectedTonyBN = ethers.BigNumber.from(expectedTony);
  const minOut = expectedTonyBN.mul(5000).div(10000); // 50% slippage
  
  console.log(`🔧 Using correct price data:`);
  console.log(`  📊 Expected TONY: ${ethers.utils.formatUnits(expectedTonyBN, 18)}`);
  console.log(`  🛡️ Min out (50% slippage): ${ethers.utils.formatUnits(minOut, 18)}`);
  
  const swapParams = {
    tokenIn: WETH,
    tokenOut: TONY,
    fee: 10000, // 1% fee tier
    recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A',
    deadline: Math.floor(Date.now() / 1000) + 300,
    amountIn: ethers.utils.parseEther('0.001'),
    amountOutMinimum: minOut,
    sqrtPriceLimitX96: 0
  };
  
  try {
    const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
      value: ethers.utils.parseEther('0.001'),
      from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
    });
    
    console.log(`✅ SWAP WITH CORRECT PRICE WORKS!`);
    console.log(`⛽ Gas estimate: ${gasEstimate.toString()}`);
    console.log(`🎉 The issue was our wrong price assumption!`);
    
    return { success: true, gas: gasEstimate.toString() };
    
  } catch (error) {
    console.log(`❌ Still failed: ${error.message.split('(')[0]}`);
    return { success: false, error: error.message };
  }
}

// Run the analysis
async function runPriceAnalysis() {
  console.log(`🧪 ========== COMPREHENSIVE PRICE ANALYSIS ==========`);
  
  const poolData = await checkPoolPrice();
  
  if (poolData.error) {
    console.log(`❌ Could not get pool data`);
    return;
  }
  
  if (poolData.locked) {
    console.log(`❌ Pool is locked - cannot trade`);
    return;
  }
  
  // Test swap with correct price
  const swapResult = await testSwapWithCorrectPrice(poolData.expectedTony, poolData.isToken0TONY);
  
  console.log(`\n📊 ========== FINAL RESULT ==========`);
  if (swapResult.success) {
    console.log(`✅ PROBLEM SOLVED!`);
    console.log(`🎯 Issue was: Wrong price assumption`);
    console.log(`💡 Solution: Use real pool price instead of hardcoded 34.11 TONY`);
    console.log(`⛽ Working gas: ${swapResult.gas}`);
  } else {
    console.log(`❌ Still not working - deeper issue exists`);
  }
}

runPriceAnalysis().catch(console.error);