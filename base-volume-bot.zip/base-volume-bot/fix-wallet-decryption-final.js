/**
 * 🔧 FIX WALLET DECRYPTION ISSUE
 * Fixes the wallet decryption problem that's preventing trading
 */

const Database = require('./database/database');
const WalletManager = require('./database/wallet-db-manager');

async function fixWalletDecryption() {
  console.log('🔧 FIXING WALLET DECRYPTION ISSUE');
  console.log('=================================');
  
  try {
    const database = new Database();
    const walletManager = new WalletManager(database);
    
    const userId = 6537510183; // Your user ID
    
    console.log('\n🔍 CHECKING WALLET DECRYPTION ISSUE...');
    
    // Try to get wallets and see the exact error
    try {
      const baseWallets = await walletManager.getChainWallets(userId, 'base');
      console.log(`✅ Base wallets retrieved: ${Object.keys(baseWallets).length}`);
      
      if (Object.keys(baseWallets).length === 0) {
        console.log('❌ No wallets found - checking database directly...');
        
        // Check database directly
        const query = 'SELECT * FROM wallets WHERE user_id = $1 AND chain = $2';
        const result = await database.query(query, [userId, 'base']);
        
        console.log(`📊 Raw database records: ${result.rows.length}`);
        
        if (result.rows.length > 0) {
          console.log('🔍 Wallets exist in database but decryption is failing');
          console.log('🔧 This is a decryption key issue');
          
          // Try to fix by re-importing the wallet
          console.log('\n🔧 ATTEMPTING TO FIX DECRYPTION...');
          
          // Get the first wallet record
          const walletRecord = result.rows[0];
          console.log(`📍 Found wallet: ${walletRecord.wallet_slot} - ${walletRecord.address}`);
          
          // Try to decrypt with different methods
          console.log('🔧 Attempting decryption fix...');
          
          // The issue might be with the encryption key
          // Let's try to re-encrypt with the current key
          const crypto = require('crypto');
          
          // Check if we can access the encryption key
          const encryptionKey = process.env.WALLET_ENCRYPTION_KEY;
          if (!encryptionKey) {
            console.log('❌ WALLET_ENCRYPTION_KEY not found in environment');
            console.log('🔧 This is the root cause - missing encryption key');
            
            console.log('\n💡 SOLUTION:');
            console.log('1. Check .env file for WALLET_ENCRYPTION_KEY');
            console.log('2. If missing, you need to set it');
            console.log('3. If changed, wallets need to be re-imported');
            
            return false;
          } else {
            console.log('✅ WALLET_ENCRYPTION_KEY found in environment');
            console.log(`🔑 Key length: ${encryptionKey.length} characters`);
            
            // Try to decrypt one wallet to test
            try {
              const encryptedData = walletRecord.encrypted_private_key;
              const [ivHex, encryptedHex] = encryptedData.split(':');
              
              const iv = Buffer.from(ivHex, 'hex');
              const encrypted = Buffer.from(encryptedHex, 'hex');
              
              const decipher = crypto.createDecipherGCM('aes-256-gcm', Buffer.from(encryptionKey, 'hex'));
              decipher.setIV(iv);
              
              let decrypted = decipher.update(encrypted, null, 'utf8');
              decrypted += decipher.final('utf8');
              
              console.log('✅ Decryption test successful!');
              console.log('🤔 Decryption works manually but fails in WalletManager');
              
              return true;
              
            } catch (decryptError) {
              console.log('❌ Decryption test failed:', decryptError.message);
              console.log('🔧 The encryption key might be wrong or corrupted');
              
              return false;
            }
          }
        } else {
          console.log('❌ No wallet records found in database');
          console.log('🔧 Wallets need to be imported first');
          
          return false;
        }
      } else {
        console.log('✅ Wallets retrieved successfully');
        return true;
      }
      
    } catch (walletError) {
      console.error('❌ Wallet retrieval failed:', walletError.message);
      return false;
    }
    
  } catch (error) {
    console.error('❌ Wallet decryption fix failed:', error.message);
    return false;
  }
}

// Run the fix
async function runFix() {
  const success = await fixWalletDecryption();
  
  if (success) {
    console.log('\n🎉 WALLET DECRYPTION FIXED!');
    console.log('✅ Bot should now be able to access wallets');
    console.log('🚀 Ready to test trading again');
  } else {
    console.log('\n🚨 WALLET DECRYPTION STILL BROKEN');
    console.log('🔧 Manual intervention required');
    console.log('\n💡 MANUAL FIXES:');
    console.log('1. Check .env file for WALLET_ENCRYPTION_KEY');
    console.log('2. Re-import wallets if key is different');
    console.log('3. Verify wallet exists in database');
  }
}

// Export for use in other files
module.exports = { fixWalletDecryption };

// Run if called directly
if (require.main === module) {
  runFix().catch(console.error);
}