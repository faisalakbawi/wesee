#!/usr/bin/env node

/**
 * DEBUG TONY TOKEN
 * Let's see what's actually happening with the TONY token
 */

require('dotenv').config();
const { ethers } = require('ethers');

async function debugTonyToken() {
  try {
    console.log('🔍 ========== DEBUGGING TONY TOKEN ==========');
    
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    
    // TONY token from successful transaction
    const TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';
    const WETH = '0x4200000000000000000000000000000000000006';
    const UNISWAP_V3_FACTORY = '0x33128a8fC17869897dcE68Ed026d694621f6FDfD';
    
    // Known successful pool from transaction
    const KNOWN_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    
    console.log(`🎯 TONY Token: ${TONY_TOKEN}`);
    console.log(`💧 WETH: ${WETH}`);
    console.log(`🏭 Factory: ${UNISWAP_V3_FACTORY}`);
    console.log(`🏊 Known Pool: ${KNOWN_POOL}`);
    
    // Check if TONY token contract exists
    console.log(`\n📋 STEP 1: Checking TONY token contract...`);
    const tokenCode = await provider.getCode(TONY_TOKEN);
    console.log(`📝 Token contract exists: ${tokenCode !== '0x'}`);
    
    if (tokenCode !== '0x') {
      const ERC20_ABI = [
        'function name() external view returns (string)',
        'function symbol() external view returns (string)',
        'function decimals() external view returns (uint8)',
        'function totalSupply() external view returns (uint256)'
      ];
      
      try {
        const token = new ethers.Contract(TONY_TOKEN, ERC20_ABI, provider);
        const [name, symbol, decimals, totalSupply] = await Promise.all([
          token.name().catch(() => 'Unknown'),
          token.symbol().catch(() => 'UNK'),
          token.decimals().catch(() => 18),
          token.totalSupply().catch(() => ethers.BigNumber.from(0))
        ]);
        
        console.log(`📊 Token Info:`);
        console.log(`  Name: ${name}`);
        console.log(`  Symbol: ${symbol}`);
        console.log(`  Decimals: ${decimals}`);
        console.log(`  Total Supply: ${ethers.utils.formatUnits(totalSupply, decimals)}`);
      } catch (error) {
        console.log(`❌ Failed to get token info:`, error.message);
      }
    }
    
    // Check Uniswap V3 Factory
    console.log(`\n🏭 STEP 2: Checking Uniswap V3 Factory...`);
    const factoryCode = await provider.getCode(UNISWAP_V3_FACTORY);
    console.log(`🏭 Factory exists: ${factoryCode !== '0x'}`);
    
    if (factoryCode !== '0x') {
      const FACTORY_ABI = [
        'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)'
      ];
      
      const factory = new ethers.Contract(UNISWAP_V3_FACTORY, FACTORY_ABI, provider);
      
      // Check all fee tiers
      const feeTiers = [100, 500, 3000, 10000];
      console.log(`🔍 Checking all fee tiers...`);
      
      for (const fee of feeTiers) {
        try {
          const pool1 = await factory.getPool(WETH, TONY_TOKEN, fee);
          const pool2 = await factory.getPool(TONY_TOKEN, WETH, fee);
          
          console.log(`  Fee ${fee / 10000}%:`);
          console.log(`    WETH/TONY: ${pool1}`);
          console.log(`    TONY/WETH: ${pool2}`);
          
          if (pool1 !== ethers.constants.AddressZero) {
            console.log(`    ✅ Found pool: ${pool1}`);
          }
          if (pool2 !== ethers.constants.AddressZero) {
            console.log(`    ✅ Found pool: ${pool2}`);
          }
        } catch (error) {
          console.log(`    ❌ Fee ${fee / 10000}% failed:`, error.message);
        }
      }
    }
    
    // Check the known successful pool
    console.log(`\n🏊 STEP 3: Checking known successful pool...`);
    const poolCode = await provider.getCode(KNOWN_POOL);
    console.log(`🏊 Known pool exists: ${poolCode !== '0x'}`);
    
    if (poolCode !== '0x') {
      const POOL_ABI = [
        'function token0() external view returns (address)',
        'function token1() external view returns (address)',
        'function fee() external view returns (uint24)',
        'function liquidity() external view returns (uint128)',
        'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)'
      ];
      
      try {
        const pool = new ethers.Contract(KNOWN_POOL, POOL_ABI, provider);
        const [token0, token1, fee, liquidity, slot0] = await Promise.all([
          pool.token0(),
          pool.token1(),
          pool.fee(),
          pool.liquidity(),
          pool.slot0()
        ]);
        
        console.log(`📊 Pool Info:`);
        console.log(`  Token0: ${token0}`);
        console.log(`  Token1: ${token1}`);
        console.log(`  Fee: ${fee / 10000}%`);
        console.log(`  Liquidity: ${liquidity.toString()}`);
        console.log(`  Current tick: ${slot0.tick}`);
        console.log(`  Unlocked: ${slot0.unlocked}`);
        
        // Check if this matches our tokens
        const hasWETH = token0.toLowerCase() === WETH.toLowerCase() || token1.toLowerCase() === WETH.toLowerCase();
        const hasTONY = token0.toLowerCase() === TONY_TOKEN.toLowerCase() || token1.toLowerCase() === TONY_TOKEN.toLowerCase();
        
        console.log(`  ✅ Contains WETH: ${hasWETH}`);
        console.log(`  ✅ Contains TONY: ${hasTONY}`);
        console.log(`  ✅ Valid pool: ${hasWETH && hasTONY}`);
        
      } catch (error) {
        console.log(`❌ Failed to get pool info:`, error.message);
      }
    }
    
    // Test a simple swap estimate
    console.log(`\n🧮 STEP 4: Testing swap estimate...`);
    const ROUTER_ABI = [
      'function exactInputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96)) external payable returns (uint256 amountOut)'
    ];
    
    const UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
    const router = new ethers.Contract(UNISWAP_V3_ROUTER, ROUTER_ABI, provider);
    
    // Try to estimate gas for a small swap
    const testAmount = ethers.utils.parseEther('0.001');
    const params = {
      tokenIn: WETH,
      tokenOut: TONY_TOKEN,
      fee: 10000, // 1% fee (from successful transaction)
      recipient: ethers.constants.AddressZero, // Test address
      deadline: Math.floor(Date.now() / 1000) + 300,
      amountIn: testAmount,
      amountOutMinimum: 0,
      sqrtPriceLimitX96: 0
    };
    
    try {
      const gasEstimate = await router.estimateGas.exactInputSingle(params, {
        value: testAmount
      });
      console.log(`✅ Swap estimate successful! Gas: ${gasEstimate.toString()}`);
    } catch (error) {
      console.log(`❌ Swap estimate failed:`, error.message);
      
      // Try with different fee
      params.fee = 3000; // 0.3%
      try {
        const gasEstimate2 = await router.estimateGas.exactInputSingle(params, {
          value: testAmount
        });
        console.log(`✅ Swap estimate successful with 0.3% fee! Gas: ${gasEstimate2.toString()}`);
      } catch (error2) {
        console.log(`❌ Swap estimate failed with 0.3% fee:`, error2.message);
      }
    }
    
    console.log(`\n✅ TONY TOKEN DEBUG COMPLETE`);
    
  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  }
}

// Run debug
debugTonyToken();