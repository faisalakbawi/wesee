#!/usr/bin/env node

/**
 * DEBUG POOL STATE
 * Check the current state of the TONY pool to understand why transactions fail
 */

require('dotenv').config();
const { ethers } = require('ethers');

async function debugPoolState() {
  console.log('🔍 ========== DEBUGGING POOL STATE ==========');
  
  const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
  
  // Addresses
  const TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
  const UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WALLET = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
  
  // ABIs
  const POOL_ABI = [
    'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
    'function liquidity() external view returns (uint128)',
    'function token0() external view returns (address)',
    'function token1() external view returns (address)',
    'function fee() external view returns (uint24)',
    'function tickSpacing() external view returns (int24)',
    'function maxLiquidityPerTick() external view returns (uint128)',
    'function protocolFees() external view returns (uint128 token0, uint128 token1)',
    'function feeGrowthGlobal0X128() external view returns (uint256)',
    'function feeGrowthGlobal1X128() external view returns (uint256)'
  ];
  
  const ERC20_ABI = [
    'function balanceOf(address account) external view returns (uint256)',
    'function decimals() external view returns (uint8)',
    'function name() external view returns (string)',
    'function symbol() external view returns (string)',
    'function totalSupply() external view returns (uint256)',
    'function transfer(address to, uint256 amount) external returns (bool)',
    'function transferFrom(address from, address to, uint256 amount) external returns (bool)',
    'function approve(address spender, uint256 amount) external returns (bool)',
    'function allowance(address owner, address spender) external view returns (uint256)'
  ];
  
  const ROUTER_ABI = [
    'function exactInputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96)) external payable returns (uint256 amountOut)'
  ];
  
  try {
    console.log('📊 STEP 1: Pool State Analysis');
    
    const pool = new ethers.Contract(TONY_POOL, POOL_ABI, provider);
    
    const [slot0, liquidity, token0, token1, fee, tickSpacing] = await Promise.all([
      pool.slot0(),
      pool.liquidity(),
      pool.token0(),
      pool.token1(),
      pool.fee(),
      pool.tickSpacing()
    ]);
    
    console.log(`  🏊 Pool: ${TONY_POOL}`);
    console.log(`  📍 Token0: ${token0} ${token0.toLowerCase() === TONY_TOKEN.toLowerCase() ? '(TONY)' : '(WETH)'}`);
    console.log(`  📍 Token1: ${token1} ${token1.toLowerCase() === WETH.toLowerCase() ? '(WETH)' : '(TONY)'}`);
    console.log(`  💸 Fee: ${fee} (${fee / 10000}%)`);
    console.log(`  💧 Liquidity: ${liquidity.toString()}`);
    console.log(`  🎯 Current Tick: ${slot0.tick}`);
    console.log(`  🔓 Unlocked: ${slot0.unlocked}`);
    console.log(`  📈 SqrtPriceX96: ${slot0.sqrtPriceX96.toString()}`);
    console.log(`  📊 Tick Spacing: ${tickSpacing}`);
    
    // Check if pool has enough liquidity
    const hasLiquidity = liquidity.gt(0);
    console.log(`  ✅ Has Liquidity: ${hasLiquidity}`);
    
    if (!slot0.unlocked) {
      console.log(`  ❌ CRITICAL: Pool is LOCKED!`);
      return;
    }
    
    console.log('\n📊 STEP 2: Token Analysis');
    
    // Check TONY token
    const tonyToken = new ethers.Contract(TONY_TOKEN, ERC20_ABI, provider);
    const [tonyName, tonySymbol, tonyDecimals, tonyTotalSupply] = await Promise.all([
      tonyToken.name(),
      tonyToken.symbol(),
      tonyToken.decimals(),
      tonyToken.totalSupply()
    ]);
    
    console.log(`  🪙 TONY Token:`);
    console.log(`    Name: ${tonyName}`);
    console.log(`    Symbol: ${tonySymbol}`);
    console.log(`    Decimals: ${tonyDecimals}`);
    console.log(`    Total Supply: ${ethers.utils.formatUnits(tonyTotalSupply, tonyDecimals)}`);
    
    // Check pool token balances
    const [tonyPoolBalance, wethPoolBalance] = await Promise.all([
      tonyToken.balanceOf(TONY_POOL),
      provider.getBalance(TONY_POOL) // For WETH, check ETH balance of pool
    ]);
    
    console.log(`  💰 Pool Balances:`);
    console.log(`    TONY in pool: ${ethers.utils.formatUnits(tonyPoolBalance, tonyDecimals)}`);
    console.log(`    ETH in pool: ${ethers.utils.formatEther(wethPoolBalance)}`);
    
    console.log('\n📊 STEP 3: Wallet Analysis');
    
    const walletEthBalance = await provider.getBalance(WALLET);
    const walletTonyBalance = await tonyToken.balanceOf(WALLET);
    
    console.log(`  👤 Wallet: ${WALLET}`);
    console.log(`  💰 ETH Balance: ${ethers.utils.formatEther(walletEthBalance)}`);
    console.log(`  🪙 TONY Balance: ${ethers.utils.formatUnits(walletTonyBalance, tonyDecimals)}`);
    
    console.log('\n📊 STEP 4: Router Analysis');
    
    // Check if router exists
    const routerCode = await provider.getCode(UNISWAP_V3_ROUTER);
    console.log(`  🔧 Router exists: ${routerCode !== '0x'}`);
    
    if (routerCode === '0x') {
      console.log(`  ❌ CRITICAL: Router contract doesn't exist!`);
      return;
    }
    
    console.log('\n📊 STEP 5: Simulate Small Trade');
    
    // Try to simulate a very small trade
    const router = new ethers.Contract(UNISWAP_V3_ROUTER, ROUTER_ABI, provider);
    
    const smallAmount = ethers.utils.parseEther('0.0001'); // Very small amount
    
    const params = {
      tokenIn: WETH,
      tokenOut: TONY_TOKEN,
      fee: 10000,
      recipient: WALLET,
      deadline: Math.floor(Date.now() / 1000) + 300,
      amountIn: smallAmount,
      amountOutMinimum: 0,
      sqrtPriceLimitX96: 0
    };
    
    try {
      console.log(`  🧪 Testing 0.0001 ETH trade...`);
      
      // Try to estimate gas
      const gasEstimate = await router.estimateGas.exactInputSingle(params, {
        value: smallAmount,
        from: WALLET
      });
      
      console.log(`  ✅ Small trade simulation SUCCESS!`);
      console.log(`  ⛽ Gas estimate: ${gasEstimate.toString()}`);
      
      // Try with original amount
      console.log(`  🧪 Testing 0.001 ETH trade...`);
      
      const originalAmount = ethers.utils.parseEther('0.001');
      const originalParams = { ...params, amountIn: originalAmount };
      
      const originalGasEstimate = await router.estimateGas.exactInputSingle(originalParams, {
        value: originalAmount,
        from: WALLET
      });
      
      console.log(`  ✅ Original trade simulation SUCCESS!`);
      console.log(`  ⛽ Gas estimate: ${originalGasEstimate.toString()}`);
      
      console.log(`\n🤔 MYSTERY: Simulation works but actual transaction fails!`);
      console.log(`💡 This suggests a timing or state issue during execution`);
      
    } catch (error) {
      console.log(`  ❌ Trade simulation FAILED: ${error.message}`);
      
      if (error.message.includes('insufficient liquidity')) {
        console.log(`  💡 CAUSE: Pool has insufficient liquidity for this trade size`);
      } else if (error.message.includes('price')) {
        console.log(`  💡 CAUSE: Price impact too high or price limits exceeded`);
      } else if (error.message.includes('deadline')) {
        console.log(`  💡 CAUSE: Deadline issues`);
      } else {
        console.log(`  💡 CAUSE: Unknown - ${error.message}`);
      }
    }
    
    console.log('\n📊 STEP 6: Alternative Pool Check');
    
    // Check if there are other TONY pools
    const FACTORY_ABI = [
      'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)'
    ];
    
    const UNISWAP_V3_FACTORY = '0x33128a8fC17869897dcE68Ed026d694621f6FDfD';
    const factory = new ethers.Contract(UNISWAP_V3_FACTORY, FACTORY_ABI, provider);
    
    const feeTiers = [100, 500, 3000, 10000];
    console.log(`  🔍 Checking all fee tiers for TONY/WETH pools...`);
    
    for (const feeCheck of feeTiers) {
      try {
        const pool1 = await factory.getPool(WETH, TONY_TOKEN, feeCheck);
        const pool2 = await factory.getPool(TONY_TOKEN, WETH, feeCheck);
        
        console.log(`    ${feeCheck / 10000}% fee:`);
        console.log(`      WETH/TONY: ${pool1}`);
        console.log(`      TONY/WETH: ${pool2}`);
        
        if (pool1 !== ethers.constants.AddressZero && pool1 !== TONY_POOL) {
          console.log(`      🆕 Alternative pool found: ${pool1}`);
        }
        if (pool2 !== ethers.constants.AddressZero && pool2 !== TONY_POOL) {
          console.log(`      🆕 Alternative pool found: ${pool2}`);
        }
      } catch (error) {
        console.log(`    ${feeCheck / 10000}% fee: Error - ${error.message}`);
      }
    }
    
    console.log('\n✅ POOL STATE DEBUG COMPLETE');
    
    console.log('\n💡 RECOMMENDATIONS:');
    console.log('1. Try with even smaller amount (0.00001 ETH)');
    console.log('2. Check if TONY token has transfer fees or restrictions');
    console.log('3. Try using a different router or DEX');
    console.log('4. Check if pool requires specific conditions');
    console.log('5. Monitor pool state changes in real-time');
    
  } catch (error) {
    console.error('❌ Pool state debug failed:', error.message);
  }
}

// Run debug
debugPoolState();