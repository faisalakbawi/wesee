/**
 * TEST TO REPRODUCE SLIPPAGE ERROR
 * This will help us identify the exact issue
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot that logs everything
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== EDIT MESSAGE ATTEMPT ==========');
    console.log('📝 Chat ID:', options.chat_id);
    console.log('📝 Message ID:', options.message_id);
    console.log('📝 Text length:', text.length);
    console.log('📝 Has reply_markup:', !!options.reply_markup);
    console.log('📝 Parse mode:', options.parse_mode);
    
    // Simulate potential error scenarios
    if (options.message_id === 999) {
      console.log('❌ SIMULATING MESSAGE NOT FOUND ERROR');
      const error = new Error('Bad Request: message to edit not found');
      error.code = 'ETELEGRAM';
      error.response = { body: { error_code: 400, description: 'Bad Request: message to edit not found' } };
      throw error;
    }
    
    console.log('✅ Message edit would succeed');
    console.log('📝 ==========================================');
    return { message_id: options.message_id };
  },
  
  sendMessage: async (chatId, text, options) => {
    console.log('📤 ========== SEND MESSAGE ==========');
    console.log('📤 To:', chatId);
    console.log('📤 Text preview:', text.substring(0, 50) + '...');
    console.log('📤 Has force_reply:', !!options?.reply_markup?.force_reply);
    console.log('📤 ================================');
    return { message_id: 999 }; // This will cause edit error later
  },
  
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ Callback answered:', options?.text || 'OK');
  },
  
  deleteMessage: async (chatId, messageId) => {
    console.log('🗑️ Delete message:', messageId);
  }
};

async function testSlippageError() {
  console.log('🧪 ========== TESTING SLIPPAGE ERROR REPRODUCTION ==========');
  
  try {
    // Initialize components
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    const mockTrading = { chainManager: chainManager };
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    
    await walletManager.initialize();
    
    const testChatId = '6537510183';
    const testMessageId = 123; // Valid message ID
    
    console.log('✅ Components initialized');
    
    // Step 1: Create token session
    console.log('\n1️⃣ Creating token session...');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await callbacks.buyTokenUI.handleContractAddress(contractMsg);
    
    // Get session ID
    const sessions = Array.from(callbacks.buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 2: Test custom slippage button (this will create reply message with ID 999)
    console.log('\n2️⃣ Testing custom slippage button...');
    const customSlippageCallback = {
      id: 'test_124',
      data: `slippage_custom_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    await callbacks.handle(customSlippageCallback);
    console.log('✅ Custom slippage button handled');
    
    // Step 3: Test reply message input (this should cause the error)
    console.log('\n3️⃣ Testing reply message input (this should cause error)...');
    const replyInputMsg = {
      chat: { id: testChatId },
      text: '2.5',
      message_id: 1000,
      reply_to_message: {
        message_id: 999 // This message ID will cause edit error
      }
    };
    
    console.log('🔍 About to process reply input...');
    
    try {
      await callbacks.handleCustomSlippageInput(replyInputMsg);
      console.log('❌ Expected error but got success!');
    } catch (error) {
      console.log('✅ Caught expected error:', error.message);
      console.log('🔍 Error details:', {
        name: error.name,
        code: error.code,
        message: error.message
      });
    }
    
    // Step 4: Test with valid message ID
    console.log('\n4️⃣ Testing with valid message ID...');
    
    // Reset state
    userStates.set(testChatId, {
      state: 'awaiting_custom_slippage',
      sessionId: sessionId,
      messageId: testMessageId, // Valid message ID
      replyMessageId: testMessageId // Valid reply message ID
    });
    
    const validReplyMsg = {
      chat: { id: testChatId },
      text: '2.5',
      message_id: 1001,
      reply_to_message: {
        message_id: testMessageId // Valid message ID
      }
    };
    
    try {
      await callbacks.handleCustomSlippageInput(validReplyMsg);
      console.log('✅ Valid message ID worked!');
    } catch (error) {
      console.log('❌ Error with valid message ID:', error.message);
    }
    
    console.log('\n🎯 ========== ANALYSIS ==========');
    console.log('The error likely occurs because:');
    console.log('1. Reply message gets created with a message ID');
    console.log('2. When user replies, bot tries to edit the original token message');
    console.log('3. But the message ID might be invalid or the message was deleted');
    console.log('4. This causes "message to edit not found" error');
    console.log('5. The error gets caught and shows "❌ Error setting slippage"');
    
  } catch (error) {
    console.error('\n❌ ========== TEST FAILED ==========');
    console.error('❌ Error:', error.message);
    console.error('❌ Stack:', error.stack);
  }
  
  process.exit(0);
}

testSlippageError();