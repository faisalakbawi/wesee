// Simple test to restart the bot
const { exec } = require('child_process');

console.log('Stopping existing bot...');
exec('pkill -f "node main-bot.js"', (error, stdout, stderr) => {
  setTimeout(() => {
    console.log('Starting bot...');
    exec('node main-bot.js', (error, stdout, stderr) => {
      if (error) {
        console.error('Error starting bot:', error);
        return;
      }
      console.log('Bot started successfully');
    });
  }, 2000);
});