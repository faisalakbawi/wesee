#!/bin/bash
pkill -f "node main-bot.js"
sleep 2
node main-bot.js