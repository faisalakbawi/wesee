/**
 * TEST BACK TO TOKEN BUTTON FIX
 * Verify the "🔙 Back to Token" button now works
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== MESSAGE EDITED ==========');
    console.log('📝 Text preview:', text.substring(0, 100) + '...');
    console.log('📝 Has reply_markup:', !!options.reply_markup);
    console.log('📝 Buttons count:', options.reply_markup?.inline_keyboard?.length || 0);
    console.log('📝 ===================================');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text) => {
    console.log('📤 Send message:', text.substring(0, 50));
    return { message_id: 124 };
  },
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ Callback answered:', options?.text || 'OK');
  }
};

async function testBackToTokenFix() {
  console.log('🧪 ========== TESTING BACK TO TOKEN FIX ==========');
  
  try {
    // Initialize components
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    const mockTrading = { chainManager: chainManager };
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    const buyTokenUI = callbacks.buyTokenUI;
    
    await walletManager.initialize();
    
    const testChatId = '6537510183';
    const testMessageId = 123;
    
    console.log('✅ Components initialized');
    
    // Step 1: Create token session
    console.log('\n1️⃣ Creating token session...');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await buyTokenUI.handleContractAddress(contractMsg);
    
    // Get session ID
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 2: Test slippage menu
    console.log('\n2️⃣ Opening slippage menu...');
    const slippageCallback = {
      id: 'test_123',
      data: `slippage_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    await callbacks.handle(slippageCallback);
    console.log('✅ Slippage menu opened');
    
    // Step 3: Test "Back to Token" button
    console.log('\n3️⃣ Testing "🔙 Back to Token" button...');
    const backToTokenCallback = {
      id: 'test_124',
      data: `back_to_token_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('🔙 Callback data:', backToTokenCallback.data);
    console.log('🔙 About to handle back to token...');
    
    try {
      await callbacks.handle(backToTokenCallback);
      console.log('✅ "Back to Token" button worked successfully!');
      
    } catch (backError) {
      console.error('❌ "Back to Token" button failed:', backError.message);
      console.error('❌ Error stack:', backError.stack);
      throw backError;
    }
    
    console.log('\n🎉 ========== TEST RESULTS ==========');
    console.log('✅ Token session creation: WORKING');
    console.log('✅ Slippage menu display: WORKING');
    console.log('✅ Back to Token button: WORKING');
    console.log('\n🚀 The "🔙 Back to Token" button is now FIXED!');
    
  } catch (error) {
    console.error('\n❌ ========== TEST FAILED ==========');
    console.error('❌ Error:', error.message);
    console.error('❌ Stack:', error.stack);
    
    console.error('\n🔧 DEBUGGING INFO:');
    console.error('🔧 This error indicates the fix needs more work');
    console.error('🔧 Check the returnToTokenPage method implementation');
  }
  
  process.exit(0);
}

testBackToTokenFix();