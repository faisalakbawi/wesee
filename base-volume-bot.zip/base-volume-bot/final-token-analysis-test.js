/**
 * FINAL TOKEN ANALYSIS TEST
 * Test both EVM and Solana token analysis
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.callbacks = [];
    this.deletedMessages = [];
    this.editedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 80)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.editedMessages.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 80)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function finalTokenAnalysisTest() {
  console.log('🧪 ========== FINAL TOKEN ANALYSIS TEST ==========');

  try {
    // Initialize all components
    console.log('🔧 Initializing components...');
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ All components initialized successfully');

    // Test 1: EVM Token (Base USDC)
    console.log('\n📍 TEST 1: EVM Token Analysis (Base USDC)');
    
    const evmMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      from: { id: testUserId }
    };

    console.log('🎯 Testing EVM token analysis...');
    await callbacks.buyTokenUI.handleContractAddress(evmMessage);
    
    // Check result
    const evmResult = mockBot.messages.find(msg => 
      msg.text && (msg.text.includes('Buy: USDC') || msg.text.includes('❌ Error analyzing token'))
    );
    
    if (evmResult && evmResult.text.includes('❌ Error analyzing token')) {
      console.log('❌ EVM FAILED: Still showing error');
      console.log('❌ Error:', evmResult.text);
    } else if (evmResult && evmResult.text.includes('Buy: USDC')) {
      console.log('✅ EVM SUCCESS: Token analysis working');
    } else {
      console.log('⚠️ EVM UNKNOWN: Unexpected result');
    }

    // Clear messages for next test
    mockBot.messages = [];

    // Test 2: Solana Token
    console.log('\n📍 TEST 2: Solana Token Analysis');
    
    const solanaMessage = {
      message_id: 1002,
      chat: { id: testUserId },
      text: '27U6sAYSDUJLpeCTTL5gW2wSwLGNRZRZKWJEqTWGbonk',
      from: { id: testUserId }
    };

    console.log('🎯 Testing Solana token analysis...');
    await callbacks.buyTokenUI.handleContractAddress(solanaMessage);
    
    // Check result
    const solanaResult = mockBot.messages.find(msg => 
      msg.text && (msg.text.includes('Buy: NFT') || msg.text.includes('❌ Error analyzing token'))
    );
    
    if (solanaResult && solanaResult.text.includes('❌ Error analyzing token')) {
      console.log('❌ SOLANA FAILED: Still showing error');
      console.log('❌ Error:', solanaResult.text);
    } else if (solanaResult && solanaResult.text.includes('Buy: NFT')) {
      console.log('✅ SOLANA SUCCESS: Token analysis working');
    } else {
      console.log('⚠️ SOLANA UNKNOWN: Unexpected result');
    }

    // Test 3: Invalid Address
    console.log('\n📍 TEST 3: Invalid Address Handling');
    
    const invalidMessage = {
      message_id: 1003,
      chat: { id: testUserId },
      text: 'invalid_address_123',
      from: { id: testUserId }
    };

    console.log('🎯 Testing invalid address handling...');
    await callbacks.buyTokenUI.handleContractAddress(invalidMessage);
    
    // Check result
    const invalidResult = mockBot.messages.find(msg => 
      msg.text && msg.text.includes('Invalid contract address format')
    );
    
    if (invalidResult) {
      console.log('✅ INVALID ADDRESS: Properly handled');
    } else {
      console.log('❌ INVALID ADDRESS: Not handled correctly');
    }

    // Summary
    console.log('\n📊 ========== TEST SUMMARY ==========');
    console.log(`📤 Total messages sent: ${mockBot.messages.length}`);
    
    // Count error messages
    const errorMessages = mockBot.messages.filter(msg => 
      msg.text && msg.text.includes('❌ Error analyzing token')
    );
    
    console.log(`❌ Error messages: ${errorMessages.length}`);
    
    if (errorMessages.length === 0) {
      console.log('\n🎉 ========== ALL TOKEN ANALYSIS WORKING! ==========');
      console.log('✅ EVM tokens: Working');
      console.log('✅ Solana tokens: Working');
      console.log('✅ Invalid addresses: Properly handled');
      return true;
    } else {
      console.log('\n❌ ========== SOME ISSUES REMAIN ==========');
      errorMessages.forEach(msg => console.log(`   - ${msg.text}`));
      return false;
    }

  } catch (error) {
    console.error('❌ TEST FAILED:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
finalTokenAnalysisTest().then(success => {
  if (success) {
    console.log('\n🚀 ========== BOT READY FOR PRODUCTION! ==========');
    console.log('✅ All token analysis features working correctly');
    console.log('✅ Both EVM and Solana tokens supported');
    console.log('✅ Custom slippage functionality working');
    console.log('🎯 Ready for live user testing!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== ISSUES NEED FIXING ==========');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});