/**
 * TEST SOLANA TOKEN ANALYSIS FIX
 * Verify that Solana token analysis now works
 */

const ChainManager = require('./chains/chain-manager');
const TokenAnalyzer = require('./trading/token-analyzer');

async function testSolanaFix() {
  console.log('🧪 ========== SOLANA TOKEN ANALYSIS FIX TEST ==========');
  
  try {
    // Initialize components
    console.log('🔧 Initializing components...');
    const chainManager = new ChainManager();
    const tokenAnalyzer = new TokenAnalyzer(chainManager);
    
    // Test with a Solana token address
    const testAddress = '27U6sAYSDUJLpeCTTL5gW2wSwLGNRZRZKWJEqTWGbonk';
    console.log('🎯 Testing with Solana token:', testAddress);
    
    console.log('🔍 Step 1: Detecting blockchain...');
    const blockchainType = tokenAnalyzer.detectBlockchain(testAddress);
    console.log('✅ Blockchain type:', blockchainType);
    
    if (blockchainType === 'solana') {
      console.log('🔍 Step 2: Analyzing Solana token...');
      try {
        const result = await tokenAnalyzer.analyzeSolanaToken(testAddress);
        console.log('✅ Solana analysis result:', result);
        
      } catch (solanaError) {
        console.error('❌ Solana analysis error:', solanaError.message);
        console.error('❌ Stack:', solanaError.stack);
      }
    }
    
    console.log('🔍 Step 3: Full analysis...');
    const fullAnalysis = await tokenAnalyzer.analyzeToken(testAddress);
    console.log('✅ Full analysis result:', fullAnalysis);
    
    if (fullAnalysis.success) {
      console.log('✅ SUCCESS: Solana token analysis working correctly');
      console.log('📊 Token data:', fullAnalysis.data);
      return true;
    } else {
      console.log('❌ FAILED: Solana token analysis error');
      console.log('❌ Error:', fullAnalysis.error);
      return false;
    }
    
  } catch (error) {
    console.error('❌ DEBUG ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

testSolanaFix().then(success => {
  if (success) {
    console.log('🎉 Solana token analysis fix successful!');
    process.exit(0);
  } else {
    console.log('💥 Solana token analysis still has issues');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});