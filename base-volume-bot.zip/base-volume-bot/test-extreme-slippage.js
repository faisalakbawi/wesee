/**
 * TEST WITH EXTREME SLIPPAGE
 * Test direct Uniswap V3 with very high slippage tolerance
 */

const { ethers } = require('ethers');

async function testExtremeSlippage() {
  console.log(`🌊 ========== TESTING EXTREME SLIPPAGE ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  // Addresses
  const UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  // Router ABI
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  const router = new ethers.Contract(UNISWAP_V3_ROUTER, routerABI, provider);
  
  // Test with different slippage levels
  const slippageTests = [
    { name: '50% slippage', slippage: 5000, minOut: '17.055' }, // 50% of 34.11
    { name: '70% slippage', slippage: 7000, minOut: '10.233' }, // 30% of 34.11
    { name: '90% slippage', slippage: 9000, minOut: '3.411' },  // 10% of 34.11
    { name: '99% slippage', slippage: 9900, minOut: '0.341' },  // 1% of 34.11
    { name: 'Almost zero', slippage: 9999, minOut: '0.001' }    // Almost nothing
  ];
  
  const ethAmountWei = ethers.utils.parseEther('0.001');
  const deadline = Math.floor(Date.now() / 1000) + 300;
  
  for (const test of slippageTests) {
    console.log(`\n🧪 Testing ${test.name}...`);
    
    const minOut = ethers.utils.parseUnits(test.minOut, 18);
    
    const swapParams = {
      tokenIn: WETH,
      tokenOut: TONY,
      fee: 10000, // 1% fee tier
      recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A',
      deadline: deadline,
      amountIn: ethAmountWei,
      amountOutMinimum: minOut,
      sqrtPriceLimitX96: 0
    };
    
    console.log(`  🛡️ Min Out: ${test.minOut} TONY`);
    console.log(`  📊 Slippage: ${test.slippage / 100}%`);
    
    try {
      const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
        value: ethAmountWei,
        from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
      });
      
      console.log(`  ✅ SUCCESS! Gas: ${gasEstimate.toString()}`);
      console.log(`  🎉 ${test.name} works!`);
      
      return {
        success: true,
        workingSlippage: test.slippage,
        workingMinOut: test.minOut,
        gasEstimate: gasEstimate.toString()
      };
      
    } catch (error) {
      console.log(`  ❌ Failed: ${error.message.split('(')[0]}`);
    }
  }
  
  console.log(`\n❌ All slippage tests failed!`);
  return { success: false, message: 'All slippage levels failed' };
}

// Also test if the pool exists and has liquidity
async function checkPoolStatus() {
  console.log(`\n🏊 ========== CHECKING POOL STATUS ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
  
  // Pool ABI for basic checks
  const poolABI = [
    "function token0() external view returns (address)",
    "function token1() external view returns (address)",
    "function fee() external view returns (uint24)",
    "function liquidity() external view returns (uint128)"
  ];
  
  try {
    const pool = new ethers.Contract(TONY_POOL, poolABI, provider);
    
    const token0 = await pool.token0();
    const token1 = await pool.token1();
    const fee = await pool.fee();
    const liquidity = await pool.liquidity();
    
    console.log(`📍 Pool: ${TONY_POOL}`);
    console.log(`🪙 Token0: ${token0}`);
    console.log(`🪙 Token1: ${token1}`);
    console.log(`💸 Fee: ${fee} (${fee / 10000}%)`);
    console.log(`💧 Liquidity: ${liquidity.toString()}`);
    
    if (liquidity.eq(0)) {
      console.log(`❌ POOL HAS NO LIQUIDITY!`);
      return { hasLiquidity: false };
    } else {
      console.log(`✅ Pool has liquidity`);
      return { hasLiquidity: true, liquidity: liquidity.toString() };
    }
    
  } catch (error) {
    console.log(`❌ Pool check failed: ${error.message}`);
    return { error: error.message };
  }
}

// Run both tests
async function runTests() {
  console.log(`🧪 ========== COMPREHENSIVE SLIPPAGE TESTS ==========`);
  
  // First check if pool exists and has liquidity
  const poolStatus = await checkPoolStatus();
  
  if (poolStatus.hasLiquidity === false) {
    console.log(`\n❌ CRITICAL: Pool has no liquidity! Cannot trade.`);
    return;
  }
  
  // Then test different slippage levels
  const result = await testExtremeSlippage();
  
  console.log(`\n📊 ========== FINAL RESULT ==========`);
  if (result.success) {
    console.log(`✅ SOLUTION FOUND!`);
    console.log(`🎯 Working slippage: ${result.workingSlippage / 100}%`);
    console.log(`🛡️ Working minOut: ${result.workingMinOut} TONY`);
    console.log(`⛽ Gas needed: ${result.gasEstimate}`);
    console.log(`\n💡 RECOMMENDATION: Use ${result.workingSlippage / 100}% slippage for TONY trades`);
  } else {
    console.log(`❌ NO SOLUTION FOUND`);
    console.log(`🔍 Even 99% slippage failed - there might be a deeper issue`);
    console.log(`💡 Possible causes:`);
    console.log(`   - Pool is paused or broken`);
    console.log(`   - Token has transfer restrictions`);
    console.log(`   - Router address is wrong`);
    console.log(`   - Fee tier is wrong`);
  }
}

runTests().catch(console.error);