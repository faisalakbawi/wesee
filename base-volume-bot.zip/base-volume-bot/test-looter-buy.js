#!/usr/bin/env node

/**
 * TEST LOOTER-STYLE BUY SYSTEM
 * Test the new Looter-style buying mechanism
 */

require('dotenv').config();
const LooterBuySystem = require('./chains/base/looter-buy-system');
const { ethers } = require('ethers');

async function testLooterBuy() {
  try {
    console.log('🔥 ========== TESTING LOOTER-STYLE BUY SYSTEM ==========');
    
    // Setup Base provider
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com'); // Free RPC for testing
    
    // Initialize Looter Buy System
    const looterBuy = new LooterBuySystem(provider);
    
    // Test tokens
    const testTokens = [
      {
        name: 'TONY Token (Micro Liquidity)',
        address: '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D',
        amount: 0.001 // Very small amount for testing
      },
      {
        name: 'USDC (High Liquidity)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      },
      {
        name: 'DAI (Medium Liquidity)',
        address: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb',
        amount: 0.001
      }
    ];
    
    for (const token of testTokens) {
      console.log(`\n🎯 Testing: ${token.name}`);
      console.log(`📍 Address: ${token.address}`);
      
      // 1. Check liquidity
      console.log('\n1️⃣ LIQUIDITY CHECK:');
      const liquidityInfo = await looterBuy.checkLiquidity(token.address);
      console.log('💧 Liquidity info:', liquidityInfo);
      
      // 2. Get expected tokens
      console.log('\n2️⃣ EXPECTED TOKENS:');
      const expectedTokens = await looterBuy.getExpectedTokens(
        token.address, 
        ethers.utils.parseEther(token.amount.toString())
      );
      console.log('📊 Expected tokens:', ethers.utils.formatUnits(expectedTokens, 18));
      
      // 3. Simulate buy (no actual transaction)
      console.log('\n3️⃣ SIMULATE BUY:');
      const simulation = await looterBuy.simulateBuy(token.address, token.amount);
      console.log('🧪 Simulation result:', simulation);
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ LOOTER-STYLE BUY SYSTEM TEST COMPLETE');
    console.log('💡 Ready for integration with the bot!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testLooterBuy();