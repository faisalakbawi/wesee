/**
 * FIX WALLET DECRYPTION
 * Diagnose and fix wallet decryption issues
 */

require('dotenv').config();
const Database = require('./database/database');
const crypto = require('crypto');

async function fixWalletDecryption() {
  console.log('🔧 ========== FIX WALLET DECRYPTION ==========');

  try {
    const db = new Database();
    await db.initialize();
    const client = await db.getClient();
    
    // Get the imported wallet that should have funds
    const walletQuery = `
      SELECT w.*, u.telegram_id, c.chain_id 
      FROM wallets w 
      JOIN users u ON w.user_id = u.id 
      JOIN chains c ON w.chain_id = c.id 
      WHERE LOWER(w.address) = LOWER($1)
    `;
    
    const importedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    const result = await client.query(walletQuery, [importedAddress]);
    
    if (result.rows.length === 0) {
      console.log('❌ Wallet not found in database');
      return;
    }
    
    const wallet = result.rows[0];
    console.log('✅ Found wallet in database:');
    console.log(`   User: ${wallet.telegram_id}`);
    console.log(`   Address: ${wallet.address}`);
    console.log(`   Chain: ${wallet.chain_id}`);
    console.log(`   Slot: ${wallet.wallet_slot}`);
    console.log(`   Imported: ${wallet.is_imported}`);
    
    // Try to decrypt with current encryption key
    console.log('\n🔍 Testing decryption with current key...');
    
    const currentEncryptionKey = process.env.ENCRYPTION_KEY;
    console.log(`Current encryption key: ${currentEncryptionKey}`);
    
    if (!currentEncryptionKey) {
      console.log('❌ No encryption key found in environment');
      return;
    }
    
    // Test decryption function
    function testDecrypt(encryptedText, encryptionKey) {
      try {
        const algorithm = 'aes-256-cbc';
        const key = crypto.scryptSync(encryptionKey, 'salt', 32);
        
        const textParts = encryptedText.split(':');
        const iv = Buffer.from(textParts.shift(), 'hex');
        const encrypted = textParts.join(':');
        
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        let decrypted = decipher.update(encrypted, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        return { success: true, decrypted };
      } catch (error) {
        return { success: false, error: error.message };
      }
    }
    
    // Test current private key decryption
    console.log('\n🔐 Testing private key decryption...');
    const privateKeyResult = testDecrypt(wallet.private_key, currentEncryptionKey);
    
    if (privateKeyResult.success) {
      console.log('✅ Private key decryption successful!');
      console.log(`   Decrypted key starts with: ${privateKeyResult.decrypted.substring(0, 10)}...`);
    } else {
      console.log('❌ Private key decryption failed:', privateKeyResult.error);
      
      // Try some common alternative keys
      console.log('\n🔄 Trying alternative encryption approaches...');
      
      // Try without the current key (maybe it was stored unencrypted)
      if (wallet.private_key.startsWith('0x') && wallet.private_key.length === 66) {
        console.log('💡 Private key might be stored unencrypted (starts with 0x and correct length)');
        console.log('🔧 Re-encrypting with current key...');
        
        // Re-encrypt with current key
        const algorithm = 'aes-256-cbc';
        const key = crypto.scryptSync(currentEncryptionKey, 'salt', 32);
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv(algorithm, key, iv);
        
        let encrypted = cipher.update(wallet.private_key, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const encryptedPrivateKey = iv.toString('hex') + ':' + encrypted;
        
        // Update in database
        const updateQuery = `
          UPDATE wallets 
          SET private_key = $1, updated_at = CURRENT_TIMESTAMP 
          WHERE id = $2
        `;
        
        await client.query(updateQuery, [encryptedPrivateKey, wallet.id]);
        console.log('✅ Private key re-encrypted and updated in database');
        
        // Test decryption again
        const retestResult = testDecrypt(encryptedPrivateKey, currentEncryptionKey);
        if (retestResult.success) {
          console.log('✅ Re-encryption successful! Private key can now be decrypted');
        } else {
          console.log('❌ Re-encryption failed:', retestResult.error);
        }
      }
    }
    
    // Test seed phrase decryption if exists
    if (wallet.seed_phrase) {
      console.log('\n🌱 Testing seed phrase decryption...');
      const seedResult = testDecrypt(wallet.seed_phrase, currentEncryptionKey);
      
      if (seedResult.success) {
        console.log('✅ Seed phrase decryption successful!');
      } else {
        console.log('❌ Seed phrase decryption failed:', seedResult.error);
        
        // Try to fix seed phrase too if it looks unencrypted
        const words = wallet.seed_phrase.split(' ');
        if (words.length === 12 || words.length === 24) {
          console.log('💡 Seed phrase might be stored unencrypted');
          console.log('🔧 Re-encrypting seed phrase...');
          
          const algorithm = 'aes-256-cbc';
          const key = crypto.scryptSync(currentEncryptionKey, 'salt', 32);
          const iv = crypto.randomBytes(16);
          const cipher = crypto.createCipheriv(algorithm, key, iv);
          
          let encrypted = cipher.update(wallet.seed_phrase, 'utf8', 'hex');
          encrypted += cipher.final('hex');
          const encryptedSeedPhrase = iv.toString('hex') + ':' + encrypted;
          
          // Update in database
          const updateQuery = `
            UPDATE wallets 
            SET seed_phrase = $1, updated_at = CURRENT_TIMESTAMP 
            WHERE id = $2
          `;
          
          await client.query(updateQuery, [encryptedSeedPhrase, wallet.id]);
          console.log('✅ Seed phrase re-encrypted and updated in database');
        }
      }
    }
    
    client.release();
    
    console.log('\n🧪 Testing wallet loading after fixes...');
    
    // Test loading the wallet again
    const WalletDBManager = require('./database/wallet-db-manager');
    const ChainManager = require('./chains/chain-manager');
    
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    const chainWallets = await walletManager.getChainWallets(wallet.telegram_id, wallet.chain_id);
    
    if (chainWallets && Object.keys(chainWallets).length > 0) {
      console.log('✅ Wallets loaded successfully after fixes!');
      
      Object.keys(chainWallets).forEach(slot => {
        const w = chainWallets[slot];
        const isTarget = w.address.toLowerCase() === importedAddress.toLowerCase();
        console.log(`   ${slot}: ${w.address} ${isTarget ? '🎯 TARGET' : ''}`);
        console.log(`     Balance: ${w.balance || '0'} ETH`);
        console.log(`     Imported: ${w.isImported ? 'YES' : 'NO'}`);
      });
      
      // Check if target wallet is now accessible
      const targetWallet = Object.values(chainWallets).find(w => 
        w.address.toLowerCase() === importedAddress.toLowerCase()
      );
      
      if (targetWallet) {
        console.log('\n🎉 SUCCESS! Target wallet is now accessible:');
        console.log(`   Address: ${targetWallet.address}`);
        console.log(`   Balance: ${targetWallet.balance || '0'} ETH`);
        console.log(`   Private Key: ${targetWallet.privateKey ? 'Available' : 'Missing'}`);
        console.log(`   Seed Phrase: ${targetWallet.seedPhrase ? 'Available' : 'Missing'}`);
        
        // Test balance fetching
        const balance = await walletManager.getWalletBalance(targetWallet.address, wallet.chain_id);
        console.log(`   Live Balance: ${balance} ETH`);
        
        if (parseFloat(balance) > 0) {
          console.log('🎉 PERFECT! Wallet has funds and is fully accessible!');
          console.log('✅ Ready for trading on Base chain!');
        }
      } else {
        console.log('❌ Target wallet still not accessible after fixes');
      }
      
    } else {
      console.log('❌ Wallets still not loading after fixes');
      console.log('💡 There might be other encryption issues');
    }

  } catch (error) {
    console.error('❌ Fix error:', error.message);
    console.error('❌ Stack:', error.stack);
  }
}

fixWalletDecryption().then(() => {
  console.log('\n🎉 Wallet decryption fix completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Fix failed:', error);
  process.exit(1);
});