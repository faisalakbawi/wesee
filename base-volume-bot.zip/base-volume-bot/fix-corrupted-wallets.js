/**
 * Fix Corrupted Wallets Script
 * Removes wallets with corrupted encryption data
 */

const Database = require('./database/database');

async function fixCorruptedWallets() {
  const db = new Database();
  
  try {
    await db.initialize();
    console.log('🔧 Starting corrupted wallet cleanup...');
    
    // Get all wallets
    const result = await db.query(`
      SELECT w.*, c.chain_id, u.telegram_id
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      JOIN users u ON w.user_id = u.id
      WHERE w.is_active = TRUE
      ORDER BY u.telegram_id, c.chain_id, w.wallet_slot
    `);
    
    console.log(`📊 Found ${result.rows.length} wallets to check`);
    
    let corruptedCount = 0;
    let fixedCount = 0;
    
    for (const wallet of result.rows) {
      try {
        // Try to decrypt the private key
        const decryptedKey = db.decrypt(wallet.private_key);
        
        if (!decryptedKey) {
          console.log(`❌ Corrupted wallet found: ${wallet.wallet_slot} on ${wallet.chain_id} for user ${wallet.telegram_id}`);
          
          // Soft delete the corrupted wallet
          await db.query(
            'UPDATE wallets SET is_active = FALSE WHERE id = $1',
            [wallet.id]
          );
          
          corruptedCount++;
          fixedCount++;
          
          console.log(`🗑️ Removed corrupted wallet: ${wallet.wallet_slot} on ${wallet.chain_id}`);
        } else {
          console.log(`✅ Wallet OK: ${wallet.wallet_slot} on ${wallet.chain_id} for user ${wallet.telegram_id}`);
        }
      } catch (error) {
        console.error(`❌ Error checking wallet ${wallet.wallet_slot}:`, error.message);
        corruptedCount++;
      }
    }
    
    console.log('\n🎯 Cleanup Summary:');
    console.log(`📊 Total wallets checked: ${result.rows.length}`);
    console.log(`❌ Corrupted wallets found: ${corruptedCount}`);
    console.log(`🗑️ Corrupted wallets removed: ${fixedCount}`);
    console.log(`✅ Valid wallets remaining: ${result.rows.length - corruptedCount}`);
    
    if (fixedCount > 0) {
      console.log('\n💡 Users can now regenerate wallets in the empty slots!');
    }
    
  } catch (error) {
    console.error('❌ Error during cleanup:', error.message);
  } finally {
    await db.close();
  }
}

// Run the cleanup
fixCorruptedWallets().then(() => {
  console.log('🎯 Cleanup completed!');
  process.exit(0);
}).catch(error => {
  console.error('❌ Cleanup failed:', error.message);
  process.exit(1);
});