/**
 * TEST SHORT GAS BUTTON TEXT
 * Verify the gas buttons now have shorter, more readable text
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 50)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 50)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function testShortGasButtons() {
  console.log('📝 ========== SHORT GAS BUTTON TEXT TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // Test 1: Check default gas button text
    console.log('\n📍 TEST 1: Default Gas Button Text');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find the token display with keyboard
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    if (tokenDisplay) {
      const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
      const gasButton = keyboard.flat().find(btn => btn.text.includes('⛽'));
      
      console.log('✅ Default gas button:', gasButton.text);
      
      if (gasButton.text === '⛽ Standard') {
        console.log('✅ PASS: Default gas button text is short and readable');
      } else {
        console.log('❌ FAIL: Expected "⛽ Standard", got:', gasButton.text);
        return false;
      }
    }

    // Test 2: Check gas menu button texts
    console.log('\n📍 TEST 2: Gas Menu Button Texts');
    
    const gasCallback = {
      id: 'test_callback_2',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_t1'
    };
    
    await callbacks.buyTokenUI.handleGasMenu(gasCallback);
    
    // Find the gas menu
    const gasMenu = mockBot.edits.find(edit => 
      edit.text && edit.text.includes('Gas Settings')
    );
    
    if (gasMenu && gasMenu.options.reply_markup) {
      const gasKeyboard = gasMenu.options.reply_markup.inline_keyboard;
      const buttons = gasKeyboard.flat();
      
      const standardBtn = buttons.find(btn => btn.text.includes('Standard'));
      const fastBtn = buttons.find(btn => btn.text.includes('Fast'));
      const instantBtn = buttons.find(btn => btn.text.includes('Instant'));
      const customBtn = buttons.find(btn => btn.text.includes('Custom'));
      const backBtn = buttons.find(btn => btn.text.includes('Back'));
      
      console.log('✅ Gas menu buttons:');
      console.log('  - Standard:', standardBtn?.text);
      console.log('  - Fast:', fastBtn?.text);
      console.log('  - Instant:', instantBtn?.text);
      console.log('  - Custom:', customBtn?.text);
      console.log('  - Back:', backBtn?.text);
      
      // Check if all buttons are short and readable
      const expectedButtons = [
        { button: standardBtn, expected: '🐌 Standard' },
        { button: fastBtn, expected: '🚀 Fast' },
        { button: instantBtn, expected: '⚡ Instant' },
        { button: customBtn, expected: '💡 Custom' },
        { button: backBtn, expected: '🔙 Back' }
      ];
      
      let allPassed = true;
      for (const { button, expected } of expectedButtons) {
        if (button?.text === expected) {
          console.log(`✅ PASS: ${expected}`);
        } else {
          console.log(`❌ FAIL: Expected "${expected}", got "${button?.text}"`);
          allPassed = false;
        }
      }
      
      if (!allPassed) return false;
    }

    // Test 3: Check gas button text after selection
    console.log('\n📍 TEST 3: Gas Button Text After Selection');
    
    const fastGasCallback = {
      id: 'test_callback_3',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'gas_set_t1_fast'
    };
    
    await callbacks.buyTokenUI.handleGasSet(fastGasCallback);
    
    // Find the updated token display
    const updatedDisplay = mockBot.edits[mockBot.edits.length - 1];
    if (updatedDisplay.options.reply_markup) {
      const updatedKeyboard = updatedDisplay.options.reply_markup.inline_keyboard;
      const updatedGasButton = updatedKeyboard.flat().find(btn => btn.text.includes('⛽'));
      
      console.log('✅ Updated gas button:', updatedGasButton.text);
      
      if (updatedGasButton.text === '⛽ Fast') {
        console.log('✅ PASS: Gas button updated to "⛽ Fast"');
      } else {
        console.log('❌ FAIL: Expected "⛽ Fast", got:', updatedGasButton.text);
        return false;
      }
    }

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log('✅ All gas button texts are short and readable!');
    console.log('✅ Default: "⛽ Standard"');
    console.log('✅ Menu options: "🐌 Standard", "🚀 Fast", "⚡ Instant", "💡 Custom"');
    console.log('✅ Back button: "🔙 Back"');
    console.log('✅ Dynamic updates: "⛽ Fast" after selection');
    
    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    return false;
  }
}

// Run the test
testShortGasButtons().then(success => {
  if (success) {
    console.log('\n🎉 ========== SHORT GAS BUTTON TEST PASSED! ==========');
    console.log('✅ All gas buttons now have short, readable text');
    console.log('✅ Users can easily see what they\'re clicking');
    console.log('✅ Button text is clean and professional');
    console.log('🚀 Gas buttons are now user-friendly!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== SHORT GAS BUTTON TEST FAILED ==========');
    console.log('❌ Some button texts are still too long');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});