#!/usr/bin/env node

/**
 * CREATE TEST WALLETS
 * Generate additional wallets for testing wallet selection
 */

require('dotenv').config();
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function createTestWallets() {
  const chainManager = new ChainManager();
  const walletManager = new WalletDBManager(chainManager);
  
  try {
    await walletManager.initialize();
    console.log('🔧 ========== CREATING TEST WALLETS ==========');
    
    const userId = 6537510183; // Your Telegram ID
    const chain = 'base';
    
    // Generate W2, W3, W4, W5 for Base chain
    const slotsToCreate = ['W2', 'W3', 'W4', 'W5'];
    
    for (const slot of slotsToCreate) {
      try {
        console.log(`\n🔑 Generating ${slot} for ${chain}...`);
        
        const result = await walletManager.generateWallet(userId, slot, chain);
        console.log(`✅ ${slot} created: ${result.address}`);
        
      } catch (error) {
        console.error(`❌ Failed to create ${slot}:`, error.message);
      }
    }
    
    // Show final wallet state
    console.log('\n📊 FINAL WALLET STATE:');
    const chainWallets = await walletManager.getChainWallets(userId, chain);
    Object.keys(chainWallets).forEach(slot => {
      const wallet = chainWallets[slot];
      console.log(`   ${slot}: ${wallet.address} (${wallet.isImported ? 'IMPORTED' : 'GENERATED'})`);
    });
    
    console.log('\n✅ Test wallets created successfully!');
    console.log('💡 Now you can test wallet selection with multiple wallets');
    
  } catch (error) {
    console.error('❌ Failed to create test wallets:', error.message);
  } finally {
    await walletManager.close();
  }
}

// Run wallet creation
createTestWallets();