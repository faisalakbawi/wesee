/**
 * TEST REPLY MESSAGE CUSTOM SLIPPAGE
 * Test the new reply-based custom slippage system
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot that simulates Telegram reply behavior
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== MESSAGE EDITED ==========');
    console.log('📝 Text preview:', text.substring(0, 100) + '...');
    if (options.reply_markup?.inline_keyboard) {
      console.log('📝 Buttons:');
      options.reply_markup.inline_keyboard.forEach((row, i) => {
        const buttonTexts = row.map(btn => `"${btn.text}"`).join(' | ');
        console.log(`     Row ${i + 1}: ${buttonTexts}`);
      });
    }
    console.log('📝 ===================================');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text, options) => {
    console.log('📤 ========== NEW MESSAGE SENT ==========');
    console.log('📤 To:', chatId);
    console.log('📤 Text:', text.substring(0, 100) + '...');
    console.log('📤 Has force_reply:', !!options?.reply_markup?.force_reply);
    console.log('📤 ====================================');
    return { message_id: 999 }; // This will be our reply message ID
  },
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ Callback answered:', options?.text || 'OK');
  },
  deleteMessage: async (chatId, messageId) => {
    console.log('🗑️ Message deleted:', messageId);
  }
};

async function testReplySlippage() {
  console.log('🧪 ========== TESTING REPLY MESSAGE CUSTOM SLIPPAGE ==========');
  
  try {
    // Initialize components
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    const mockTrading = { chainManager: chainManager };
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    const buyTokenUI = callbacks.buyTokenUI;
    
    await walletManager.initialize();
    
    const testChatId = '6537510183';
    const testMessageId = 123;
    
    console.log('✅ Components initialized');
    
    // Step 1: Create token session
    console.log('\n1️⃣ Creating token session...');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await buyTokenUI.handleContractAddress(contractMsg);
    
    // Get session ID
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 2: Test custom slippage button (should send reply message)
    console.log('\n2️⃣ Testing "💡 Custom %" button...');
    const customSlippageCallback = {
      id: 'test_124',
      data: `slippage_custom_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('🔍 Custom slippage callback data:', customSlippageCallback.data);
    
    await callbacks.handle(customSlippageCallback);
    console.log('✅ Custom slippage button should have sent reply message');
    
    // Step 3: Check user state
    console.log('\n3️⃣ Checking user state...');
    const userState = userStates.get(testChatId);
    console.log('🔍 User state:', userState);
    
    if (!userState || userState.state !== 'awaiting_custom_slippage') {
      throw new Error('User state not set correctly for custom slippage input');
    }
    
    if (!userState.replyMessageId) {
      throw new Error('Reply message ID not stored in user state');
    }
    
    console.log('✅ User state set correctly with reply message ID');
    
    // Step 4: Test reply message input
    console.log('\n4️⃣ Testing reply message input...');
    const replyInputMsg = {
      chat: { id: testChatId },
      text: '2.5',
      message_id: 1000,
      reply_to_message: {
        message_id: userState.replyMessageId // Reply to our custom slippage message
      }
    };
    
    console.log('🔍 Reply input:', replyInputMsg.text);
    console.log('🔍 Replying to message ID:', replyInputMsg.reply_to_message.message_id);
    
    await callbacks.handleCustomSlippageInput(replyInputMsg);
    console.log('✅ Reply message input processed');
    
    // Step 5: Verify slippage was set
    console.log('\n5️⃣ Verifying slippage was set...');
    const currentSlippage = buyTokenUI.getTokenSlippage(testChatId, sessionId);
    console.log('🔍 Current slippage after setting custom:', currentSlippage + '%');
    
    if (currentSlippage === 2.5) {
      console.log('✅ Custom slippage set correctly via reply!');
    } else {
      throw new Error(`Expected 2.5%, got ${currentSlippage}%`);
    }
    
    // Step 6: Test invalid reply
    console.log('\n6️⃣ Testing invalid reply...');
    
    // Reset state for testing
    userStates.set(testChatId, {
      state: 'awaiting_custom_slippage',
      sessionId: sessionId,
      messageId: testMessageId,
      replyMessageId: 999
    });
    
    const invalidReplyMsg = {
      chat: { id: testChatId },
      text: 'abc',
      message_id: 1001,
      reply_to_message: {
        message_id: 999 // Reply to our custom slippage message
      }
    };
    
    await callbacks.handleCustomSlippageInput(invalidReplyMsg);
    console.log('✅ Invalid reply handled correctly');
    
    // Step 7: Test non-reply message (should be ignored)
    console.log('\n7️⃣ Testing non-reply message...');
    
    // Reset state for testing
    userStates.set(testChatId, {
      state: 'awaiting_custom_slippage',
      sessionId: sessionId,
      messageId: testMessageId,
      replyMessageId: 999
    });
    
    const nonReplyMsg = {
      chat: { id: testChatId },
      text: '5.0',
      message_id: 1002
      // No reply_to_message - should be ignored or handled differently
    };
    
    await callbacks.handleCustomSlippageInput(nonReplyMsg);
    console.log('✅ Non-reply message handled');
    
    console.log('\n🎉 ========== TEST RESULTS ==========');
    console.log('✅ Reply message creation: WORKING');
    console.log('✅ User state with reply ID: WORKING');
    console.log('✅ Reply message processing: WORKING');
    console.log('✅ Slippage value setting: WORKING');
    console.log('✅ Invalid reply handling: WORKING');
    console.log('✅ Non-reply message handling: WORKING');
    console.log('\n🚀 REPLY-BASED CUSTOM SLIPPAGE IS WORKING!');
    
    console.log('\n📋 ========== HOW IT WORKS NOW ==========');
    console.log('1. Click "💡 Custom %" button');
    console.log('2. Bot sends a message with force_reply');
    console.log('3. User clicks "Reply" on that message');
    console.log('4. User types their percentage (e.g., "2.5")');
    console.log('5. Bot processes the reply and sets slippage');
    console.log('6. Bot cleans up messages and shows confirmation');
    
  } catch (error) {
    console.error('\n❌ ========== TEST FAILED ==========');
    console.error('❌ Error:', error.message);
    console.error('❌ Stack:', error.stack);
  }
  
  process.exit(0);
}

testReplySlippage();