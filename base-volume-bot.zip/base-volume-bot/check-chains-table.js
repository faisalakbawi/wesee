/**
 * CHECK CHAINS TABLE
 * Check what chains are actually stored in the database
 */

const { Pool } = require('pg');

async function checkChainsTable() {
  console.log('🔗 ========== CHECK CHAINS TABLE ==========');

  const pool = new Pool({
    user: process.env.DB_USER || 'faisal',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'looter_ai_clone',
    password: process.env.DB_PASSWORD || '',
    port: process.env.DB_PORT || 5432,
  });

  try {
    console.log('🔍 Checking chains table...');
    
    // Get all chains
    const chainsQuery = 'SELECT * FROM chains ORDER BY name';
    const chainsResult = await pool.query(chainsQuery);
    
    console.log(`📊 Found ${chainsResult.rows.length} chains in database:`);
    
    chainsResult.rows.forEach(chain => {
      console.log(`\n🔗 Chain: ${chain.name}`);
      console.log(`   ID: ${chain.id}`);
      console.log(`   Chain ID: ${chain.chain_id}`);
      console.log(`   Symbol: ${chain.symbol}`);
      console.log(`   Network ID: ${chain.network_id}`);
      console.log(`   Active: ${chain.is_active}`);
      
      if (chain.chain_id === 'base') {
        console.log(`   🎯 THIS IS THE BASE CHAIN!`);
      }
    });
    
    // Test the specific query that's failing
    console.log(`\n🔍 Testing the failing query...`);
    const testQuery = 'SELECT id FROM chains WHERE chain_id = $1';
    const testResult = await pool.query(testQuery, ['base']);
    
    console.log(`📊 Query result for 'base':`);
    if (testResult.rows.length > 0) {
      console.log(`   ✅ Found: ${testResult.rows[0].id}`);
    } else {
      console.log(`   ❌ Not found!`);
      console.log(`   💡 This explains why wallet import is failing`);
    }
    
    // Check what chain_id values exist
    console.log(`\n📋 All chain_id values in database:`);
    const chainIdsQuery = 'SELECT chain_id FROM chains ORDER BY chain_id';
    const chainIdsResult = await pool.query(chainIdsQuery);
    
    chainIdsResult.rows.forEach(row => {
      console.log(`   - ${row.chain_id}`);
    });

  } catch (error) {
    console.error('❌ Database error:', error.message);
  } finally {
    await pool.end();
  }
}

checkChainsTable().then(() => {
  console.log('\n🎉 Chains table check completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Chains check failed:', error);
  process.exit(1);
});