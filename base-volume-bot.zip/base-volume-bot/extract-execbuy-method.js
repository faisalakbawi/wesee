/**
 * EXTRACT EXECBUY METHOD
 * Analyze the sniper contract to understand the exact execBuy function signature and logic
 */

const { ethers } = require('ethers');

class ExecBuyAnalyzer {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
    this.SNIPER_CONTRACT = '0xe111b0C3605aDc45CFb0CD75E5543F63CC3ec425';
    this.FAILED_TX = '0x5dee64ae5a41226c408d5bda84305b61cb9510ca5c7b9a79fb41d2499c054676';
  }

  /**
   * DECODE THE FAILED TRANSACTION INPUT DATA
   */
  async decodeFailedTransactionData() {
    console.log(`🔍 ========== DECODING FAILED TRANSACTION DATA ==========`);
    
    try {
      const tx = await this.provider.getTransaction(this.FAILED_TX);
      const inputData = tx.data;
      
      console.log(`📍 Transaction: ${this.FAILED_TX}`);
      console.log(`📋 Input Data: ${inputData}`);
      console.log(`📏 Data Length: ${inputData.length} characters`);
      
      // Extract function selector
      const functionSelector = inputData.slice(0, 10);
      console.log(`🔧 Function Selector: ${functionSelector}`);
      
      if (functionSelector === '0xc981cc3c') {
        console.log(`✅ Confirmed: This is execBuy() function`);
      }
      
      // Remove function selector and decode parameters
      const paramData = inputData.slice(10);
      console.log(`📊 Parameter Data: ${paramData}`);
      console.log(`📏 Parameter Length: ${paramData.length} characters (${paramData.length / 64} parameters)`);
      
      // Split into 32-byte chunks (64 hex characters each)
      const chunks = [];
      for (let i = 0; i < paramData.length; i += 64) {
        const chunk = paramData.slice(i, i + 64);
        chunks.push('0x' + chunk);
      }
      
      console.log(`\n📊 Parameter Chunks (${chunks.length} total):`);
      chunks.forEach((chunk, index) => {
        console.log(`  [${index}]: ${chunk}`);
        
        // Try to interpret as different types
        try {
          const asNumber = ethers.BigNumber.from(chunk);
          const asAddress = '0x' + chunk.slice(-40);
          
          console.log(`       Number: ${asNumber.toString()}`);
          console.log(`       ETH: ${ethers.utils.formatEther(asNumber)}`);
          console.log(`       Address: ${asAddress}`);
        } catch (e) {
          console.log(`       (Invalid number)`);
        }
      });
      
      return {
        functionSelector,
        chunks,
        rawData: inputData
      };
      
    } catch (error) {
      console.log(`❌ Failed to decode transaction: ${error.message}`);
      return null;
    }
  }

  /**
   * ANALYZE CONTRACT BYTECODE FOR EXECBUY FUNCTION
   */
  async analyzeContractBytecode() {
    console.log(`\n🔍 ========== ANALYZING CONTRACT BYTECODE ==========`);
    
    try {
      const code = await this.provider.getCode(this.SNIPER_CONTRACT);
      console.log(`📋 Contract Code Length: ${code.length} bytes`);
      
      // Look for execBuy function selector in bytecode
      const execBuySelector = 'c981cc3c';
      const selectorIndex = code.indexOf(execBuySelector);
      
      if (selectorIndex !== -1) {
        console.log(`✅ Found execBuy selector at position: ${selectorIndex}`);
        
        // Extract surrounding bytecode
        const start = Math.max(0, selectorIndex - 100);
        const end = Math.min(code.length, selectorIndex + 200);
        const surrounding = code.slice(start, end);
        
        console.log(`📊 Surrounding bytecode:`);
        console.log(`${surrounding}`);
      } else {
        console.log(`❌ execBuy selector not found in bytecode`);
      }
      
      // Look for common patterns
      console.log(`\n🔍 Looking for common patterns...`);
      
      // Look for other function selectors
      const commonSelectors = {
        'owner()': '8da5cb5b',
        'transfer(address,uint256)': 'a9059cbb',
        'approve(address,uint256)': '095ea7b3',
        'balanceOf(address)': '70a08231',
        'swapExactETHForTokens': '7ff36ab5',
        'swapExactTokensForETH': '18cbafe5'
      };
      
      for (const [name, selector] of Object.entries(commonSelectors)) {
        if (code.includes(selector)) {
          console.log(`✅ Found ${name}: ${selector}`);
        }
      }
      
      return {
        codeLength: code.length,
        hasExecBuy: selectorIndex !== -1,
        bytecode: code
      };
      
    } catch (error) {
      console.log(`❌ Failed to analyze bytecode: ${error.message}`);
      return null;
    }
  }

  /**
   * TRY TO CALL CONTRACT FUNCTIONS TO UNDERSTAND INTERFACE
   */
  async probeContractInterface() {
    console.log(`\n🔍 ========== PROBING CONTRACT INTERFACE ==========`);
    
    const commonFunctions = [
      { name: 'owner()', selector: '0x8da5cb5b', params: [] },
      { name: 'name()', selector: '0x06fdde03', params: [] },
      { name: 'symbol()', selector: '0x95d89b41', params: [] },
      { name: 'decimals()', selector: '0x313ce567', params: [] },
      { name: 'totalSupply()', selector: '0x18160ddd', params: [] }
    ];
    
    const results = {};
    
    for (const func of commonFunctions) {
      try {
        console.log(`🧪 Testing ${func.name}...`);
        
        const result = await this.provider.call({
          to: this.SNIPER_CONTRACT,
          data: func.selector
        });
        
        console.log(`  ✅ ${func.name}: ${result}`);
        
        // Try to decode result
        if (result !== '0x') {
          try {
            if (func.name === 'owner()') {
              const owner = '0x' + result.slice(-40);
              console.log(`     Decoded owner: ${owner}`);
              results[func.name] = owner;
            } else if (func.name.includes('Supply') || func.name.includes('decimals')) {
              const number = ethers.BigNumber.from(result);
              console.log(`     Decoded number: ${number.toString()}`);
              results[func.name] = number.toString();
            } else {
              // Try as string
              try {
                const decoded = ethers.utils.toUtf8String(result);
                console.log(`     Decoded string: "${decoded}"`);
                results[func.name] = decoded;
              } catch (e) {
                results[func.name] = result;
              }
            }
          } catch (e) {
            results[func.name] = result;
          }
        }
        
      } catch (error) {
        console.log(`  ❌ ${func.name}: ${error.message.split('(')[0]}`);
      }
    }
    
    return results;
  }

  /**
   * REVERSE ENGINEER EXECBUY PARAMETERS FROM FAILED TX
   */
  reverseEngineerExecBuy(chunks) {
    console.log(`\n🧠 ========== REVERSE ENGINEERING EXECBUY ==========`);
    
    if (!chunks || chunks.length === 0) {
      console.log(`❌ No parameter chunks to analyze`);
      return null;
    }
    
    console.log(`📊 Analyzing ${chunks.length} parameters...`);
    
    // Common patterns in DeFi functions:
    // execBuy(uint256 amountIn, uint256 amountOutMin, address[] path, address to, uint256 deadline)
    // execBuy(address token, uint256 amountETH, uint256 minTokens, bytes data)
    
    const analysis = {};
    
    chunks.forEach((chunk, index) => {
      const bn = ethers.BigNumber.from(chunk);
      const address = '0x' + chunk.slice(-40);
      
      console.log(`\n[${index}] ${chunk}`);
      console.log(`    As Number: ${bn.toString()}`);
      console.log(`    As ETH: ${ethers.utils.formatEther(bn)}`);
      console.log(`    As Address: ${address}`);
      
      // Analyze patterns
      if (bn.eq(ethers.utils.parseEther('0.001'))) {
        console.log(`    🎯 MATCH: This is 0.001 ETH (our input amount)`);
        analysis[`param_${index}`] = { type: 'ETH_AMOUNT', value: '0.001 ETH' };
      } else if (bn.gt(ethers.utils.parseEther('1000'))) {
        console.log(`    🎯 POSSIBLE: Large number, could be token amount or min output`);
        analysis[`param_${index}`] = { type: 'LARGE_NUMBER', value: ethers.utils.formatEther(bn) };
      } else if (address.length === 42 && address !== '0x0000000000000000000000000000000000000000') {
        console.log(`    🎯 POSSIBLE: Valid address`);
        analysis[`param_${index}`] = { type: 'ADDRESS', value: address };
      } else if (bn.lt(ethers.utils.parseEther('1')) && bn.gt(0)) {
        console.log(`    🎯 POSSIBLE: Small number, could be fee or percentage`);
        analysis[`param_${index}`] = { type: 'SMALL_NUMBER', value: bn.toString() };
      }
    });
    
    // Try to match against common DeFi patterns
    console.log(`\n🔍 Pattern Analysis:`);
    
    if (chunks.length >= 5) {
      console.log(`📊 Likely pattern: execBuy(amountIn, amountOutMin, token, recipient, deadline, ...)`);
    } else if (chunks.length >= 3) {
      console.log(`📊 Likely pattern: execBuy(token, amountETH, minTokens, ...)`);
    }
    
    return analysis;
  }

  /**
   * GENERATE EXECBUY FUNCTION SIGNATURE
   */
  generateFunctionSignature(analysis) {
    console.log(`\n🛠️ ========== GENERATING FUNCTION SIGNATURE ==========`);
    
    // Based on the analysis, try to construct the most likely signature
    const signatures = [
      'execBuy(address token, uint256 amountETH, uint256 minTokens, bytes data)',
      'execBuy(uint256 amountIn, uint256 amountOutMin, address[] path, address to, uint256 deadline)',
      'execBuy(address tokenIn, address tokenOut, uint256 amountIn, uint256 amountOutMin, uint256 deadline)',
      'execBuy(bytes data)',
      'execBuy(uint256[] amounts, address[] tokens, bytes data)'
    ];
    
    console.log(`🎯 Most likely signatures:`);
    signatures.forEach((sig, index) => {
      const hash = ethers.utils.keccak256(ethers.utils.toUtf8Bytes(sig));
      const selector = hash.slice(0, 10);
      
      console.log(`${index + 1}. ${sig}`);
      console.log(`   Selector: ${selector} ${selector === '0xc981cc3c' ? '✅ MATCH!' : ''}`);
    });
    
    return signatures;
  }

  /**
   * RUN COMPLETE ANALYSIS
   */
  async runCompleteAnalysis() {
    console.log(`🧠 ========== COMPLETE EXECBUY ANALYSIS ==========`);
    console.log(`🕐 Started at: ${new Date().toISOString()}`);
    
    // Step 1: Decode failed transaction
    const txData = await this.decodeFailedTransactionData();
    
    // Step 2: Analyze contract bytecode
    const bytecodeData = await this.analyzeContractBytecode();
    
    // Step 3: Probe contract interface
    const interfaceData = await this.probeContractInterface();
    
    // Step 4: Reverse engineer execBuy
    let analysis = null;
    if (txData && txData.chunks) {
      analysis = this.reverseEngineerExecBuy(txData.chunks);
    }
    
    // Step 5: Generate function signatures
    const signatures = this.generateFunctionSignature(analysis);
    
    console.log(`\n📊 ========== FINAL EXECBUY ANALYSIS ==========`);
    console.log(`🔧 Function Selector: 0xc981cc3c`);
    console.log(`📊 Parameter Count: ${txData?.chunks?.length || 'Unknown'}`);
    console.log(`👤 Contract Owner: ${interfaceData?.['owner()'] || 'Unknown'}`);
    console.log(`📋 Contract Size: ${bytecodeData?.codeLength || 'Unknown'} bytes`);
    
    if (analysis) {
      console.log(`\n🎯 Parameter Analysis:`);
      Object.entries(analysis).forEach(([param, data]) => {
        console.log(`  ${param}: ${data.type} = ${data.value}`);
      });
    }
    
    console.log(`\n✅ Analysis Complete!`);
    
    return {
      transactionData: txData,
      bytecodeData,
      interfaceData,
      parameterAnalysis: analysis,
      possibleSignatures: signatures
    };
  }
}

// Run the analysis
if (require.main === module) {
  const analyzer = new ExecBuyAnalyzer();
  
  analyzer.runCompleteAnalysis()
    .then(results => {
      console.log(`\n🎯 ========== EXECBUY METHOD EXTRACTED ==========`);
      console.log(`Status: Analysis complete`);
      console.log(`Function: execBuy() with selector 0xc981cc3c`);
      console.log(`Parameters: ${results.transactionData?.chunks?.length || 'Unknown'} detected`);
    })
    .catch(error => {
      console.error(`❌ Analysis failed:`, error);
    });
}

module.exports = ExecBuyAnalyzer;