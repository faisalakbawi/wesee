/**
 * TEST RUNNER - READY FOR YOUR REAL TESTING
 * Use this to test the production solution with your actual private key
 */

const { ethers } = require('ethers');
const ProductionReadySolution = require('./PRODUCTION_READY_SOLUTION');

class TestRunner {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
    this.solution = new ProductionReadySolution(this.provider);
    
    // Test tokens (add more as needed)
    this.testTokens = {
      TONY: '0x36a947baa2492c72bf9d3307117237e79145a87d',
      // Add more tokens here
    };
  }

  /**
   * HEALTH CHECK FIRST
   */
  async runHealthCheck() {
    console.log(`🏥 ========== HEALTH CHECK ==========`);
    const health = await this.solution.healthCheck();
    
    if (Object.values(health).every(check => check)) {
      console.log(`✅ All systems healthy - ready for testing!`);
      return true;
    } else {
      console.log(`❌ Health issues detected - check your setup`);
      return false;
    }
  }

  /**
   * TEST WITH YOUR PRIVATE KEY
   */
  async testWithRealKey(privateKey, tokenSymbol = 'TONY', ethAmount = 0.001, slippage = 30) {
    console.log(`🧪 ========== REAL TEST WITH YOUR PRIVATE KEY ==========`);
    console.log(`🎯 Token: ${tokenSymbol}`);
    console.log(`💰 Amount: ${ethAmount} ETH`);
    console.log(`🛡️ Slippage: ${slippage}%`);
    console.log(`🕐 Time: ${new Date().toISOString()}`);
    
    try {
      // Validate private key format
      if (!privateKey || privateKey.length !== 66 || !privateKey.startsWith('0x')) {
        throw new Error('Private key must be 66 characters starting with 0x');
      }
      
      // Get token address
      const tokenAddress = this.testTokens[tokenSymbol];
      if (!tokenAddress) {
        throw new Error(`Unknown token: ${tokenSymbol}. Available: ${Object.keys(this.testTokens).join(', ')}`);
      }
      
      // Show wallet info
      const wallet = new ethers.Wallet(privateKey, this.provider);
      const balance = await wallet.getBalance();
      
      console.log(`\n👤 Wallet Information:`);
      console.log(`  📍 Address: ${wallet.address}`);
      console.log(`  💰 Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      if (balance.lt(ethers.utils.parseEther(ethAmount.toString()))) {
        throw new Error(`Insufficient balance! Need ${ethAmount} ETH, have ${ethers.utils.formatEther(balance)} ETH`);
      }
      
      console.log(`  ✅ Balance sufficient for trade`);
      
      // Execute the trade
      console.log(`\n🚀 Executing trade...`);
      console.log(`⚠️  THIS WILL SPEND REAL ETH!`);
      console.log(`⏳ Processing...`);
      
      const result = await this.solution.execBuy(
        privateKey,
        tokenAddress,
        ethAmount,
        slippage
      );
      
      console.log(`\n📊 ========== TRADE RESULT ==========`);
      
      if (result.success) {
        console.log(`🎉 TRADE SUCCESSFUL!`);
        console.log(`📍 Transaction Hash: ${result.txHash}`);
        console.log(`⛽ Gas Used: ${result.gasUsed}`);
        console.log(`📤 Expected Output: ${result.expectedOutput}`);
        console.log(`🛡️ Min Output: ${result.minOutput}`);
        console.log(`🔗 Basescan: https://basescan.org/tx/${result.txHash}`);
        console.log(`📊 Block: ${result.blockNumber}`);
        
        // Check final balance
        const newBalance = await wallet.getBalance();
        const ethSpent = balance.sub(newBalance);
        console.log(`💰 ETH Spent: ${ethers.utils.formatEther(ethSpent)} ETH`);
        console.log(`💰 New Balance: ${ethers.utils.formatEther(newBalance)} ETH`);
        
      } else {
        console.log(`❌ TRADE FAILED`);
        console.log(`🔧 Error: ${result.error}`);
        console.log(`📋 Error Code: ${result.errorCode}`);
        console.log(`🕐 Time: ${result.timestamp}`);
      }
      
      return result;
      
    } catch (error) {
      console.log(`💥 Test failed: ${error.message}`);
      return {
        success: false,
        error: error.message,
        testError: true
      };
    }
  }

  /**
   * DRY RUN - TEST WITHOUT SPENDING ETH
   */
  async dryRun(privateKey, tokenSymbol = 'TONY', ethAmount = 0.001, slippage = 30) {
    console.log(`🧪 ========== DRY RUN (NO ETH SPENT) ==========`);
    console.log(`💡 This will test everything except the final transaction`);
    
    try {
      const wallet = new ethers.Wallet(privateKey, this.provider);
      const tokenAddress = this.testTokens[tokenSymbol];
      const ethAmountWei = ethers.utils.parseEther(ethAmount.toString());
      
      // Check balance
      const balance = await wallet.getBalance();
      console.log(`👤 Wallet: ${wallet.address}`);
      console.log(`💰 Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      if (balance.lt(ethAmountWei)) {
        console.log(`⚠️ Insufficient balance for real trade`);
      } else {
        console.log(`✅ Balance sufficient for real trade`);
      }
      
      // Test price calculation
      const config = this.solution.getTokenConfig(tokenAddress);
      const { expectedOutput } = this.solution.calculateExpectedOutput(ethAmountWei, tokenAddress);
      const minOut = expectedOutput.mul(10000 - (slippage * 100)).div(10000);
      
      console.log(`📊 Price Calculation:`);
      console.log(`  📈 Rate: ${config.ratePerEth} ${config.symbol} per ETH`);
      console.log(`  📤 Expected: ${ethers.utils.formatEther(expectedOutput)} ${config.symbol}`);
      console.log(`  🛡️ Min Out: ${ethers.utils.formatEther(minOut)} ${config.symbol}`);
      
      // Test gas estimation
      const router = new ethers.Contract(
        this.solution.SWAP_ROUTER_02,
        this.solution.routerABI,
        wallet
      );
      
      const swapParams = {
        tokenIn: this.solution.WETH,
        tokenOut: tokenAddress,
        fee: config.fee,
        recipient: wallet.address,
        deadline: Math.floor(Date.now() / 1000) + 300,
        amountIn: ethAmountWei,
        amountOutMinimum: 1, // Minimal for testing
        sqrtPriceLimitX96: 0
      };
      
      console.log(`⛽ Testing gas estimation...`);
      
      try {
        const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
          value: ethAmountWei
        });
        
        console.log(`✅ Gas estimation successful: ${gasEstimate.toString()}`);
        console.log(`💰 Estimated gas cost: ~${ethers.utils.formatEther(gasEstimate.mul(ethers.utils.parseUnits('1', 'gwei')))} ETH`);
        
        console.log(`\n🎯 DRY RUN RESULT: SUCCESS!`);
        console.log(`✅ All checks passed`);
        console.log(`🚀 Ready for real transaction`);
        
        return {
          success: true,
          dryRun: true,
          gasEstimate: gasEstimate.toString(),
          expectedOutput: ethers.utils.formatEther(expectedOutput),
          minOutput: ethers.utils.formatEther(minOut)
        };
        
      } catch (gasError) {
        console.log(`❌ Gas estimation failed: ${gasError.message}`);
        console.log(`💡 This might indicate:`);
        console.log(`  - Pool liquidity issues`);
        console.log(`  - Wrong fee tier`);
        console.log(`  - Network congestion`);
        
        return {
          success: false,
          dryRun: true,
          error: gasError.message
        };
      }
      
    } catch (error) {
      console.log(`❌ Dry run failed: ${error.message}`);
      return {
        success: false,
        dryRun: true,
        error: error.message
      };
    }
  }

  /**
   * INTERACTIVE TEST MENU
   */
  async interactiveTest() {
    console.log(`🎯 ========== INTERACTIVE TEST MENU ==========`);
    console.log(`\nChoose your test:`);
    console.log(`1. Health Check (free)`);
    console.log(`2. Dry Run (free - no ETH spent)`);
    console.log(`3. Real Trade (spends ETH)`);
    console.log(`\nTo run a test, use:`);
    console.log(`\n// Health Check`);
    console.log(`await testRunner.runHealthCheck();`);
    console.log(`\n// Dry Run`);
    console.log(`await testRunner.dryRun('YOUR_PRIVATE_KEY');`);
    console.log(`\n// Real Trade (careful!)`);
    console.log(`await testRunner.testWithRealKey('YOUR_PRIVATE_KEY', 'TONY', 0.001, 30);`);
    
    console.log(`\n📋 Available tokens: ${Object.keys(this.testTokens).join(', ')}`);
    console.log(`💡 Start with dry run to test everything safely!`);
  }
}

// Create test runner instance
const testRunner = new TestRunner();

// Run interactive menu
if (require.main === module) {
  testRunner.interactiveTest();
}

// Export for use
module.exports = TestRunner;

// USAGE EXAMPLES:
console.log(`\n🚀 ========== READY FOR YOUR TESTING ==========`);
console.log(`\n1. HEALTH CHECK (run this first):`);
console.log(`   node -e "const TestRunner = require('./test-runner'); const t = new TestRunner(); t.runHealthCheck();"`);

console.log(`\n2. DRY RUN (safe test with your private key):`);
console.log(`   const testRunner = new TestRunner();`);
console.log(`   await testRunner.dryRun('YOUR_PRIVATE_KEY_HERE');`);

console.log(`\n3. REAL TRADE (spends actual ETH):`);
console.log(`   await testRunner.testWithRealKey('YOUR_PRIVATE_KEY_HERE', 'TONY', 0.001, 30);`);

console.log(`\n⚠️  IMPORTANT:`);
console.log(`   - Start with health check`);
console.log(`   - Then do dry run`);
console.log(`   - Only do real trade when dry run succeeds`);
console.log(`   - Use small amounts first (0.001 ETH)`);

console.log(`\n✅ Everything is ready for your testing!`);