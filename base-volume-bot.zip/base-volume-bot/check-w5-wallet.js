/**
 * CHECK W5 WALLET
 * Check what wallet is actually in slot W5
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function checkW5Wallet() {
  console.log('🔍 ========== CHECK W5 WALLET ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    const yourUserId = 12345;
    const chain = 'base';
    const expectedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    
    console.log(`🔍 Checking W5 wallet for user: ${yourUserId}`);
    console.log(`🔍 Expected address: ${expectedAddress}`);
    
    // Get all wallets
    const chainWallets = await walletManager.getChainWallets(yourUserId, chain);
    
    console.log('\n📊 ALL WALLET SLOTS:');
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = chainWallets[walletSlot];
      
      if (wallet) {
        const balance = await walletManager.getWalletBalance(wallet.address, chain);
        const isYourWallet = wallet.address.toLowerCase() === expectedAddress.toLowerCase();
        const importedStatus = wallet.isImported ? '📥 IMPORTED' : '🔧 GENERATED';
        const matchStatus = isYourWallet ? '🎯 YOUR WALLET!' : '';
        
        console.log(`\n${walletSlot}: ${wallet.address}`);
        console.log(`   💰 Balance: ${balance} ETH`);
        console.log(`   🏷️ Type: ${importedStatus}`);
        console.log(`   📅 Created: ${new Date(wallet.createdAt).toLocaleDateString()}`);
        if (matchStatus) console.log(`   ${matchStatus}`);
        
        if (isYourWallet) {
          console.log(`\n🎯 FOUND YOUR WALLET IN SLOT ${walletSlot}!`);
          if (parseFloat(balance) > 0) {
            console.log(`✅ Wallet has balance: ${balance} ETH`);
            console.log(`✅ This should work for trading!`);
          } else {
            console.log(`❌ Wallet has 0 balance - this is the problem!`);
            console.log(`💡 Make sure this wallet has ETH on Base network`);
          }
        }
      } else {
        console.log(`\n${walletSlot}: EMPTY`);
      }
    }
    
    // Check if your wallet is in any slot
    let foundSlot = null;
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = chainWallets[walletSlot];
      if (wallet && wallet.address.toLowerCase() === expectedAddress.toLowerCase()) {
        foundSlot = walletSlot;
        break;
      }
    }
    
    console.log('\n🎯 DIAGNOSIS:');
    if (foundSlot) {
      console.log(`✅ Your wallet is in slot: ${foundSlot}`);
      if (foundSlot === 'W5') {
        console.log(`✅ Smart selection should pick this wallet automatically`);
        console.log(`💡 If trading still fails, the issue is likely:`);
        console.log(`   1. Wallet has insufficient ETH balance`);
        console.log(`   2. Network connectivity issues`);
        console.log(`   3. Gas price too low`);
      } else {
        console.log(`⚠️ Your wallet is NOT in W5 (it's in ${foundSlot})`);
        console.log(`💡 The smart selection might not be working correctly`);
      }
    } else {
      console.log(`❌ Your wallet is NOT found in any slot`);
      console.log(`💡 You need to import your wallet again`);
    }

  } catch (error) {
    console.error('❌ ERROR:', error.message);
  }
}

checkW5Wallet().then(() => {
  console.log('\n🎉 Check completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Check failed:', error);
  process.exit(1);
});