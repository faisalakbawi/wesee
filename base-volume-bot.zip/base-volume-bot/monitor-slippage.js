/**
 * MONITOR SLIPPAGE ERRORS
 * This script will help us monitor what happens during slippage setting
 */

const fs = require('fs');
const { spawn } = require('child_process');

console.log('🔍 ========== SLIPPAGE ERROR MONITOR ==========');
console.log('This will monitor the bot process for slippage-related logs');
console.log('Please test the custom slippage feature now...');
console.log('');

// Function to monitor bot process
function monitorBot() {
  const botProcess = spawn('node', ['main-bot.js'], {
    cwd: '/Users/faisal/Desktop/base-volume-bot',
    stdio: ['pipe', 'pipe', 'pipe']
  });

  console.log('🚀 Bot process started with PID:', botProcess.pid);

  botProcess.stdout.on('data', (data) => {
    const output = data.toString();
    
    // Filter for slippage-related logs
    if (output.includes('slippage') || 
        output.includes('CUSTOM SLIPPAGE') || 
        output.includes('Error setting slippage') ||
        output.includes('returnToTokenPage') ||
        output.includes('Step')) {
      
      console.log('📊 SLIPPAGE LOG:', output.trim());
    }
  });

  botProcess.stderr.on('data', (data) => {
    const error = data.toString();
    
    // Filter for error logs
    if (error.includes('Error') || error.includes('❌')) {
      console.log('❌ ERROR LOG:', error.trim());
    }
  });

  botProcess.on('close', (code) => {
    console.log(`🔴 Bot process exited with code ${code}`);
  });

  botProcess.on('error', (error) => {
    console.log('❌ Bot process error:', error.message);
  });

  return botProcess;
}

// Start monitoring
const botProcess = monitorBot();

// Handle cleanup
process.on('SIGINT', () => {
  console.log('\n🛑 Stopping monitor...');
  botProcess.kill();
  process.exit(0);
});

console.log('📱 Now test the custom slippage in your Telegram bot:');
console.log('1. Send /start');
console.log('2. Click 🔥 Buy Token');
console.log('3. Send: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913');
console.log('4. Click 📊 Slippage X%');
console.log('5. Click 💡 Custom %');
console.log('6. Reply with: 2.5');
console.log('');
console.log('Watch this console for detailed logs...');