/**
 * FIXED PRICE CALCULATION
 * Properly calculate Uniswap V3 pool price from sqrtPriceX96
 */

const { ethers } = require('ethers');

async function getCorrectPoolPrice() {
  console.log(`🏊 ========== CORRECT POOL PRICE CALCULATION ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  const TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  // Pool ABI
  const poolABI = [
    "function token0() external view returns (address)",
    "function token1() external view returns (address)",
    "function fee() external view returns (uint24)",
    "function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)"
  ];
  
  const pool = new ethers.Contract(TONY_POOL, poolABI, provider);
  
  try {
    const token0 = await pool.token0();
    const token1 = await pool.token1();
    const slot0 = await pool.slot0();
    
    console.log(`📊 Pool Data:`);
    console.log(`  🪙 Token0: ${token0} (TONY)`);
    console.log(`  🪙 Token1: ${token1} (WETH)`);
    console.log(`  🔢 SqrtPriceX96: ${slot0.sqrtPriceX96.toString()}`);
    console.log(`  📊 Tick: ${slot0.tick}`);
    
    // Correct Uniswap V3 price calculation
    // Price = (sqrtPriceX96 / 2^96)^2
    const sqrtPriceX96 = slot0.sqrtPriceX96;
    
    // Convert to decimal for calculation
    const Q96 = ethers.BigNumber.from(2).pow(96);
    const sqrtPrice = sqrtPriceX96.mul(ethers.utils.parseEther('1')).div(Q96);
    
    console.log(`\n💰 Price Calculation:`);
    console.log(`  🔢 SqrtPrice (decimal): ${ethers.utils.formatEther(sqrtPrice)}`);
    
    // Price = sqrtPrice^2
    const price = sqrtPrice.mul(sqrtPrice).div(ethers.utils.parseEther('1'));
    
    console.log(`  🔢 Price (Token1/Token0): ${ethers.utils.formatEther(price)}`);
    
    // Since Token0 = TONY, Token1 = WETH
    // Price = WETH/TONY (how much WETH for 1 TONY)
    const wethPerTony = price;
    
    // To get TONY per WETH, we need 1/price
    const tonyPerWeth = ethers.utils.parseEther('1').mul(ethers.utils.parseEther('1')).div(price);
    
    console.log(`\n📊 Human Readable Prices:`);
    console.log(`  💰 1 TONY = ${ethers.utils.formatEther(wethPerTony)} WETH`);
    console.log(`  💰 1 WETH = ${ethers.utils.formatEther(tonyPerWeth)} TONY`);
    
    // Calculate expected output for 0.001 ETH
    const ethInput = ethers.utils.parseEther('0.001');
    const expectedTonyOutput = ethInput.mul(tonyPerWeth).div(ethers.utils.parseEther('1'));
    
    console.log(`\n🧮 Expected Output for 0.001 ETH:`);
    console.log(`  📥 Input: 0.001 ETH`);
    console.log(`  📤 Expected: ${ethers.utils.formatEther(expectedTonyOutput)} TONY`);
    
    // Compare with our original assumption
    console.log(`\n🔍 Comparison:`);
    console.log(`  🤖 Our assumption: 34.11 TONY`);
    console.log(`  🏊 Pool reality: ${ethers.utils.formatEther(expectedTonyOutput)} TONY`);
    
    const ourAssumption = ethers.utils.parseEther('34.11');
    if (expectedTonyOutput.gt(ourAssumption.mul(2)) || expectedTonyOutput.lt(ourAssumption.div(2))) {
      console.log(`  ⚠️ MAJOR PRICE DIFFERENCE! Our assumption was wrong.`);
    } else {
      console.log(`  ✅ Price is reasonable, issue might be elsewhere.`);
    }
    
    return {
      wethPerTony: wethPerTony.toString(),
      tonyPerWeth: tonyPerWeth.toString(),
      expectedTonyOutput: expectedTonyOutput.toString(),
      sqrtPriceX96: sqrtPriceX96.toString()
    };
    
  } catch (error) {
    console.log(`❌ Price calculation failed: ${error.message}`);
    
    // Try alternative method using QuoterV2
    console.log(`\n🔄 Trying QuoterV2 for price...`);
    return await getQuoterPrice();
  }
}

async function getQuoterPrice() {
  console.log(`📊 ========== USING QUOTER V2 FOR PRICE ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  const QUOTER_V2 = '0x3d4e44Eb1374240CE5F1B871ab261CD16335B76a';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  // QuoterV2 ABI
  const quoterABI = [
    {
      "inputs": [
        {"internalType": "address", "name": "tokenIn", "type": "address"},
        {"internalType": "address", "name": "tokenOut", "type": "address"},
        {"internalType": "uint24", "name": "fee", "type": "uint24"},
        {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
        {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
      ],
      "name": "quoteExactInputSingle",
      "outputs": [
        {"internalType": "uint256", "name": "amountOut", "type": "uint256"},
        {"internalType": "uint160", "name": "sqrtPriceX96After", "type": "uint160"},
        {"internalType": "uint32", "name": "initializedTicksCrossed", "type": "uint32"},
        {"internalType": "uint256", "name": "gasEstimate", "type": "uint256"}
      ],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ];
  
  const quoter = new ethers.Contract(QUOTER_V2, quoterABI, provider);
  
  try {
    console.log(`🔍 Getting quote for 0.001 ETH → TONY...`);
    
    const ethInput = ethers.utils.parseEther('0.001');
    const quote = await quoter.quoteExactInputSingle(
      WETH,    // tokenIn
      TONY,    // tokenOut  
      10000,   // fee (1%)
      ethInput, // amountIn (0.001 ETH)
      0        // sqrtPriceLimitX96
    );
    
    console.log(`✅ QuoterV2 Results:`);
    console.log(`  📥 Input: 0.001 ETH`);
    console.log(`  📤 Output: ${ethers.utils.formatEther(quote.amountOut)} TONY`);
    console.log(`  ⛽ Gas estimate: ${quote.gasEstimate.toString()}`);
    console.log(`  🔢 Price after: ${quote.sqrtPriceX96After.toString()}`);
    console.log(`  📊 Ticks crossed: ${quote.initializedTicksCrossed}`);
    
    return {
      success: true,
      expectedTonyOutput: quote.amountOut.toString(),
      gasEstimate: quote.gasEstimate.toString()
    };
    
  } catch (error) {
    console.log(`❌ QuoterV2 failed: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// Test swap with QuoterV2 price
async function testSwapWithQuoterPrice(expectedTony) {
  console.log(`\n🧪 ========== TESTING SWAP WITH QUOTER PRICE ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const SWAP_ROUTER_02 = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  const router = new ethers.Contract(SWAP_ROUTER_02, routerABI, provider);
  
  // Use QuoterV2 price with 20% slippage
  const expectedTonyBN = ethers.BigNumber.from(expectedTony);
  const minOut = expectedTonyBN.mul(8000).div(10000); // 20% slippage
  
  console.log(`🔧 Using QuoterV2 price:`);
  console.log(`  📊 Expected TONY: ${ethers.utils.formatEther(expectedTonyBN)}`);
  console.log(`  🛡️ Min out (20% slippage): ${ethers.utils.formatEther(minOut)}`);
  
  const swapParams = {
    tokenIn: WETH,
    tokenOut: TONY,
    fee: 10000,
    recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A',
    deadline: Math.floor(Date.now() / 1000) + 300,
    amountIn: ethers.utils.parseEther('0.001'),
    amountOutMinimum: minOut,
    sqrtPriceLimitX96: 0
  };
  
  try {
    const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
      value: ethers.utils.parseEther('0.001'),
      from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
    });
    
    console.log(`✅ SWAP WITH QUOTER PRICE WORKS!`);
    console.log(`⛽ Gas estimate: ${gasEstimate.toString()}`);
    console.log(`🎉 PROBLEM SOLVED!`);
    
    return { success: true, gas: gasEstimate.toString() };
    
  } catch (error) {
    console.log(`❌ Still failed: ${error.message.split('(')[0]}`);
    return { success: false, error: error.message };
  }
}

// Run complete analysis
async function runCompleteAnalysis() {
  console.log(`🧪 ========== COMPLETE PRICE ANALYSIS ==========`);
  
  // Try manual price calculation first
  const priceData = await getCorrectPoolPrice();
  
  // If that fails, use QuoterV2
  if (!priceData.expectedTonyOutput) {
    console.log(`\n🔄 Manual calculation failed, using QuoterV2...`);
    const quoterData = await getQuoterPrice();
    
    if (quoterData.success) {
      // Test swap with QuoterV2 price
      const swapResult = await testSwapWithQuoterPrice(quoterData.expectedTonyOutput);
      
      console.log(`\n📊 ========== FINAL RESULT ==========`);
      if (swapResult.success) {
        console.log(`✅ PROBLEM COMPLETELY SOLVED!`);
        console.log(`🎯 Issue: Wrong price calculation`);
        console.log(`💡 Solution: Use QuoterV2 for accurate pricing`);
        console.log(`📊 Correct output: ${ethers.utils.formatEther(quoterData.expectedTonyOutput)} TONY`);
        console.log(`⛽ Working gas: ${swapResult.gas}`);
      } else {
        console.log(`❌ Still failing - deeper issue exists`);
      }
    } else {
      console.log(`❌ Both price methods failed`);
    }
  }
}

runCompleteAnalysis().catch(console.error);