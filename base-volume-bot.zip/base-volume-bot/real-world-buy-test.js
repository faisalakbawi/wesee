/**
 * 🌍 REAL-WORLD BUY FUNCTIONALITY TEST
 * Tests with actual tokens across different liquidity levels and chains
 */

const ChainManager = require('./chains/chain-manager');
const TokenAnalyzer = require('./trading/token-analyzer');
const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletManager = require('./database/wallet-db-manager');
const Database = require('./database/database');

class RealWorldBuyTest {
  constructor() {
    this.chainManager = new ChainManager();
    this.tokenAnalyzer = new TokenAnalyzer(this.chainManager);
    this.database = new Database();
    this.walletManager = new WalletManager(this.database);
    this.buyTokenUI = new BuyTokenUI(null, this.walletManager, this.chainManager);
    
    // Real token addresses for testing different scenarios
    this.testTokens = {
      // High liquidity tokens
      highLiquidity: [
        { address: '0xA0b86a33E6441b8e8C7C7b0b8b8b8b8b8b8b8b8b', chain: 'ethereum', name: 'USDC', expectedLiquidity: 'high' },
        { address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', chain: 'base', name: 'USDC', expectedLiquidity: 'high' },
        { address: '0x55d398326f99059fF775485246999027B3197955', chain: 'bsc', name: 'USDT', expectedLiquidity: 'high' }
      ],
      
      // Medium liquidity tokens
      mediumLiquidity: [
        { address: '0x4ed4E862860beD51a9570b96d89aF5E1B0Efefed', chain: 'base', name: 'DEGEN', expectedLiquidity: 'medium' },
        { address: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb', chain: 'base', name: 'DAI', expectedLiquidity: 'medium' }
      ],
      
      // Low liquidity tokens (newer/smaller projects)
      lowLiquidity: [
        { address: '0x1234567890123456789012345678901234567890', chain: 'base', name: 'TEST_LOW', expectedLiquidity: 'low' },
        { address: '0xabcdefabcdefabcdefabcdefabcdefabcdefabcd', chain: 'ethereum', name: 'TEST_MICRO', expectedLiquidity: 'micro' }
      ],
      
      // Solana tokens
      solana: [
        { address: 'So11111111111111111111111111111111111111112', chain: 'solana', name: 'Wrapped SOL', expectedLiquidity: 'high' },
        { address: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', chain: 'solana', name: 'USDC', expectedLiquidity: 'high' }
      ]
    };
  }

  async runRealWorldTest() {
    console.log('🌍 STARTING REAL-WORLD BUY FUNCTIONALITY TEST');
    console.log('==============================================');
    
    const results = {
      tokenAnalysis: {},
      liquidityDetection: {},
      buyFlowSimulation: {},
      crossChainSupport: {},
      errors: []
    };
    
    try {
      // Test 1: Token Analysis Accuracy
      await this.testTokenAnalysisAccuracy(results);
      
      // Test 2: Liquidity Detection
      await this.testLiquidityDetection(results);
      
      // Test 3: Buy Flow Simulation
      await this.testBuyFlowSimulation(results);
      
      // Test 4: Cross-Chain Support
      await this.testCrossChainSupport(results);
      
      // Test 5: Error Scenarios
      await this.testErrorScenarios(results);
      
      // Generate report
      this.generateRealWorldReport(results);
      
    } catch (error) {
      console.error('❌ Real-world test failed:', error.message);
      results.errors.push(`Test suite failure: ${error.message}`);
    }
  }

  async testTokenAnalysisAccuracy(results) {
    console.log('\n🔍 PHASE 1: TOKEN ANALYSIS ACCURACY TEST');
    console.log('=======================================');
    
    const allTokens = [
      ...this.testTokens.highLiquidity,
      ...this.testTokens.mediumLiquidity,
      ...this.testTokens.lowLiquidity,
      ...this.testTokens.solana
    ];
    
    for (const token of allTokens) {
      try {
        console.log(`\n🔍 Analyzing ${token.name} on ${token.chain}...`);
        
        let analysis;
        if (token.chain === 'solana') {
          analysis = await this.tokenAnalyzer.analyzeSolanaToken(token.address);
        } else {
          analysis = await this.tokenAnalyzer.analyzeEVMToken(token.address, token.chain);
        }
        
        const result = {
          token: token.name,
          chain: token.chain,
          address: token.address,
          analysis: analysis,
          success: !!analysis,
          hasPrice: !!(analysis && analysis.price),
          hasLiquidity: !!(analysis && analysis.liquidity),
          hasMarketCap: !!(analysis && analysis.marketCap)
        };
        
        results.tokenAnalysis[`${token.chain}_${token.name}`] = result;
        
        console.log(`   ${result.success ? '✅' : '❌'} Analysis: ${result.success ? 'SUCCESS' : 'FAILED'}`);
        if (analysis) {
          console.log(`   💰 Price: ${analysis.price || 'N/A'}`);
          console.log(`   💧 Liquidity: ${analysis.liquidity || 'N/A'}`);
          console.log(`   📊 Market Cap: ${analysis.marketCap || 'N/A'}`);
          console.log(`   📈 24h Change: ${analysis.priceChange24h || 'N/A'}`);
        }
        
      } catch (error) {
        console.error(`   ❌ ${token.name}: ${error.message}`);
        results.errors.push(`Token analysis ${token.name}: ${error.message}`);
      }
    }
  }

  async testLiquidityDetection(results) {
    console.log('\n💧 PHASE 2: LIQUIDITY DETECTION ACCURACY');
    console.log('========================================');
    
    for (const [category, tokens] of Object.entries(this.testTokens)) {
      if (category === 'solana') continue; // Skip Solana for liquidity testing
      
      console.log(`\n🔍 Testing ${category} tokens...`);
      
      for (const token of tokens) {
        try {
          const analysis = await this.tokenAnalyzer.analyzeEVMToken(token.address, token.chain);
          
          if (analysis && analysis.liquidity) {
            const liquidityAnalysis = await this.tokenAnalyzer.analyzeLiquidityConditions(analysis);
            
            const result = {
              token: token.name,
              expected: token.expectedLiquidity,
              detected: liquidityAnalysis.liquidityCategory,
              riskLevel: liquidityAnalysis.riskLevel,
              recommendedSlippage: liquidityAnalysis.recommendedSlippage,
              warnings: liquidityAnalysis.warnings,
              accurate: this.isLiquidityDetectionAccurate(token.expectedLiquidity, liquidityAnalysis.liquidityCategory)
            };
            
            results.liquidityDetection[`${token.chain}_${token.name}`] = result;
            
            const accuracy = result.accurate ? '✅' : '⚠️';
            console.log(`   ${accuracy} ${token.name}: Expected ${token.expectedLiquidity}, Got ${liquidityAnalysis.liquidityCategory}`);
            console.log(`      Risk: ${liquidityAnalysis.riskLevel}, Slippage: ${liquidityAnalysis.recommendedSlippage}%`);
            
            if (liquidityAnalysis.warnings.length > 0) {
              console.log(`      Warnings: ${liquidityAnalysis.warnings.length}`);
            }
          }
          
        } catch (error) {
          console.error(`   ❌ ${token.name}: ${error.message}`);
          results.errors.push(`Liquidity detection ${token.name}: ${error.message}`);
        }
      }
    }
  }

  async testBuyFlowSimulation(results) {
    console.log('\n🛒 PHASE 3: BUY FLOW SIMULATION');
    console.log('===============================');
    
    const testUserId = 999999997;
    const buyAmounts = ['0.01', '0.1', '0.5']; // Different buy amounts to test
    
    // Test with a few representative tokens
    const testTokens = [
      this.testTokens.highLiquidity[0], // USDC on Ethereum
      this.testTokens.mediumLiquidity[0], // DEGEN on Base
      this.testTokens.solana[0] // Wrapped SOL
    ];
    
    for (const token of testTokens) {
      try {
        console.log(`\n🔍 Testing buy flow for ${token.name} on ${token.chain}...`);
        
        // Step 1: Analyze token
        let analysis;
        if (token.chain === 'solana') {
          analysis = await this.tokenAnalyzer.analyzeSolanaToken(token.address);
        } else {
          analysis = await this.tokenAnalyzer.analyzeEVMToken(token.address, token.chain);
        }
        
        if (!analysis) {
          console.log(`   ❌ Token analysis failed`);
          continue;
        }
        
        // Step 2: Create session
        const sessionId = this.buyTokenUI.createTokenSession(testUserId, {
          name: token.name,
          symbol: token.name,
          address: token.address,
          chain: token.chain,
          ...analysis
        });
        
        console.log(`   ✅ Session created: ${sessionId}`);
        
        // Step 3: Test wallet selection
        const selectedWallets = new Set([1, 2]); // Select first 2 wallets
        this.buyTokenUI.setSelectedWallets(testUserId, sessionId, selectedWallets);
        
        const retrievedWallets = this.buyTokenUI.getSelectedWallets(testUserId, sessionId);
        const walletSelectionWorks = retrievedWallets.size === 2;
        
        console.log(`   ${walletSelectionWorks ? '✅' : '❌'} Wallet selection: ${walletSelectionWorks ? 'OK' : 'FAILED'}`);
        
        // Step 4: Test different buy amounts
        for (const amount of buyAmounts) {
          this.buyTokenUI.setSelectedAmount(testUserId, sessionId, parseFloat(amount));
          const retrievedAmount = this.buyTokenUI.getSelectedAmount(testUserId, sessionId);
          
          console.log(`   ${retrievedAmount === parseFloat(amount) ? '✅' : '❌'} Amount ${amount}: ${retrievedAmount === parseFloat(amount) ? 'OK' : 'FAILED'}`);
          
          // Test slippage calculation
          if (analysis.liquidity) {
            const liquidityAnalysis = await this.tokenAnalyzer.analyzeLiquidityConditions(analysis);
            const smartSlippage = this.tokenAnalyzer.getSmartSlippageRecommendation(liquidityAnalysis, amount);
            
            console.log(`      📊 Smart slippage for ${amount}: ${smartSlippage}%`);
          }
        }
        
        // Step 5: Test keyboard generation
        try {
          const keyboard = await this.buyTokenUI.createBuyKeyboard(testUserId, {
            name: token.name,
            symbol: token.name,
            address: token.address,
            chain: token.chain,
            ...analysis
          });
          
          console.log(`   ${keyboard ? '✅' : '❌'} Keyboard generation: ${keyboard ? 'OK' : 'FAILED'}`);
        } catch (error) {
          console.log(`   ⚠️ Keyboard generation: ${error.message.substring(0, 50)}...`);
        }
        
        results.buyFlowSimulation[`${token.chain}_${token.name}`] = {
          tokenAnalysis: !!analysis,
          sessionCreation: !!sessionId,
          walletSelection: walletSelectionWorks,
          amountSelection: true,
          keyboardGeneration: true
        };
        
      } catch (error) {
        console.error(`   ❌ Buy flow test for ${token.name}: ${error.message}`);
        results.errors.push(`Buy flow ${token.name}: ${error.message}`);
      }
    }
  }

  async testCrossChainSupport(results) {
    console.log('\n🌐 PHASE 4: CROSS-CHAIN SUPPORT TEST');
    console.log('====================================');
    
    const chains = ['ethereum', 'base', 'bsc', 'solana'];
    const testAddress = '0x1234567890123456789012345678901234567890';
    
    for (const chain of chains) {
      try {
        console.log(`\n🔍 Testing ${chain} support...`);
        
        const chainInstance = this.chainManager.getChain(chain);
        const result = {
          chain,
          available: !!chainInstance,
          features: {
            tokenAnalysis: false,
            priceData: false,
            walletBalance: false,
            trading: false
          }
        };
        
        if (chainInstance) {
          // Test token analysis
          try {
            let analysis;
            if (chain === 'solana') {
              analysis = await this.tokenAnalyzer.analyzeSolanaToken('So11111111111111111111111111111111111111112');
            } else {
              analysis = await this.tokenAnalyzer.analyzeEVMToken(testAddress, chain);
            }
            result.features.tokenAnalysis = !!analysis;
          } catch (error) {
            // Expected for some chains
          }
          
          // Test price data
          try {
            const priceData = await chainInstance.getTokenPrice(testAddress);
            result.features.priceData = !!priceData;
          } catch (error) {
            // Expected for some chains
          }
          
          // Test wallet balance
          try {
            const balance = await chainInstance.getWalletBalance(testAddress);
            result.features.walletBalance = true;
          } catch (error) {
            // Expected for some chains
          }
          
          // Test trading capability
          try {
            await chainInstance.executeBuy('test', testAddress, '0.1', 5);
            result.features.trading = true;
          } catch (error) {
            if (!error.message.includes('coming soon') && !error.message.includes('invalid hexlify')) {
              result.features.trading = false;
            }
          }
        }
        
        results.crossChainSupport[chain] = result;
        
        const supportLevel = result.available ? 
          (Object.values(result.features).filter(f => f).length >= 2 ? '✅ GOOD' : '🟡 PARTIAL') : 
          '❌ NONE';
        
        console.log(`   ${supportLevel} ${chain}: ${Object.values(result.features).filter(f => f).length}/4 features`);
        
      } catch (error) {
        console.error(`   ❌ ${chain}: ${error.message}`);
        results.errors.push(`Cross-chain ${chain}: ${error.message}`);
      }
    }
  }

  async testErrorScenarios(results) {
    console.log('\n🚨 PHASE 5: ERROR SCENARIO TESTING');
    console.log('==================================');
    
    const errorScenarios = [
      {
        name: 'Invalid Token Address',
        test: () => this.tokenAnalyzer.analyzeToken('invalid_address_format'),
        expectGracefulHandling: true
      },
      {
        name: 'Non-existent Token',
        test: () => this.tokenAnalyzer.analyzeEVMToken('0x0000000000000000000000000000000000000000', 'ethereum'),
        expectGracefulHandling: true
      },
      {
        name: 'Network Timeout Simulation',
        test: () => this.tokenAnalyzer.analyzeEVMToken('0x1234567890123456789012345678901234567890', 'nonexistent_chain'),
        expectGracefulHandling: true
      },
      {
        name: 'Extreme Buy Amount',
        test: () => {
          const testUserId = 999999996;
          const sessionId = 'test_extreme';
          this.buyTokenUI.setSelectedAmount(testUserId, sessionId, 999999999);
          return this.buyTokenUI.getSelectedAmount(testUserId, sessionId);
        },
        expectGracefulHandling: true
      }
    ];
    
    for (const scenario of errorScenarios) {
      try {
        console.log(`🔍 Testing ${scenario.name}...`);
        
        const result = await scenario.test();
        
        if (scenario.expectGracefulHandling) {
          console.log(`   ✅ Handled gracefully: ${typeof result}`);
        } else {
          console.log(`   ⚠️ Unexpected success: ${JSON.stringify(result).substring(0, 50)}...`);
        }
        
      } catch (error) {
        if (scenario.expectGracefulHandling) {
          console.log(`   ✅ Error handled: ${error.message.substring(0, 50)}...`);
        } else {
          console.log(`   ❌ Unexpected error: ${error.message}`);
          results.errors.push(`Error scenario ${scenario.name}: ${error.message}`);
        }
      }
    }
  }

  isLiquidityDetectionAccurate(expected, detected) {
    // Allow some flexibility in liquidity detection
    const liquidityLevels = ['micro', 'very-low', 'low', 'medium', 'good', 'high'];
    const expectedIndex = liquidityLevels.indexOf(expected);
    const detectedIndex = liquidityLevels.indexOf(detected);
    
    // Consider accurate if within 1 level
    return Math.abs(expectedIndex - detectedIndex) <= 1;
  }

  generateRealWorldReport(results) {
    console.log('\n📊 REAL-WORLD TEST REPORT');
    console.log('=========================');
    
    // Token Analysis Summary
    const analysisResults = Object.values(results.tokenAnalysis);
    const successfulAnalysis = analysisResults.filter(r => r.success).length;
    
    console.log('\n🔍 TOKEN ANALYSIS:');
    console.log(`   ✅ Successful: ${successfulAnalysis}/${analysisResults.length}`);
    console.log(`   💰 Price Data: ${analysisResults.filter(r => r.hasPrice).length}/${analysisResults.length}`);
    console.log(`   💧 Liquidity Data: ${analysisResults.filter(r => r.hasLiquidity).length}/${analysisResults.length}`);
    
    // Liquidity Detection Summary
    const liquidityResults = Object.values(results.liquidityDetection);
    const accurateDetection = liquidityResults.filter(r => r.accurate).length;
    
    console.log('\n💧 LIQUIDITY DETECTION:');
    console.log(`   🎯 Accurate: ${accurateDetection}/${liquidityResults.length}`);
    console.log(`   ⚠️ Warnings Generated: ${liquidityResults.reduce((sum, r) => sum + r.warnings.length, 0)}`);
    
    // Buy Flow Summary
    const buyFlowResults = Object.values(results.buyFlowSimulation);
    const completeBuyFlows = buyFlowResults.filter(r => 
      r.tokenAnalysis && r.sessionCreation && r.walletSelection && r.amountSelection
    ).length;
    
    console.log('\n🛒 BUY FLOW SIMULATION:');
    console.log(`   ✅ Complete Flows: ${completeBuyFlows}/${buyFlowResults.length}`);
    
    // Cross-Chain Summary
    const chainResults = Object.values(results.crossChainSupport);
    const fullySupported = chainResults.filter(r => 
      Object.values(r.features).filter(f => f).length >= 3
    ).length;
    
    console.log('\n🌐 CROSS-CHAIN SUPPORT:');
    console.log(`   ✅ Fully Supported: ${fullySupported}/${chainResults.length}`);
    console.log(`   🟡 Partially Supported: ${chainResults.filter(r => 
      Object.values(r.features).filter(f => f).length >= 1 && 
      Object.values(r.features).filter(f => f).length < 3
    ).length}/${chainResults.length}`);
    
    // Error Summary
    console.log('\n🚨 ERROR SUMMARY:');
    if (results.errors.length === 0) {
      console.log('   ✅ No critical errors found!');
    } else {
      console.log(`   ❌ ${results.errors.length} errors found:`);
      results.errors.slice(0, 5).forEach((error, index) => {
        console.log(`      ${index + 1}. ${error.substring(0, 80)}...`);
      });
      if (results.errors.length > 5) {
        console.log(`      ... and ${results.errors.length - 5} more`);
      }
    }
    
    // Overall Assessment
    const overallScore = this.calculateRealWorldScore(results);
    console.log('\n🎯 REAL-WORLD ASSESSMENT:');
    console.log(`   📊 Real-World Readiness Score: ${overallScore}/100`);
    
    if (overallScore >= 85) {
      console.log('   🚀 EXCELLENT - Ready for production with real tokens!');
    } else if (overallScore >= 70) {
      console.log('   ✅ GOOD - Functional with real tokens, minor improvements needed');
    } else if (overallScore >= 55) {
      console.log('   🟡 FAIR - Works with some tokens, needs improvements');
    } else {
      console.log('   ❌ POOR - Significant issues with real token handling');
    }
    
    // Save detailed report
    const fs = require('fs');
    const path = require('path');
    const reportPath = path.join(__dirname, 'REAL_WORLD_BUY_TEST_REPORT.json');
    
    const report = {
      timestamp: new Date().toISOString(),
      summary: {
        tokenAnalysisSuccess: successfulAnalysis,
        liquidityDetectionAccuracy: accurateDetection,
        completeBuyFlows: completeBuyFlows,
        crossChainSupport: fullySupported,
        totalErrors: results.errors.length,
        overallScore: overallScore
      },
      details: results
    };
    
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    console.log(`\n📄 Detailed report saved to: ${reportPath}`);
  }

  calculateRealWorldScore(results) {
    let score = 0;
    
    // Token analysis success (30 points)
    const analysisResults = Object.values(results.tokenAnalysis);
    if (analysisResults.length > 0) {
      const successRate = analysisResults.filter(r => r.success).length / analysisResults.length;
      score += successRate * 30;
    }
    
    // Liquidity detection accuracy (25 points)
    const liquidityResults = Object.values(results.liquidityDetection);
    if (liquidityResults.length > 0) {
      const accuracyRate = liquidityResults.filter(r => r.accurate).length / liquidityResults.length;
      score += accuracyRate * 25;
    }
    
    // Buy flow completion (25 points)
    const buyFlowResults = Object.values(results.buyFlowSimulation);
    if (buyFlowResults.length > 0) {
      const completionRate = buyFlowResults.filter(r => 
        r.tokenAnalysis && r.sessionCreation && r.walletSelection
      ).length / buyFlowResults.length;
      score += completionRate * 25;
    }
    
    // Cross-chain support (20 points)
    const chainResults = Object.values(results.crossChainSupport);
    if (chainResults.length > 0) {
      const supportRate = chainResults.filter(r => 
        Object.values(r.features).filter(f => f).length >= 2
      ).length / chainResults.length;
      score += supportRate * 20;
    }
    
    // Deduct for errors
    score -= Math.min(results.errors.length * 3, 15);
    
    return Math.max(0, Math.round(score));
  }
}

// Run the real-world test
async function runRealWorldTest() {
  const tester = new RealWorldBuyTest();
  await tester.runRealWorldTest();
}

// Export for use in other files
module.exports = RealWorldBuyTest;

// Run if called directly
if (require.main === module) {
  runRealWorldTest().catch(console.error);
}