/**
 * TEST TOKEN ANALYSIS FIX
 * Verify that token analysis now works correctly in the bot
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.callbacks = [];
    this.deletedMessages = [];
    this.editedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 100)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.editedMessages.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 100)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function testTokenAnalysisFix() {
  console.log('🧪 ========== TOKEN ANALYSIS FIX TEST ==========');

  try {
    // Initialize all components
    console.log('🔧 Initializing components...');
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ All components initialized successfully');

    // Test 1: Buy Token Menu
    console.log('\n📍 TEST 1: Buy Token Menu');
    const buyTokenCallback = {
      id: 'test_1',
      data: 'buy_menu',
      from: { id: testUserId },
      message: { message_id: 1001 }
    };
    await callbacks.handle(buyTokenCallback);
    console.log('✅ Buy token menu displayed');

    // Test 2: Contract Address Input (The Critical Test!)
    console.log('\n📍 TEST 2: Contract Address Input (CRITICAL TEST)');
    
    const contractMessage = {
      message_id: 1002,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    console.log('🎯 Testing with USDC contract address...');
    await callbacks.buyTokenUI.handleContractAddress(contractMessage);
    
    // Check if token analysis succeeded
    const lastMessage = mockBot.messages[mockBot.messages.length - 1];
    if (lastMessage && lastMessage.text.includes('❌ Error analyzing token')) {
      console.log('❌ FAILED: Token analysis still showing error');
      console.log('❌ Error message:', lastMessage.text);
    } else if (lastMessage && lastMessage.text.includes('Buy: USDC')) {
      console.log('✅ SUCCESS: Token analysis working correctly!');
      console.log('✅ Token info displayed properly');
    } else {
      console.log('⚠️ UNKNOWN: Unexpected response');
      console.log('📄 Last message:', lastMessage?.text?.substring(0, 200));
    }

    // Test 3: Check if slippage button is available
    console.log('\n📍 TEST 3: Slippage Button Availability');
    if (lastMessage && lastMessage.reply_markup && lastMessage.reply_markup.inline_keyboard) {
      const buttons = lastMessage.reply_markup.inline_keyboard.flat();
      const slippageButton = buttons.find(btn => btn.text.includes('Slippage'));
      
      if (slippageButton) {
        console.log('✅ Slippage button found:', slippageButton.text);
        console.log('✅ Callback data:', slippageButton.callback_data);
      } else {
        console.log('❌ Slippage button not found');
      }
    }

    // Summary
    console.log('\n📊 ========== TEST SUMMARY ==========');
    console.log(`📤 Messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Messages edited: ${mockBot.editedMessages.length}`);
    console.log(`✅ Callbacks answered: ${mockBot.callbacks.length}`);

    // Check for error messages
    const errorMessages = mockBot.messages.filter(msg => 
      msg.text && msg.text.includes('❌ Error analyzing token')
    );
    
    if (errorMessages.length > 0) {
      console.log('\n❌ ERROR MESSAGES FOUND:');
      errorMessages.forEach(msg => console.log(`   - ${msg.text}`));
      return false;
    } else {
      console.log('\n✅ NO ERROR MESSAGES - TOKEN ANALYSIS WORKING!');
      return true;
    }

  } catch (error) {
    console.error('❌ TEST FAILED:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
testTokenAnalysisFix().then(success => {
  if (success) {
    console.log('\n🎉 ========== TOKEN ANALYSIS FIX SUCCESSFUL! ==========');
    console.log('🚀 Bot is ready for live testing!');
    console.log('✅ Users can now send contract addresses without errors!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== TOKEN ANALYSIS STILL HAS ISSUES ==========');
    console.log('❌ Need to investigate further');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});