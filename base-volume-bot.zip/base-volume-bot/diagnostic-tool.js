/**
 * COMPREHENSIVE DIAGNOSTIC TOOL
 * Analyzes why the sniper contract fails and tests direct Uniswap V3 approach
 */

const { ethers } = require('ethers');

class DiagnosticTool {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
    
    // Addresses
    this.SNIPER_CONTRACT = '0xe111b0C3605aDc45CFb0CD75E5543F63CC3ec425';
    this.UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
    this.WETH = '0x4200000000000000000000000000000000000006';
    this.TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
    this.TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    
    // Test wallet (replace with your private key for testing)
    this.TEST_WALLET = null; // Will be set when testing
  }

  /**
   * ANALYZE SNIPER CONTRACT
   * Deep dive into why the sniper contract is failing
   */
  async analyzeSniperContract() {
    console.log(`🔍 ========== SNIPER CONTRACT ANALYSIS ==========`);
    console.log(`📍 Contract: ${this.SNIPER_CONTRACT}`);
    
    try {
      // 1. Check if contract exists
      const code = await this.provider.getCode(this.SNIPER_CONTRACT);
      console.log(`📋 Contract Code Length: ${code.length} bytes`);
      
      if (code === '0x') {
        console.log(`❌ CONTRACT DOES NOT EXIST!`);
        return { exists: false };
      }
      
      // 2. Check if it's a proxy contract
      const isProxy = code.includes('363d3d373d3d3d363d73') || code.includes('5155f3363d3d373d3d3d363d73');
      console.log(`🔄 Is Proxy Contract: ${isProxy}`);
      
      // 3. Try to get implementation address (if proxy)
      if (isProxy) {
        try {
          // Standard proxy implementation slot
          const implSlot = '0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc';
          const implAddress = await this.provider.getStorageAt(this.SNIPER_CONTRACT, implSlot);
          const cleanImplAddress = '0x' + implAddress.slice(-40);
          console.log(`🎯 Implementation Address: ${cleanImplAddress}`);
          
          const implCode = await this.provider.getCode(cleanImplAddress);
          console.log(`📋 Implementation Code Length: ${implCode.length} bytes`);
        } catch (error) {
          console.log(`⚠️ Could not get implementation: ${error.message}`);
        }
      }
      
      // 4. Check contract balance
      const balance = await this.provider.getBalance(this.SNIPER_CONTRACT);
      console.log(`💰 Contract Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      // 5. Try to call view functions
      console.log(`🔍 Testing contract calls...`);
      
      // Try common view functions
      const testCalls = [
        { name: 'owner()', selector: '0x8da5cb5b' },
        { name: 'paused()', selector: '0x5c975abb' },
        { name: 'admin()', selector: '0xf851a440' },
        { name: 'implementation()', selector: '0x5c60da1b' }
      ];
      
      for (const call of testCalls) {
        try {
          const result = await this.provider.call({
            to: this.SNIPER_CONTRACT,
            data: call.selector
          });
          console.log(`  ✅ ${call.name}: ${result}`);
        } catch (error) {
          console.log(`  ❌ ${call.name}: ${error.message}`);
        }
      }
      
      return { exists: true, isProxy, analysis: 'complete' };
      
    } catch (error) {
      console.log(`❌ Sniper contract analysis failed: ${error.message}`);
      return { exists: false, error: error.message };
    }
  }

  /**
   * ANALYZE FAILED TRANSACTION
   * Decode and analyze the specific failed transaction
   */
  async analyzeFailedTransaction() {
    console.log(`🔍 ========== FAILED TRANSACTION ANALYSIS ==========`);
    
    const txHash = '0x5dee64ae5a41226c408d5bda84305b61cb9510ca5c7b9a79fb41d2499c054676';
    console.log(`📍 Transaction: ${txHash}`);
    
    try {
      const tx = await this.provider.getTransaction(txHash);
      const receipt = await this.provider.getTransactionReceipt(txHash);
      
      console.log(`📊 Transaction Details:`);
      console.log(`  💰 Value: ${ethers.utils.formatEther(tx.value)} ETH`);
      console.log(`  ⛽ Gas Limit: ${tx.gasLimit.toString()}`);
      console.log(`  ⛽ Gas Used: ${receipt.gasUsed.toString()} (${(receipt.gasUsed.toNumber() / tx.gasLimit.toNumber() * 100).toFixed(2)}%)`);
      console.log(`  📊 Status: ${receipt.status === 1 ? 'Success' : 'Failed'}`);
      console.log(`  🏷️ Nonce: ${tx.nonce}`);
      
      // Decode input data
      console.log(`📋 Input Data Analysis:`);
      const inputData = tx.data;
      console.log(`  🔧 Function Selector: ${inputData.slice(0, 10)}`);
      console.log(`  📊 Data Length: ${inputData.length} characters`);
      
      // Try to decode the parameters
      if (inputData.startsWith('0xc981cc3c')) {
        console.log(`  ✅ Function: execBuy()`);
        
        // Decode parameters (simplified)
        const params = inputData.slice(10);
        const chunks = [];
        for (let i = 0; i < params.length; i += 64) {
          chunks.push(params.slice(i, i + 64));
        }
        
        console.log(`  📊 Parameters (${chunks.length} chunks):`);
        chunks.forEach((chunk, i) => {
          const value = ethers.BigNumber.from('0x' + chunk);
          console.log(`    Param ${i + 1}: 0x${chunk} (${value.toString()})`);
        });
      }
      
      return { tx, receipt, analysis: 'complete' };
      
    } catch (error) {
      console.log(`❌ Transaction analysis failed: ${error.message}`);
      return { error: error.message };
    }
  }

  /**
   * TEST DIRECT UNISWAP V3 APPROACH
   * Test if direct Uniswap V3 Router works
   */
  async testDirectUniswapV3(privateKey, amountETH = 0.001) {
    console.log(`🌊 ========== DIRECT UNISWAP V3 TEST ==========`);
    console.log(`🎯 Testing direct Uniswap V3 Router approach`);
    console.log(`💰 Amount: ${amountETH} ETH`);
    
    try {
      const wallet = new ethers.Wallet(privateKey, this.provider);
      console.log(`👤 Wallet: ${wallet.address}`);
      
      // Check wallet balance
      const balance = await wallet.getBalance();
      console.log(`💰 Wallet Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      if (balance.lt(ethers.utils.parseEther(amountETH.toString()))) {
        console.log(`❌ Insufficient balance for test`);
        return { success: false, error: 'Insufficient balance' };
      }
      
      // Uniswap V3 Router ABI (exactInputSingle)
      const routerABI = [
        {
          "inputs": [
            {
              "components": [
                {"internalType": "address", "name": "tokenIn", "type": "address"},
                {"internalType": "address", "name": "tokenOut", "type": "address"},
                {"internalType": "uint24", "name": "fee", "type": "uint24"},
                {"internalType": "address", "name": "recipient", "type": "address"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
                {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
              ],
              "internalType": "struct ISwapRouter.ExactInputSingleParams",
              "name": "params",
              "type": "tuple"
            }
          ],
          "name": "exactInputSingle",
          "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
          "stateMutability": "payable",
          "type": "function"
        }
      ];
      
      const router = new ethers.Contract(this.UNISWAP_V3_ROUTER, routerABI, wallet);
      
      // Build swap parameters
      const ethAmountWei = ethers.utils.parseEther(amountETH.toString());
      const deadline = Math.floor(Date.now() / 1000) + 300; // 5 minutes
      const expectedTokens = ethers.utils.parseUnits('34.11', 18); // Known TONY rate
      const minOut = expectedTokens.mul(8000).div(10000); // 20% slippage
      
      const swapParams = {
        tokenIn: this.WETH,
        tokenOut: this.TONY,
        fee: 10000, // 1% fee tier
        recipient: wallet.address,
        deadline: deadline,
        amountIn: ethAmountWei,
        amountOutMinimum: minOut,
        sqrtPriceLimitX96: 0
      };
      
      console.log(`🔧 Swap Parameters:`);
      console.log(`  📥 Token In: ${swapParams.tokenIn} (WETH)`);
      console.log(`  📤 Token Out: ${swapParams.tokenOut} (TONY)`);
      console.log(`  💰 Amount In: ${ethers.utils.formatEther(swapParams.amountIn)} ETH`);
      console.log(`  🛡️ Min Out: ${ethers.utils.formatUnits(swapParams.amountOutMinimum, 18)} TONY`);
      console.log(`  💸 Fee: ${swapParams.fee / 10000}%`);
      console.log(`  ⏰ Deadline: ${new Date(deadline * 1000).toISOString()}`);
      
      // Estimate gas first
      console.log(`⛽ Estimating gas...`);
      try {
        const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
          value: ethAmountWei
        });
        console.log(`  ✅ Gas Estimate: ${gasEstimate.toString()}`);
        
        // If gas estimation succeeds, the transaction should work
        console.log(`✅ DIRECT UNISWAP V3 SHOULD WORK!`);
        console.log(`🎯 Gas estimate successful means transaction is valid`);
        
        return {
          success: true,
          gasEstimate: gasEstimate.toString(),
          method: 'Direct Uniswap V3 Router',
          params: swapParams
        };
        
      } catch (gasError) {
        console.log(`❌ Gas estimation failed: ${gasError.message}`);
        
        // Try to understand why
        if (gasError.message.includes('INSUFFICIENT_OUTPUT_AMOUNT')) {
          console.log(`🔍 Issue: Slippage too tight, need higher slippage`);
        } else if (gasError.message.includes('STF')) {
          console.log(`🔍 Issue: Insufficient balance or approval`);
        } else {
          console.log(`🔍 Issue: ${gasError.message}`);
        }
        
        return {
          success: false,
          error: gasError.message,
          analysis: 'Gas estimation failed'
        };
      }
      
    } catch (error) {
      console.log(`❌ Direct Uniswap V3 test failed: ${error.message}`);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * COMPREHENSIVE DIAGNOSIS
   * Run all diagnostic tests
   */
  async runFullDiagnosis(privateKey = null) {
    console.log(`🧠 ========== COMPREHENSIVE DIAGNOSIS ==========`);
    console.log(`🕐 Started at: ${new Date().toISOString()}`);
    
    const results = {};
    
    // 1. Analyze sniper contract
    console.log(`\n1️⃣ ANALYZING SNIPER CONTRACT...`);
    results.sniperAnalysis = await this.analyzeSniperContract();
    
    // 2. Analyze failed transaction
    console.log(`\n2️⃣ ANALYZING FAILED TRANSACTION...`);
    results.transactionAnalysis = await this.analyzeFailedTransaction();
    
    // 3. Test direct Uniswap V3 (if private key provided)
    if (privateKey) {
      console.log(`\n3️⃣ TESTING DIRECT UNISWAP V3...`);
      results.uniswapTest = await this.testDirectUniswapV3(privateKey);
    } else {
      console.log(`\n3️⃣ SKIPPING UNISWAP TEST (no private key provided)`);
      results.uniswapTest = { skipped: true, reason: 'No private key' };
    }
    
    // 4. Generate recommendations
    console.log(`\n4️⃣ GENERATING RECOMMENDATIONS...`);
    results.recommendations = this.generateRecommendations(results);
    
    console.log(`\n✅ DIAGNOSIS COMPLETE!`);
    console.log(`🕐 Finished at: ${new Date().toISOString()}`);
    
    return results;
  }

  /**
   * GENERATE RECOMMENDATIONS
   * Based on diagnostic results
   */
  generateRecommendations(results) {
    console.log(`💡 ========== RECOMMENDATIONS ==========`);
    
    const recommendations = [];
    
    // Sniper contract recommendations
    if (results.sniperAnalysis?.exists) {
      if (results.sniperAnalysis.isProxy) {
        recommendations.push({
          priority: 'HIGH',
          issue: 'Proxy Contract Issues',
          solution: 'The sniper contract is a proxy. It may have access controls or be paused.',
          action: 'Switch to direct Uniswap V3 Router approach'
        });
      }
    } else {
      recommendations.push({
        priority: 'CRITICAL',
        issue: 'Sniper Contract Not Found',
        solution: 'The sniper contract does not exist or is not accessible.',
        action: 'Use direct Uniswap V3 Router exclusively'
      });
    }
    
    // Transaction analysis recommendations
    if (results.transactionAnalysis?.receipt?.gasUsed) {
      const gasUsedPercent = (results.transactionAnalysis.receipt.gasUsed.toNumber() / 800000) * 100;
      if (gasUsedPercent < 10) {
        recommendations.push({
          priority: 'HIGH',
          issue: 'Early Revert Pattern',
          solution: `Transaction used only ${gasUsedPercent.toFixed(2)}% of gas, indicating early revert.`,
          action: 'Contract is rejecting calls due to access control or parameter validation'
        });
      }
    }
    
    // Uniswap test recommendations
    if (results.uniswapTest?.success) {
      recommendations.push({
        priority: 'SOLUTION',
        issue: 'Direct Uniswap V3 Works',
        solution: 'Gas estimation succeeded for direct Uniswap V3 Router.',
        action: 'Use direct Uniswap V3 Router as primary method'
      });
    } else if (results.uniswapTest?.error) {
      recommendations.push({
        priority: 'MEDIUM',
        issue: 'Direct Uniswap V3 Issues',
        solution: `Direct approach failed: ${results.uniswapTest.error}`,
        action: 'Adjust slippage or check token approvals'
      });
    }
    
    // Print recommendations
    recommendations.forEach((rec, i) => {
      console.log(`${i + 1}. [${rec.priority}] ${rec.issue}`);
      console.log(`   💡 ${rec.solution}`);
      console.log(`   🎯 ${rec.action}`);
      console.log(``);
    });
    
    return recommendations;
  }
}

// Export for use in other files
module.exports = DiagnosticTool;

// If run directly, execute diagnosis
if (require.main === module) {
  const diagnostic = new DiagnosticTool();
  
  // Get private key from environment or command line
  const privateKey = process.env.PRIVATE_KEY || process.argv[2];
  
  diagnostic.runFullDiagnosis(privateKey)
    .then(results => {
      console.log(`\n📊 ========== FINAL RESULTS ==========`);
      console.log(JSON.stringify(results, null, 2));
    })
    .catch(error => {
      console.error(`❌ Diagnosis failed:`, error);
    });
}