/**
 * TEST SOLANA TOKEN FIX
 * Test the specific Solana token that was failing
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 100)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 100)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function testSolanaTokenFix() {
  console.log('🧪 ========== SOLANA TOKEN FIX TEST ==========');

  try {
    // Initialize all components
    console.log('🔧 Initializing components...');
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ All components initialized successfully');

    // Test the specific failing Solana token
    console.log('\n📍 TESTING FAILING SOLANA TOKEN');
    
    const solanaMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '27U6sAYSDUJLpeCTTL5gW2wSwLGNRZRZKWJEqTWGbonk', // The failing token
      from: { id: testUserId }
    };

    console.log('🎯 Testing Solana token that was failing...');
    console.log(`   Token: ${solanaMessage.text}`);
    
    try {
      await callbacks.buyTokenUI.handleContractAddress(solanaMessage);
      
      // Check results
      const errorMessages = mockBot.messages.filter(msg => 
        msg.text && msg.text.includes('❌ Token Analysis Failed')
      );
      
      const successMessages = mockBot.messages.filter(msg => 
        msg.text && msg.text.includes('🔍 Analyzing Token')
      );
      
      const editedMessages = mockBot.edits.filter(edit => 
        edit.text && (edit.text.includes('NFT') || edit.text.includes('Token'))
      );
      
      console.log('\n📊 ========== RESULTS ==========');
      console.log(`📤 Total messages: ${mockBot.messages.length}`);
      console.log(`✏️ Total edits: ${mockBot.edits.length}`);
      console.log(`❌ Error messages: ${errorMessages.length}`);
      console.log(`✅ Success messages: ${successMessages.length}`);
      console.log(`📝 Token info edits: ${editedMessages.length}`);
      
      if (errorMessages.length > 0) {
        console.log('\n❌ STILL FAILING:');
        errorMessages.forEach(msg => {
          console.log(`   Error: ${msg.text.substring(0, 200)}...`);
        });
        return false;
      } else if (editedMessages.length > 0) {
        console.log('\n✅ SUCCESS - TOKEN INFO DISPLAYED:');
        editedMessages.forEach(edit => {
          console.log(`   Info: ${edit.text.substring(0, 200)}...`);
        });
        return true;
      } else {
        console.log('\n⚠️ UNKNOWN STATE - No clear success or failure');
        return false;
      }
      
    } catch (testError) {
      console.error('\n❌ TEST ERROR:', testError.message);
      console.error('❌ STACK:', testError.stack);
      return false;
    }

  } catch (error) {
    console.error('❌ SETUP ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
testSolanaTokenFix().then(success => {
  if (success) {
    console.log('\n🎉 ========== SOLANA TOKEN FIX SUCCESSFUL! ==========');
    console.log('✅ The failing Solana token now works correctly!');
    console.log('🚀 Bot should now respond to token addresses properly!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== SOLANA TOKEN STILL FAILING ==========');
    console.log('❌ Need to investigate further');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});