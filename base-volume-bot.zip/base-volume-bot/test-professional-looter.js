#!/usr/bin/env node

/**
 * TEST PROFESSIONAL LOOTER SYSTEM
 * Test the real technique used by professional Looter bots
 */

require('dotenv').config();
const ProfessionalLooterSystem = require('./chains/base/professional-looter-system');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const { ethers } = require('ethers');

async function testProfessionalLooter() {
  try {
    console.log('🤖 ========== TESTING PROFESSIONAL LOOTER SYSTEM ==========');
    console.log('🎯 Using REAL professional techniques:');
    console.log('   1. Pool Discovery - Find ALL Uniswap V3 pools');
    console.log('   2. Pre-calculation - Calculate EXACT outputs');
    console.log('   3. Best Pool Selection - Choose highest output');
    console.log('   4. Professional Execution - Use calculated values');
    
    // Setup
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const professionalLooter = new ProfessionalLooterSystem(provider);
    
    // Get wallet
    const userId = 6537510183;
    const chainWallets = await walletManager.getChainWallets(userId, 'base');
    const wallet = chainWallets['W1'];
    
    if (!wallet) {
      throw new Error('W1 wallet not found');
    }
    
    console.log(`👤 Using wallet: ${wallet.address}`);
    
    // Check wallet balance
    const provider_wallet = new ethers.Wallet(wallet.privateKey, provider);
    const balance = await provider_wallet.getBalance();
    console.log(`💰 ETH Balance: ${ethers.utils.formatEther(balance)} ETH`);
    
    // Test tokens
    const testTokens = [
      {
        name: 'TONY Token (From successful transaction)',
        address: '0x36a947baa2492c72bf9d3307117237e79145a87d', // EXACT same token
        amount: 0.001 // Small test amount
      },
      {
        name: 'USDC (Control test)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      }
    ];
    
    for (const token of testTokens) {
      console.log(`\n🎯 ========== TESTING: ${token.name} ==========`);
      console.log(`📍 Address: ${token.address}`);
      console.log(`💰 Amount: ${token.amount} ETH`);
      
      console.log(`\n🚀 EXECUTING PROFESSIONAL LOOTER SYSTEM...`);
      console.log(`⚠️  This will execute a REAL transaction!`);
      console.log(`🤖 Using PROFESSIONAL pool discovery and pre-calculation`);
      
      // Execute the professional looter system
      const result = await professionalLooter.execBuy(
        wallet.privateKey,
        token.address,
        token.amount
      );
      
      console.log(`\n🎉 PROFESSIONAL LOOTER RESULT:`, result);
      
      if (result.success) {
        console.log(`✅ SUCCESS!`);
        console.log(`📝 Transaction: ${result.txHash}`);
        console.log(`⛽ Gas used: ${result.gasUsed}`);
        console.log(`🪙 Tokens received: ${result.tokensReceived}`);
        console.log(`🎯 Expected tokens: ${result.expectedTokens}`);
        console.log(`🏆 Pool used: ${result.pool}`);
        console.log(`💸 Fee: ${result.fee / 10000}%`);
        console.log(`🔧 Method: ${result.method}`);
        console.log(`📊 Token info:`, result.tokenInfo);
      } else {
        console.log(`❌ FAILED: ${result.error}`);
        console.log(`🔧 Method: ${result.method}`);
      }
      
      // Only test one token to save gas
      break;
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ PROFESSIONAL LOOTER TEST COMPLETE');
    console.log('🤖 System uses REAL professional techniques');
    console.log('🔍 Discovers ALL pools and pre-calculates outputs');
    console.log('🏆 Selects best pool automatically');
    console.log('🎯 Executes with professional precision');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testProfessionalLooter();