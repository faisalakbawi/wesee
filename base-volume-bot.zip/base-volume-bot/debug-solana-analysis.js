/**
 * DEBUG SOLANA ANALYSIS
 * Deep dive into what's failing in Solana token analysis
 */

const ChainManager = require('./chains/chain-manager');
const TokenAnalyzer = require('./trading/token-analyzer');

async function debugSolanaAnalysis() {
  console.log('🔍 ========== DEBUG SOLANA ANALYSIS ==========');
  
  try {
    // Initialize components
    console.log('🔧 Initializing components...');
    const chainManager = new ChainManager();
    const tokenAnalyzer = new TokenAnalyzer(chainManager);
    
    // Test with the failing Solana token
    const testAddress = '27U6sAYSDUJLpeCTTL5gW2wSwLGNRZRZKWJEqTWGbonk';
    console.log('🎯 Testing failing Solana token:', testAddress);
    
    console.log('\n🔍 Step 1: Detecting blockchain...');
    const blockchainType = tokenAnalyzer.detectBlockchain(testAddress);
    console.log('✅ Blockchain type:', blockchainType);
    
    if (blockchainType === 'solana') {
      console.log('\n🔍 Step 2: Testing analyzeSolanaToken directly...');
      try {
        const result = await tokenAnalyzer.analyzeSolanaToken(testAddress);
        console.log('✅ Direct Solana analysis result:', result);
        
        console.log('\n🔍 Step 3: Testing full analyzeToken method...');
        const fullResult = await tokenAnalyzer.analyzeToken(testAddress);
        console.log('✅ Full analysis result:', fullResult);
        
        if (fullResult.success) {
          console.log('✅ SUCCESS: Analysis working correctly');
          console.log('📊 Token data:', JSON.stringify(fullResult.data, null, 2));
        } else {
          console.log('❌ FAILED: Analysis error');
          console.log('❌ Error:', fullResult.error);
        }
        
      } catch (solanaError) {
        console.error('❌ Solana analysis error:', solanaError.message);
        console.error('❌ Stack:', solanaError.stack);
        
        // Let's test the individual components
        console.log('\n🔍 Step 4: Testing individual components...');
        
        try {
          console.log('🔍 Testing getSolanaTokenInfo...');
          const tokenInfo = await tokenAnalyzer.getSolanaTokenInfo(testAddress);
          console.log('✅ Token info:', tokenInfo);
        } catch (infoError) {
          console.error('❌ Token info error:', infoError.message);
        }
        
        try {
          console.log('🔍 Testing getSolanaTokenPrice...');
          const priceData = await tokenAnalyzer.getSolanaTokenPrice(testAddress);
          console.log('✅ Price data:', priceData);
        } catch (priceError) {
          console.error('❌ Price data error:', priceError.message);
        }
        
        try {
          console.log('🔍 Testing calculateSolanaPriceImpact...');
          const priceImpact = await tokenAnalyzer.calculateSolanaPriceImpact(testAddress, '0.01');
          console.log('✅ Price impact:', priceImpact);
        } catch (impactError) {
          console.error('❌ Price impact error:', impactError.message);
        }
      }
    }
    
  } catch (error) {
    console.error('❌ DEBUG ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugSolanaAnalysis().then(() => {
  console.log('\n🎉 Debug completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});