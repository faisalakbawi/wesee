/**
 * CHECK DATABASE DIRECT
 * Direct database query to see what wallets are actually stored
 */

const { Pool } = require('pg');

async function checkDatabaseDirect() {
  console.log('🗄️ ========== DIRECT DATABASE CHECK ==========');

  const pool = new Pool({
    user: process.env.DB_USER || 'faisal',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'looter_ai_clone',
    password: process.env.DB_PASSWORD || '',
    port: process.env.DB_PORT || 5432,
  });

  try {
    const userId = 12345;
    const expectedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    
    console.log(`🔍 Checking database for user: ${userId}`);
    console.log(`🔍 Expected address: ${expectedAddress}`);
    
    // Check user exists
    const userQuery = 'SELECT * FROM users WHERE telegram_id = $1';
    const userResult = await pool.query(userQuery, [userId]);
    
    if (userResult.rows.length === 0) {
      console.log(`❌ User ${userId} not found in database`);
      return;
    }
    
    console.log(`✅ User found: ${userResult.rows[0].telegram_id}`);
    console.log(`   Created: ${userResult.rows[0].created_at}`);
    console.log(`   Active: ${userResult.rows[0].is_active}`);
    
    // Check all wallets for this user
    const walletQuery = `
      SELECT w.*, c.name as chain_name, c.symbol as chain_symbol
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1
      ORDER BY w.wallet_slot, c.name
    `;
    
    const walletResult = await pool.query(walletQuery, [userResult.rows[0].id]);
    
    console.log(`\n📊 Found ${walletResult.rows.length} wallet records:`);
    
    let foundExpectedWallet = false;
    const walletsByChain = {};
    
    walletResult.rows.forEach(wallet => {
      const chain = wallet.chain_name;
      if (!walletsByChain[chain]) {
        walletsByChain[chain] = [];
      }
      walletsByChain[chain].push(wallet);
      
      if (wallet.address.toLowerCase() === expectedAddress.toLowerCase()) {
        foundExpectedWallet = true;
        console.log(`\n🎯 FOUND YOUR WALLET!`);
        console.log(`   Address: ${wallet.address}`);
        console.log(`   Chain: ${wallet.chain_name}`);
        console.log(`   Slot: ${wallet.wallet_slot}`);
        console.log(`   Imported: ${wallet.is_imported}`);
        console.log(`   Created: ${wallet.created_at}`);
        console.log(`   Updated: ${wallet.updated_at}`);
      }
    });
    
    // Show wallets by chain
    Object.keys(walletsByChain).forEach(chain => {
      console.log(`\n🔗 ${chain.toUpperCase()} CHAIN WALLETS:`);
      walletsByChain[chain].forEach(wallet => {
        const importedStatus = wallet.is_imported ? '📥 IMPORTED' : '🔧 GENERATED';
        const isExpected = wallet.address.toLowerCase() === expectedAddress.toLowerCase();
        const highlight = isExpected ? '🎯 ' : '   ';
        
        console.log(`${highlight}${wallet.wallet_slot}: ${wallet.address}`);
        console.log(`${highlight}   Type: ${importedStatus}`);
        console.log(`${highlight}   Created: ${wallet.created_at}`);
        
        if (isExpected) {
          console.log(`${highlight}   ⭐ THIS IS YOUR IMPORTED WALLET!`);
        }
      });
    });
    
    if (!foundExpectedWallet) {
      console.log(`\n❌ Your expected wallet ${expectedAddress} was NOT found in database`);
      console.log(`💡 The import might have failed or used a different address`);
      
      // Check if there are any recently imported wallets
      const recentQuery = `
        SELECT w.*, c.name as chain_name
        FROM wallets w
        JOIN chains c ON w.chain_id = c.id
        WHERE w.user_id = $1 AND w.is_imported = true
        ORDER BY w.updated_at DESC
        LIMIT 5
      `;
      
      const recentResult = await pool.query(recentQuery, [userResult.rows[0].id]);
      
      if (recentResult.rows.length > 0) {
        console.log(`\n📥 Recent imported wallets found:`);
        recentResult.rows.forEach(wallet => {
          console.log(`   ${wallet.wallet_slot} (${wallet.chain_name}): ${wallet.address}`);
          console.log(`   Imported: ${wallet.updated_at}`);
        });
      } else {
        console.log(`\n💡 No imported wallets found for this user`);
      }
    } else {
      console.log(`\n✅ SUCCESS: Your wallet is in the database!`);
      console.log(`💡 The issue might be with the wallet manager cache or RPC connection`);
    }
    
    // Check for any Base chain wallets specifically
    const baseQuery = `
      SELECT w.*
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1 AND c.name = 'base'
      ORDER BY w.wallet_slot
    `;
    
    const baseResult = await pool.query(baseQuery, [userResult.rows[0].id]);
    
    console.log(`\n🔵 BASE CHAIN SPECIFIC CHECK:`);
    console.log(`   Found ${baseResult.rows.length} Base wallets`);
    
    baseResult.rows.forEach(wallet => {
      const importedStatus = wallet.is_imported ? '📥 IMPORTED' : '🔧 GENERATED';
      const isExpected = wallet.address.toLowerCase() === expectedAddress.toLowerCase();
      
      console.log(`   ${wallet.wallet_slot}: ${wallet.address} [${importedStatus}]`);
      if (isExpected) {
        console.log(`      🎯 THIS IS YOUR IMPORTED WALLET!`);
      }
    });

  } catch (error) {
    console.error('❌ Database error:', error.message);
  } finally {
    await pool.end();
  }
}

checkDatabaseDirect().then(() => {
  console.log('\n🎉 Direct database check completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Database check failed:', error);
  process.exit(1);
});