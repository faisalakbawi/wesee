/**
 * DEBUG BASE WALLETS
 * Debug why Base wallets show 0 balance when user says they have funded wallets
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function debugBaseWallets() {
  console.log('🔍 ========== DEBUG BASE WALLETS ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    const userId = 12345;
    const chain = 'base';
    const expectedFundedAddress = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'; // Your wallet address
    
    console.log(`🔍 Debugging Base wallets for user: ${userId}`);
    console.log(`🔍 Expected funded address: ${expectedFundedAddress}`);
    console.log(`🔍 Chain: ${chain}`);
    
    // Step 1: Check all wallets in database
    console.log(`\n📊 STEP 1: Database wallet check...`);
    const chainWallets = await walletManager.getChainWallets(userId, chain);
    
    console.log(`📊 Found ${Object.keys(chainWallets).length} wallets in database:`);
    
    let foundExpectedWallet = false;
    
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = chainWallets[walletSlot];
      
      if (wallet) {
        const isExpected = wallet.address.toLowerCase() === expectedFundedAddress.toLowerCase();
        const importedStatus = wallet.isImported ? '📥 IMPORTED' : '🔧 GENERATED';
        
        console.log(`\n${walletSlot}: ${wallet.address}`);
        console.log(`   Type: ${importedStatus}`);
        console.log(`   Created: ${new Date(wallet.createdAt).toLocaleString()}`);
        console.log(`   Expected wallet: ${isExpected ? '🎯 YES!' : '❌ No'}`);
        
        if (isExpected) {
          foundExpectedWallet = true;
          console.log(`   🎉 FOUND YOUR EXPECTED WALLET IN ${walletSlot}!`);
        }
      } else {
        console.log(`\n${walletSlot}: EMPTY`);
      }
    }
    
    if (!foundExpectedWallet) {
      console.log(`\n❌ ISSUE FOUND: Your expected wallet ${expectedFundedAddress} is NOT in the database`);
      console.log(`💡 This means the wallet import failed or was never completed`);
      console.log(`💡 You need to import your wallet again through the Telegram bot`);
    }
    
    // Step 2: Test Base RPC connection directly
    console.log(`\n🌐 STEP 2: Testing Base RPC connection...`);
    
    try {
      const baseProvider = chainManager.getProvider('base');
      console.log(`✅ Base provider obtained`);
      
      // Test basic RPC call
      const blockNumber = await baseProvider.getBlockNumber();
      console.log(`✅ Base RPC working - Current block: ${blockNumber}`);
      
      // Test balance check for your expected address
      console.log(`\n💰 Testing balance check for your expected address...`);
      const balance = await baseProvider.getBalance(expectedFundedAddress);
      const balanceEth = parseFloat(balance.toString()) / 1e18;
      
      console.log(`🔍 Direct RPC balance check:`);
      console.log(`   Address: ${expectedFundedAddress}`);
      console.log(`   Balance: ${balanceEth} ETH`);
      
      if (balanceEth > 0) {
        console.log(`   🎉 SUCCESS: Your wallet HAS ${balanceEth} ETH on Base!`);
        console.log(`   💡 The issue is that this wallet is not imported in the bot`);
        console.log(`   💡 You need to import this wallet through Telegram bot`);
      } else {
        console.log(`   ⚠️ Your expected wallet shows 0 ETH on Base`);
        console.log(`   💡 Please double-check:`);
        console.log(`      1. The address is correct`);
        console.log(`      2. The funds are on Base network (not Ethereum mainnet)`);
        console.log(`      3. The wallet actually has ETH (not just tokens)`);
      }
      
    } catch (error) {
      console.error(`❌ Base RPC connection failed:`, error.message);
      console.log(`💡 This could explain why all wallets show 0 balance`);
    }
    
    // Step 3: Test balance checking for existing wallets
    console.log(`\n🔍 STEP 3: Testing balance checking for existing wallets...`);
    
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = chainWallets[walletSlot];
      
      if (wallet) {
        console.log(`\n🔍 Testing balance for ${walletSlot}: ${wallet.address}`);
        
        try {
          // Test direct RPC call
          const baseProvider = chainManager.getProvider('base');
          const balance = await baseProvider.getBalance(wallet.address);
          const balanceEth = parseFloat(balance.toString()) / 1e18;
          
          console.log(`   Direct RPC: ${balanceEth} ETH`);
          
          // Test through wallet manager
          const managerBalance = await walletManager.getWalletBalance(wallet.address, chain);
          console.log(`   Manager method: ${managerBalance} ETH`);
          
          if (balanceEth !== parseFloat(managerBalance)) {
            console.log(`   ⚠️ MISMATCH: Direct RPC vs Manager method`);
          } else {
            console.log(`   ✅ MATCH: Both methods agree`);
          }
          
        } catch (error) {
          console.error(`   ❌ Balance check failed:`, error.message);
        }
      }
    }
    
    // Step 4: Recommendations
    console.log(`\n${'='.repeat(60)}`);
    console.log(`💡 RECOMMENDATIONS`);
    console.log(`${'='.repeat(60)}`);
    
    if (!foundExpectedWallet) {
      console.log(`\n🔧 WALLET IMPORT ISSUE:`);
      console.log(`   ❌ Your funded wallet is not imported in the bot`);
      console.log(`   💡 Solution: Import your wallet again`);
      console.log(`   📱 Steps:`);
      console.log(`      1. Go to Telegram bot`);
      console.log(`      2. Click "💼 Manage Wallets"`);
      console.log(`      3. Select "Base" network`);
      console.log(`      4. Click "📥 Import Wallet"`);
      console.log(`      5. Choose "🔑 Private Key"`);
      console.log(`      6. Send your private key`);
      console.log(`      7. Confirm the import`);
    } else {
      console.log(`\n✅ WALLET FOUND IN DATABASE`);
      console.log(`   🔧 But showing 0 balance - possible RPC issue`);
    }
    
    console.log(`\n🔧 TESTING STEPS:`);
    console.log(`   1. Import your funded wallet if not already done`);
    console.log(`   2. Run this test again to verify import`);
    console.log(`   3. Test the trading flow with imported wallet`);
    console.log(`   4. The system should show 💰 for funded wallets`);
    
    console.log(`\n🎯 EXPECTED RESULT AFTER IMPORT:`);
    console.log(`   • Your wallet appears in one of W1-W5 slots`);
    console.log(`   • Wallet shows as 📥 IMPORTED`);
    console.log(`   • Balance shows your actual ETH amount`);
    console.log(`   • Button shows 💰 instead of ⚪`);
    console.log(`   • Trading works successfully`);

  } catch (error) {
    console.error('❌ DEBUG ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugBaseWallets().then(() => {
  console.log('\n🎉 Base wallet debug completed!');
  console.log('💡 Follow the recommendations above to fix the issue');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});