#!/usr/bin/env node

/**
 * TEST EXACT LOOTER CONTRACT
 * Test the deployed Looter contract with the exact same execBuy() function
 */

require('dotenv').config();
const ExactLooterIntegration = require('./chains/base/exact-looter-integration');
const { ethers } = require('ethers');

async function testExactLooterContract() {
  try {
    console.log('🏭 ========== TESTING EXACT LOOTER CONTRACT ==========');
    
    // Setup Base provider
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    
    // Contract address (replace with your deployed contract)
    const DEPLOYED_CONTRACT = '0x1234567890123456789012345678901234567890'; // Replace with real address
    
    if (DEPLOYED_CONTRACT === '0x1234567890123456789012345678901234567890') {
      console.log('⚠️  Please deploy the contract first and update the address!');
      console.log('📋 Follow the deployment guide in contracts/DEPLOYMENT-GUIDE.md');
      return;
    }
    
    // Initialize Exact Looter Integration
    const looterContract = new ExactLooterIntegration(provider, DEPLOYED_CONTRACT);
    
    // Test tokens
    const testTokens = [
      {
        name: 'TONY Token (No Liquidity)',
        address: '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D',
        amount: 0.001
      },
      {
        name: 'USDC (High Liquidity)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      }
    ];
    
    for (const token of testTokens) {
      console.log(`\n🎯 Testing: ${token.name}`);
      console.log(`📍 Address: ${token.address}`);
      console.log(`🏭 Contract: ${DEPLOYED_CONTRACT}`);
      
      // 1. Check liquidity using contract
      console.log('\n1️⃣ CONTRACT LIQUIDITY CHECK:');
      const liquidityInfo = await looterContract.checkContractLiquidity(token.address);
      console.log('💧 Contract liquidity info:', liquidityInfo);
      
      // 2. Simulate execBuy() call
      console.log('\n2️⃣ SIMULATE EXECBUY() CALL:');
      const simulation = await looterContract.simulateExactLooterBuy(token.address, token.amount);
      console.log('🧪 Simulation result:', simulation);
      
      if (simulation.success) {
        console.log('✅ Contract would execute successfully');
        console.log('🎯 Ready for real execBuy() call');
      } else {
        console.log('❌ Contract would fail:', simulation.error);
      }
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ EXACT LOOTER CONTRACT TEST COMPLETE');
    console.log('💡 Deploy the contract and update the address to test real execBuy() calls!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testExactLooterContract();