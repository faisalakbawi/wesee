#!/usr/bin/env node

/**
 * TOKEN INTELLIGENCE SYSTEM
 * Analyzes tokens to find ALL pools, DEXs, and liquidity providers
 * Prepares optimal trading strategy for each token
 */

require('dotenv').config();
const { ethers } = require('ethers');

class TokenIntelligenceSystem {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    
    // All DEXs and their details on Base
    this.dexes = {
      'uniswap-v3': {
        name: 'Uniswap V3',
        factory: '0x33128a8fC17869897dcE68Ed026d694621f6FDfD',
        router: '0x2626664c2603336E57B271c5C0b26F421741e481',
        type: 'v3',
        fees: [100, 500, 3000, 10000],
        priority: 1
      },
      'sushiswap': {
        name: 'SushiSwap',
        factory: '0x71524B4f93c58fcbF659783284E38825f0622859',
        router: '0x6BDED42c6DA8FBf0d2bA55B2fa120C5e0c8D7891',
        type: 'v2',
        fees: [3000],
        priority: 2
      },
      'pancakeswap': {
        name: 'PancakeSwap',
        factory: '0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865',
        router: '0x678Aa4bF4E210cf2166753e054d5b7c31cc7fa86',
        type: 'v2',
        fees: [2500],
        priority: 3
      },
      'baseswap': {
        name: 'BaseSwap',
        factory: '0xFDa619b6d20975be80A10332cD39b9a4b0FAa8BB',
        router: '0x327Df1E6de05895d2ab08513aaDD9313Fe505d86',
        type: 'v2',
        fees: [3000],
        priority: 4
      },
      'aerodrome': {
        name: 'Aerodrome',
        factory: '0x420DD381b31aEf6683db6B902084cB0FFECe40Da',
        router: '0xcF77a3Ba9A5CA399B7c97c74d54e5b1Beb874E43',
        type: 'v2',
        fees: [3000],
        priority: 5
      }
    };
    
    this.WETH = '0x4200000000000000000000000000000000000006';
    
    // Token intelligence cache
    this.tokenIntelligence = new Map();
    
    this.abis = {
      ERC20: [
        'function name() external view returns (string)',
        'function symbol() external view returns (string)',
        'function decimals() external view returns (uint8)',
        'function totalSupply() external view returns (uint256)',
        'function balanceOf(address account) external view returns (uint256)'
      ],
      
      UNISWAP_V3_FACTORY: [
        'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)'
      ],
      
      UNISWAP_V2_FACTORY: [
        'function getPair(address tokenA, address tokenB) external view returns (address pair)'
      ],
      
      UNISWAP_V3_POOL: [
        'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
        'function liquidity() external view returns (uint128)',
        'function token0() external view returns (address)',
        'function token1() external view returns (address)',
        'function fee() external view returns (uint24)',
        'function tickSpacing() external view returns (int24)'
      ],
      
      UNISWAP_V2_PAIR: [
        'function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)',
        'function token0() external view returns (address)',
        'function token1() external view returns (address)',
        'function totalSupply() external view returns (uint256)'
      ]
    };
  }
  
  /**
   * ANALYZE TOKEN - Find ALL pools and liquidity
   */
  async analyzeToken(tokenAddress) {
    console.log('🧠 ========== TOKEN INTELLIGENCE ANALYSIS ==========');
    console.log(`🎯 Analyzing: ${tokenAddress}`);
    console.log('🔍 Finding ALL pools, DEXs, and liquidity providers...\n');
    
    const tokenAddress_lower = tokenAddress.toLowerCase();
    
    // Check cache first
    if (this.tokenIntelligence.has(tokenAddress_lower)) {
      console.log('💾 Using cached intelligence...');
      return this.tokenIntelligence.get(tokenAddress_lower);
    }
    
    try {
      // Get token basic info
      const tokenInfo = await this.getTokenInfo(tokenAddress);
      console.log(`📋 Token: ${tokenInfo.name} (${tokenInfo.symbol}) - ${tokenInfo.decimals} decimals`);
      console.log(`📊 Total Supply: ${ethers.utils.formatUnits(tokenInfo.totalSupply, tokenInfo.decimals)}\n`);
      
      // Find all pools across all DEXs
      const allPools = [];
      
      for (const [dexId, dex] of Object.entries(this.dexes)) {
        console.log(`🔍 Scanning ${dex.name}...`);
        
        try {
          const pools = await this.findPoolsOnDex(tokenAddress, dex, tokenInfo);
          allPools.push(...pools);
          
          if (pools.length > 0) {
            console.log(`  ✅ Found ${pools.length} pool(s) on ${dex.name}`);
            for (const pool of pools) {
              console.log(`    🏊 Pool: ${pool.address}`);
              console.log(`    💧 Liquidity: ${pool.liquidityInfo}`);
              console.log(`    💸 Fee: ${pool.fee ? (pool.fee / 10000) + '%' : 'N/A'}`);
              console.log(`    📊 Score: ${pool.liquidityScore}/100`);
            }
          } else {
            console.log(`  ❌ No pools found on ${dex.name}`);
          }
          
        } catch (error) {
          console.log(`  ⚠️ Error scanning ${dex.name}: ${error.message}`);
        }
        
        console.log('');
      }
      
      // Sort pools by liquidity score
      allPools.sort((a, b) => b.liquidityScore - a.liquidityScore);
      
      // Create intelligence report
      const intelligence = {
        tokenAddress: tokenAddress_lower,
        tokenInfo,
        pools: allPools,
        bestPool: allPools[0] || null,
        totalPools: allPools.length,
        availableDexs: [...new Set(allPools.map(p => p.dexName))],
        lastAnalyzed: Date.now(),
        tradingStrategy: this.createTradingStrategy(allPools)
      };
      
      // Cache the intelligence
      this.tokenIntelligence.set(tokenAddress_lower, intelligence);
      
      // Print summary
      this.printIntelligenceSummary(intelligence);
      
      return intelligence;
      
    } catch (error) {
      console.error('❌ Token analysis failed:', error.message);
      throw error;
    }
  }
  
  /**
   * GET TOKEN BASIC INFO
   */
  async getTokenInfo(tokenAddress) {
    const token = new ethers.Contract(tokenAddress, this.abis.ERC20, this.provider);
    
    const [name, symbol, decimals, totalSupply] = await Promise.all([
      token.name().catch(() => 'Unknown'),
      token.symbol().catch(() => 'UNK'),
      token.decimals().catch(() => 18),
      token.totalSupply().catch(() => ethers.BigNumber.from(0))
    ]);
    
    return { name, symbol, decimals, totalSupply };
  }
  
  /**
   * FIND POOLS ON SPECIFIC DEX
   */
  async findPoolsOnDex(tokenAddress, dex, tokenInfo) {
    const pools = [];
    
    try {
      const factory = new ethers.Contract(dex.factory, 
        dex.type === 'v3' ? this.abis.UNISWAP_V3_FACTORY : this.abis.UNISWAP_V2_FACTORY, 
        this.provider
      );
      
      if (dex.type === 'v3') {
        // Check all fee tiers for V3
        for (const fee of dex.fees) {
          try {
            const poolAddress = await factory.getPool(tokenAddress, this.WETH, fee);
            
            if (poolAddress !== ethers.constants.AddressZero) {
              const poolInfo = await this.analyzeV3Pool(poolAddress, tokenAddress, tokenInfo, dex, fee);
              if (poolInfo) {
                pools.push(poolInfo);
              }
            }
          } catch (error) {
            // Skip this fee tier
          }
        }
      } else {
        // Check V2 pair
        try {
          const pairAddress = await factory.getPair(tokenAddress, this.WETH);
          
          if (pairAddress !== ethers.constants.AddressZero) {
            const pairInfo = await this.analyzeV2Pair(pairAddress, tokenAddress, tokenInfo, dex);
            if (pairInfo) {
              pools.push(pairInfo);
            }
          }
        } catch (error) {
          // Skip this DEX
        }
      }
      
    } catch (error) {
      // Skip this DEX entirely
    }
    
    return pools;
  }
  
  /**
   * ANALYZE V3 POOL
   */
  async analyzeV3Pool(poolAddress, tokenAddress, tokenInfo, dex, fee) {
    try {
      const pool = new ethers.Contract(poolAddress, this.abis.UNISWAP_V3_POOL, this.provider);
      
      const [slot0, liquidity, token0, token1] = await Promise.all([
        pool.slot0(),
        pool.liquidity(),
        pool.token0(),
        pool.token1()
      ]);
      
      // Check token balances
      const tokenContract = new ethers.Contract(tokenAddress, this.abis.ERC20, this.provider);
      const wethContract = new ethers.Contract(this.WETH, this.abis.ERC20, this.provider);
      
      const [tokenBalance, wethBalance] = await Promise.all([
        tokenContract.balanceOf(poolAddress),
        wethContract.balanceOf(poolAddress)
      ]);
      
      // Calculate liquidity score
      const wethValue = parseFloat(ethers.utils.formatEther(wethBalance));
      const tokenValue = parseFloat(ethers.utils.formatUnits(tokenBalance, tokenInfo.decimals));
      
      let liquidityScore = 0;
      if (wethValue > 0 && tokenValue > 0) {
        liquidityScore = Math.min(100, Math.floor(wethValue * 20)); // 1 WETH = 20 points, max 100
      }
      
      // Only include pools with actual liquidity
      if (liquidityScore > 0 && slot0.unlocked) {
        return {
          address: poolAddress,
          dexId: Object.keys(this.dexes).find(id => this.dexes[id].factory === dex.factory),
          dexName: dex.name,
          router: dex.router,
          type: 'v3',
          fee: fee,
          token0: token0,
          token1: token1,
          liquidity: liquidity.toString(),
          tokenBalance: ethers.utils.formatUnits(tokenBalance, tokenInfo.decimals),
          wethBalance: ethers.utils.formatEther(wethBalance),
          liquidityInfo: `${ethers.utils.formatEther(wethBalance)} WETH + ${ethers.utils.formatUnits(tokenBalance, tokenInfo.decimals)} ${tokenInfo.symbol}`,
          liquidityScore: liquidityScore,
          currentTick: slot0.tick,
          sqrtPriceX96: slot0.sqrtPriceX96.toString(),
          unlocked: slot0.unlocked,
          priority: dex.priority
        };
      }
      
    } catch (error) {
      // Skip this pool
    }
    
    return null;
  }
  
  /**
   * ANALYZE V2 PAIR
   */
  async analyzeV2Pair(pairAddress, tokenAddress, tokenInfo, dex) {
    try {
      const pair = new ethers.Contract(pairAddress, this.abis.UNISWAP_V2_PAIR, this.provider);
      
      const [reserves, token0, token1, totalSupply] = await Promise.all([
        pair.getReserves(),
        pair.token0(),
        pair.token1()
      ]);
      
      const isTokenToken0 = token0.toLowerCase() === tokenAddress.toLowerCase();
      const tokenReserve = isTokenToken0 ? reserves.reserve0 : reserves.reserve1;
      const wethReserve = isTokenToken0 ? reserves.reserve1 : reserves.reserve0;
      
      // Calculate liquidity score
      const wethValue = parseFloat(ethers.utils.formatEther(wethReserve));
      const tokenValue = parseFloat(ethers.utils.formatUnits(tokenReserve, tokenInfo.decimals));
      
      let liquidityScore = 0;
      if (wethValue > 0 && tokenValue > 0) {
        liquidityScore = Math.min(100, Math.floor(wethValue * 20)); // 1 WETH = 20 points, max 100
      }
      
      // Only include pairs with actual liquidity
      if (liquidityScore > 0) {
        return {
          address: pairAddress,
          dexId: Object.keys(this.dexes).find(id => this.dexes[id].factory === dex.factory),
          dexName: dex.name,
          router: dex.router,
          type: 'v2',
          fee: dex.fees[0], // V2 has standard fee
          token0: token0,
          token1: token1,
          tokenReserve: ethers.utils.formatUnits(tokenReserve, tokenInfo.decimals),
          wethReserve: ethers.utils.formatEther(wethReserve),
          liquidityInfo: `${ethers.utils.formatEther(wethReserve)} WETH + ${ethers.utils.formatUnits(tokenReserve, tokenInfo.decimals)} ${tokenInfo.symbol}`,
          liquidityScore: liquidityScore,
          priority: dex.priority
        };
      }
      
    } catch (error) {
      // Skip this pair
    }
    
    return null;
  }
  
  /**
   * CREATE TRADING STRATEGY
   */
  createTradingStrategy(pools) {
    if (pools.length === 0) {
      return {
        recommended: 'none',
        reason: 'No pools with liquidity found',
        fallback: 'Try alternative tokens or wait for liquidity'
      };
    }
    
    const bestPool = pools[0];
    const strategy = {
      recommended: bestPool.dexName,
      pool: bestPool.address,
      router: bestPool.router,
      type: bestPool.type,
      fee: bestPool.fee,
      liquidityScore: bestPool.liquidityScore,
      reason: `Best liquidity (${bestPool.liquidityInfo})`,
      method: bestPool.type === 'v3' ? 'exactInputSingle' : 'swapExactETHForTokens',
      maxTradeSize: Math.min(0.01, parseFloat(bestPool.wethBalance || bestPool.wethReserve || '0') * 0.1), // Max 10% of pool or 0.01 ETH
      alternatives: pools.slice(1, 3).map(p => ({
        dex: p.dexName,
        pool: p.address,
        score: p.liquidityScore
      }))
    };
    
    return strategy;
  }
  
  /**
   * PRINT INTELLIGENCE SUMMARY
   */
  printIntelligenceSummary(intelligence) {
    console.log('📊 ========== INTELLIGENCE SUMMARY ==========');
    console.log(`🪙 Token: ${intelligence.tokenInfo.name} (${intelligence.tokenInfo.symbol})`);
    console.log(`🏊 Total Pools Found: ${intelligence.totalPools}`);
    console.log(`🌐 Available DEXs: ${intelligence.availableDexs.join(', ')}`);
    
    if (intelligence.bestPool) {
      console.log(`\n🎯 RECOMMENDED TRADING STRATEGY:`);
      console.log(`  🏆 Best DEX: ${intelligence.tradingStrategy.recommended}`);
      console.log(`  🏊 Pool: ${intelligence.bestPool.address}`);
      console.log(`  💧 Liquidity: ${intelligence.bestPool.liquidityInfo}`);
      console.log(`  📊 Score: ${intelligence.bestPool.liquidityScore}/100`);
      console.log(`  ⚡ Method: ${intelligence.tradingStrategy.method}`);
      console.log(`  💰 Max Trade Size: ${intelligence.tradingStrategy.maxTradeSize} ETH`);
      
      if (intelligence.tradingStrategy.alternatives.length > 0) {
        console.log(`\n🔄 BACKUP OPTIONS:`);
        intelligence.tradingStrategy.alternatives.forEach((alt, i) => {
          console.log(`    ${i + 1}. ${alt.dex} (Score: ${alt.score}/100)`);
        });
      }
    } else {
      console.log(`\n❌ NO TRADING STRATEGY AVAILABLE`);
      console.log(`💡 Reason: ${intelligence.tradingStrategy.reason}`);
      console.log(`🔧 Suggestion: ${intelligence.tradingStrategy.fallback}`);
    }
    
    console.log('\n✅ TOKEN INTELLIGENCE ANALYSIS COMPLETE\n');
  }
  
  /**
   * GET CACHED INTELLIGENCE
   */
  getTokenIntelligence(tokenAddress) {
    return this.tokenIntelligence.get(tokenAddress.toLowerCase());
  }
  
  /**
   * CLEAR CACHE
   */
  clearCache() {
    this.tokenIntelligence.clear();
  }
}

// Test with TONY token
async function testTonyAnalysis() {
  const intelligence = new TokenIntelligenceSystem();
  
  const tonyAddress = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  try {
    const result = await intelligence.analyzeToken(tonyAddress);
    
    console.log('🎯 ANALYSIS COMPLETE!');
    console.log('💾 Intelligence cached for instant trading');
    
    return result;
    
  } catch (error) {
    console.error('❌ Analysis failed:', error.message);
  }
}

// Export for use in other modules
module.exports = TokenIntelligenceSystem;

// Run test if called directly
if (require.main === module) {
  testTonyAnalysis();
}