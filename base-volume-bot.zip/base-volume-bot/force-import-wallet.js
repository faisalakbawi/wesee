/**
 * FORCE IMPORT WALLET
 * Force replace W5 with your imported wallet
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function forceImportWallet() {
  console.log('🔧 ========== FORCE IMPORT WALLET ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    const yourUserId = 12345;
    const chain = 'base';
    const targetSlot = 'W5';
    
    // IMPORTANT: Replace this with your actual private key
    const yourPrivateKey = 'YOUR_PRIVATE_KEY_HERE'; // Replace with your actual private key
    
    console.log(`🔧 Force importing wallet for user: ${yourUserId}`);
    console.log(`🔧 Target chain: ${chain}`);
    console.log(`🔧 Target slot: ${targetSlot}`);
    
    if (yourPrivateKey === 'YOUR_PRIVATE_KEY_HERE') {
      console.log('❌ Please edit this script and add your actual private key');
      console.log('❌ Replace "YOUR_PRIVATE_KEY_HERE" with your private key');
      process.exit(1);
    }
    
    // Validate private key format
    const cleanKey = yourPrivateKey.replace(/^0x/, '').trim();
    if (!/^[a-fA-F0-9]{64}$/.test(cleanKey)) {
      console.log('❌ Invalid private key format');
      console.log('❌ Private key must be exactly 64 hexadecimal characters');
      process.exit(1);
    }
    
    console.log('✅ Private key format is valid');
    
    // Check current wallet in target slot
    const currentWallets = await walletManager.getChainWallets(yourUserId, chain);
    const currentWallet = currentWallets[targetSlot];
    
    if (currentWallet) {
      console.log(`🔍 Current wallet in ${targetSlot}:`);
      console.log(`   Address: ${currentWallet.address}`);
      console.log(`   Type: ${currentWallet.isImported ? 'IMPORTED' : 'GENERATED'}`);
      const balance = await walletManager.getWalletBalance(currentWallet.address, chain);
      console.log(`   Balance: ${balance} ETH`);
      console.log(`🔄 This wallet will be replaced...`);
    } else {
      console.log(`✅ Slot ${targetSlot} is empty, ready for import`);
    }
    
    // Force replace the wallet using the replaceWalletWithPrivateKey method
    console.log(`🔧 Force replacing wallet in slot ${targetSlot}...`);
    
    const result = await walletManager.replaceWalletWithPrivateKey(
      yourUserId, 
      `0x${cleanKey}`, 
      targetSlot, 
      chain
    );
    
    if (result.success) {
      console.log('✅ WALLET FORCE IMPORT SUCCESSFUL!');
      console.log(`🎯 Address: ${result.address}`);
      console.log(`💼 Slot: ${result.walletSlot}`);
      console.log(`⛓️ Chain: ${result.chain}`);
      
      // Verify the import
      console.log('\n🔍 Verifying import...');
      const updatedWallets = await walletManager.getChainWallets(yourUserId, chain);
      const importedWallet = updatedWallets[targetSlot];
      
      if (importedWallet && importedWallet.address.toLowerCase() === result.address.toLowerCase()) {
        console.log('✅ Import verified successfully!');
        console.log(`✅ Wallet is marked as imported: ${importedWallet.isImported}`);
        
        // Check balance
        const balance = await walletManager.getWalletBalance(importedWallet.address, chain);
        console.log(`💰 Wallet balance: ${balance} ETH`);
        
        if (parseFloat(balance) > 0) {
          console.log('🎉 SUCCESS! Your funded wallet is now in W5 and ready for trading!');
          
          console.log('\n🎯 NEXT STEPS:');
          console.log('1. Go to your Telegram bot');
          console.log('2. Try the "🔥 Buy Token" feature again');
          console.log('3. Send the same contract address: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913');
          console.log('4. The bot should now automatically select W5 (your imported wallet)');
          console.log('5. Trading should work perfectly!');
          
        } else {
          console.log('⚠️ Wallet imported but shows 0 balance. Please check:');
          console.log('   1. The private key is correct');
          console.log('   2. The wallet has ETH on Base network');
          console.log('   3. Network connection is working');
          
          // Let's double-check the address
          console.log('\n🔍 Double-checking your wallet address...');
          console.log(`Expected: 0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A`);
          console.log(`Imported: ${result.address}`);
          
          if (result.address.toLowerCase() === '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'.toLowerCase()) {
            console.log('✅ Address matches! The issue might be:');
            console.log('   - Network connectivity');
            console.log('   - RPC endpoint issues');
            console.log('   - Wallet actually has 0 balance');
          } else {
            console.log('❌ Address does NOT match! Wrong private key was used.');
          }
        }
      } else {
        console.log('❌ Import verification failed');
      }
    } else {
      console.log('❌ WALLET FORCE IMPORT FAILED');
      console.log(`❌ Error: ${result.error}`);
    }

  } catch (error) {
    console.error('❌ ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

forceImportWallet().then(() => {
  console.log('\n🎉 Force import completed');
  console.log('⚠️ SECURITY: Delete your private key from this file now!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Force import failed:', error);
  process.exit(1);
});