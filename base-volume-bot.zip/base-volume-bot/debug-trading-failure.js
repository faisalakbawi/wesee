/**
 * 🔍 DEEP TRADING FAILURE ANALYSIS
 * Analyzing the specific token and trading issues
 */

const ChainManager = require('./chains/chain-manager');
const TokenAnalyzer = require('./trading/token-analyzer');
const WalletManager = require('./database/wallet-db-manager');
const Database = require('./database/database');

class TradingFailureAnalysis {
  constructor() {
    this.chainManager = new ChainManager();
    this.tokenAnalyzer = new TokenAnalyzer(this.chainManager);
    this.database = new Database();
    this.walletManager = new WalletManager(this.database);
    
    // The specific token that failed
    this.failedToken = {
      address: '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D',
      name: 'Based Marie Rose',
      symbol: 'BasedMarie',
      chain: 'base' // Assuming Base chain
    };
  }

  async runDeepAnalysis() {
    console.log('🔍 DEEP TRADING FAILURE ANALYSIS');
    console.log('================================');
    console.log(`🪙 Token: ${this.failedToken.name} (${this.failedToken.symbol})`);
    console.log(`📍 Address: ${this.failedToken.address}`);
    console.log(`🌐 Chain: ${this.failedToken.chain}`);
    
    try {
      // Step 1: Analyze the token thoroughly
      await this.analyzeFailedToken();
      
      // Step 2: Check wallet functionality
      await this.analyzeWalletIssues();
      
      // Step 3: Test trading functions
      await this.analyzeTradingFunctions();
      
      // Step 4: Check liquidity handling
      await this.analyzeLiquidityHandling();
      
      // Step 5: Identify root causes
      await this.identifyRootCauses();
      
    } catch (error) {
      console.error('❌ Analysis failed:', error.message);
    }
  }

  async analyzeFailedToken() {
    console.log('\n🔍 STEP 1: TOKEN ANALYSIS');
    console.log('=========================');
    
    try {
      // Analyze the specific token
      console.log('📊 Analyzing token...');
      const analysis = await this.tokenAnalyzer.analyzeEVMToken(
        this.failedToken.address, 
        this.failedToken.chain
      );
      
      if (analysis) {
        console.log('✅ Token analysis successful:');
        console.log(`   💰 Price: ${analysis.price || 'N/A'}`);
        console.log(`   📊 Market Cap: ${analysis.marketCap || 'N/A'}`);
        console.log(`   💧 Liquidity: ${analysis.liquidity || 'N/A'}`);
        console.log(`   🏷️ Symbol: ${analysis.symbol || 'N/A'}`);
        console.log(`   📈 24h Change: ${analysis.priceChange24h || 'N/A'}`);
        
        // Check if this matches the user's data
        if (analysis.price) {
          const userPrice = 0.00011460;
          const apiPrice = parseFloat(analysis.price);
          const priceDiff = Math.abs(apiPrice - userPrice) / userPrice * 100;
          
          console.log(`\n🔍 Price Comparison:`);
          console.log(`   User saw: $${userPrice}`);
          console.log(`   API shows: $${apiPrice}`);
          console.log(`   Difference: ${priceDiff.toFixed(2)}%`);
          
          if (priceDiff > 10) {
            console.log('   ⚠️ SIGNIFICANT PRICE DIFFERENCE - Possible stale data');
          }
        }
        
        // Analyze liquidity conditions
        if (analysis.liquidity || analysis.marketCap) {
          const liquidityAnalysis = await this.tokenAnalyzer.analyzeLiquidityConditions(analysis);
          console.log(`\n💧 Liquidity Analysis:`);
          console.log(`   📈 Category: ${liquidityAnalysis.liquidityCategory}`);
          console.log(`   ⚠️ Risk Level: ${liquidityAnalysis.riskLevel}`);
          console.log(`   🎯 Recommended Slippage: ${liquidityAnalysis.recommendedSlippage}%`);
          console.log(`   💰 Max Recommended Buy: ${liquidityAnalysis.maxRecommendedBuy} ETH`);
          
          if (liquidityAnalysis.warnings && liquidityAnalysis.warnings.length > 0) {
            console.log(`   ⚠️ Warnings:`);
            liquidityAnalysis.warnings.forEach(warning => {
              console.log(`      - ${warning}`);
            });
          }
        }
        
      } else {
        console.log('❌ Token analysis failed - this could be the root cause');
      }
      
    } catch (error) {
      console.error('❌ Token analysis error:', error.message);
      console.log('🔍 This could be why trading failed');
    }
  }

  async analyzeWalletIssues() {
    console.log('\n💼 STEP 2: WALLET ANALYSIS');
    console.log('==========================');
    
    try {
      // Test wallet functionality
      console.log('🔍 Checking wallet system...');
      
      // Check if we can get wallets for a test user
      const testUserId = 999999999;
      
      try {
        const wallets = await this.walletManager.getChainWallets(testUserId, this.failedToken.chain);
        console.log(`✅ Found ${wallets.length} wallets for chain ${this.failedToken.chain}`);
        
        if (wallets.length > 0) {
          // Check the 5th wallet (W5) specifically
          const wallet5 = wallets[4]; // Index 4 for W5
          if (wallet5) {
            console.log(`\n🔍 Wallet W5 Analysis:`);
            console.log(`   📍 Address: ${wallet5.address}`);
            console.log(`   🏷️ Label: ${wallet5.label}`);
            console.log(`   🌐 Chain: ${wallet5.chain}`);
            
            // Try to get balance
            try {
              const balance = await this.walletManager.getWalletBalance(wallet5.address, this.failedToken.chain);
              console.log(`   💰 Balance: ${balance} ETH`);
              
              if (parseFloat(balance) > 0.001) {
                console.log('   ✅ Sufficient balance for 0.001 ETH trade');
              } else {
                console.log('   ❌ INSUFFICIENT BALANCE - This is the issue!');
              }
              
            } catch (balanceError) {
              console.log(`   ❌ Balance check failed: ${balanceError.message}`);
              console.log('   🔍 This could be why trading failed');
            }
            
          } else {
            console.log('❌ Wallet W5 not found - indexing issue?');
          }
        } else {
          console.log('❌ No wallets found - user needs to create wallets first');
        }
        
      } catch (walletError) {
        console.log(`❌ Wallet retrieval failed: ${walletError.message}`);
      }
      
    } catch (error) {
      console.error('❌ Wallet analysis error:', error.message);
    }
  }

  async analyzeTradingFunctions() {
    console.log('\n🔧 STEP 3: TRADING FUNCTION ANALYSIS');
    console.log('====================================');
    
    try {
      // Get the Base chain instance
      const baseChain = this.chainManager.getChain('base');
      
      if (baseChain) {
        console.log('✅ Base chain instance found');
        
        // Test the trading function with safe parameters
        console.log('\n🧪 Testing trading function...');
        
        try {
          // This should fail gracefully with our test parameters
          await baseChain.executeBuy(
            'test_private_key', // This will fail validation
            this.failedToken.address,
            '0.001',
            10 // 10% slippage
          );
          
        } catch (tradingError) {
          console.log(`🔍 Trading function error: ${tradingError.message}`);
          
          // Analyze the error message
          if (tradingError.message.includes('invalid hexlify')) {
            console.log('✅ Expected error - private key validation working');
          } else if (tradingError.message.includes('insufficient funds')) {
            console.log('❌ INSUFFICIENT FUNDS - Wallet balance issue');
          } else if (tradingError.message.includes('execution reverted')) {
            console.log('❌ TRANSACTION REVERTED - DEX/liquidity issue');
          } else if (tradingError.message.includes('slippage')) {
            console.log('❌ SLIPPAGE TOO HIGH - Need higher slippage tolerance');
          } else {
            console.log('❌ UNKNOWN ERROR - Need deeper investigation');
          }
        }
        
      } else {
        console.log('❌ Base chain not available');
      }
      
    } catch (error) {
      console.error('❌ Trading function analysis error:', error.message);
    }
  }

  async analyzeLiquidityHandling() {
    console.log('\n💧 STEP 4: LIQUIDITY HANDLING ANALYSIS');
    console.log('======================================');
    
    try {
      // Test with the reported market cap
      const reportedMarketCap = 114600; // $114.60K
      const estimatedLiquidity = reportedMarketCap * 0.05; // Estimate 5% of market cap as liquidity
      
      console.log(`📊 Market Cap: $${reportedMarketCap.toLocaleString()}`);
      console.log(`💧 Estimated Liquidity: $${estimatedLiquidity.toLocaleString()}`);
      
      const mockTokenData = {
        marketCap: reportedMarketCap,
        liquidity: estimatedLiquidity,
        volume24h: estimatedLiquidity * 0.1 // Estimate 10% daily volume
      };
      
      const liquidityAnalysis = await this.tokenAnalyzer.analyzeLiquidityConditions(mockTokenData);
      
      console.log(`\n💧 Liquidity Analysis Results:`);
      console.log(`   📈 Category: ${liquidityAnalysis.liquidityCategory}`);
      console.log(`   ⚠️ Risk Level: ${liquidityAnalysis.riskLevel}`);
      console.log(`   🎯 Recommended Slippage: ${liquidityAnalysis.recommendedSlippage}%`);
      console.log(`   💰 Max Recommended Buy: ${liquidityAnalysis.maxRecommendedBuy} ETH`);
      
      // Check if 0.001 ETH is within recommended limits
      if (liquidityAnalysis.maxRecommendedBuy >= 0.001) {
        console.log('✅ 0.001 ETH is within recommended buy limits');
      } else {
        console.log('⚠️ 0.001 ETH exceeds recommended buy limits');
        console.log(`   Recommended max: ${liquidityAnalysis.maxRecommendedBuy} ETH`);
      }
      
      // Check if slippage was sufficient
      const usedSlippage = 10; // Assuming default slippage
      if (liquidityAnalysis.recommendedSlippage <= usedSlippage) {
        console.log(`✅ Slippage ${usedSlippage}% should be sufficient`);
      } else {
        console.log(`❌ SLIPPAGE TOO LOW! Need ${liquidityAnalysis.recommendedSlippage}% but used ${usedSlippage}%`);
        console.log('🔍 This is likely why the transaction failed');
      }
      
    } catch (error) {
      console.error('❌ Liquidity analysis error:', error.message);
    }
  }

  async identifyRootCauses() {
    console.log('\n🎯 STEP 5: ROOT CAUSE IDENTIFICATION');
    console.log('====================================');
    
    const possibleCauses = [
      {
        issue: 'Insufficient Wallet Balance',
        likelihood: 'HIGH',
        description: 'W5 wallet may not have enough ETH for the trade + gas fees',
        solution: 'Check actual wallet balance and ensure sufficient funds'
      },
      {
        issue: 'Slippage Too Low',
        likelihood: 'HIGH', 
        description: 'Low liquidity token needs higher slippage tolerance',
        solution: 'Implement dynamic slippage based on liquidity analysis'
      },
      {
        issue: 'Private Key Issues',
        likelihood: 'MEDIUM',
        description: 'Wallet private key may be corrupted or invalid',
        solution: 'Validate private key before trading'
      },
      {
        issue: 'DEX Routing Problems',
        likelihood: 'MEDIUM',
        description: 'Token may not have sufficient liquidity on available DEXs',
        solution: 'Check multiple DEXs and routing options'
      },
      {
        issue: 'Gas Estimation Failure',
        likelihood: 'MEDIUM',
        description: 'Transaction gas estimation may be failing',
        solution: 'Implement better gas estimation with fallbacks'
      },
      {
        issue: 'Token Contract Issues',
        likelihood: 'LOW',
        description: 'Token contract may have trading restrictions',
        solution: 'Check token contract for trading limitations'
      }
    ];
    
    console.log('\n🔍 MOST LIKELY ROOT CAUSES:');
    console.log('===========================');
    
    possibleCauses
      .filter(cause => cause.likelihood === 'HIGH')
      .forEach((cause, index) => {
        console.log(`\n${index + 1}. ❌ ${cause.issue}`);
        console.log(`   📝 ${cause.description}`);
        console.log(`   🔧 Solution: ${cause.solution}`);
      });
    
    console.log('\n🔧 IMMEDIATE FIXES NEEDED:');
    console.log('==========================');
    console.log('1. 💰 Implement real wallet balance checking before trades');
    console.log('2. 📊 Add dynamic slippage calculation based on liquidity');
    console.log('3. 🔐 Add private key validation before trading');
    console.log('4. ⛽ Improve gas estimation and handling');
    console.log('5. 🔄 Add better error messages and retry logic');
    console.log('6. 🧪 Add pre-trade validation checks');
  }
}

// Run the analysis
async function runAnalysis() {
  const analyzer = new TradingFailureAnalysis();
  await analyzer.runDeepAnalysis();
}

// Export for use in other files
module.exports = TradingFailureAnalysis;

// Run if called directly
if (require.main === module) {
  runAnalysis().catch(console.error);
}