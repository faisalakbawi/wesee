/**
 * SIMPLE TEST INTERFACE
 * Easy way to test the solution with your private key
 */

const { ethers } = require('ethers');
const ProductionReadySolution = require('./PRODUCTION_READY_SOLUTION');

// Configuration
const PROVIDER_URL = 'https://mainnet.base.org';
const TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';

async function testSolution() {
  console.log(`🚀 ========== SIMPLE TEST INTERFACE ==========`);
  console.log(`🕐 Time: ${new Date().toISOString()}`);
  
  // Initialize
  const provider = new ethers.providers.JsonRpcProvider(PROVIDER_URL);
  const solution = new ProductionReadySolution(provider);
  
  console.log(`\n✅ Solution initialized`);
  console.log(`🌐 Connected to Base network`);
  
  // Health check
  console.log(`\n🏥 Running health check...`);
  const health = await solution.healthCheck();
  
  if (!Object.values(health).every(check => check)) {
    console.log(`❌ Health check failed - stopping test`);
    return;
  }
  
  console.log(`\n🎯 ========== READY FOR YOUR TESTING ==========`);
  console.log(`\n📋 To test with your private key, run one of these:`);
  
  console.log(`\n1. DRY RUN (safe - no ETH spent):`);
  console.log(`   testDryRun('YOUR_PRIVATE_KEY_HERE');`);
  
  console.log(`\n2. REAL TRADE (spends ETH - be careful!):`);
  console.log(`   testRealTrade('YOUR_PRIVATE_KEY_HERE');`);
  
  console.log(`\n💡 Copy and paste your private key in the functions below:`);
  
  // Test functions
  global.testDryRun = async function(privateKey) {
    console.log(`\n🧪 ========== DRY RUN TEST ==========`);
    
    try {
      const wallet = new ethers.Wallet(privateKey, provider);
      const balance = await wallet.getBalance();
      
      console.log(`👤 Wallet: ${wallet.address}`);
      console.log(`💰 Balance: ${ethers.utils.formatEther(balance)} ETH`);
      
      if (balance.lt(ethers.utils.parseEther('0.001'))) {
        console.log(`⚠️ Warning: Balance too low for 0.001 ETH trade`);
        console.log(`💡 You need at least 0.001 ETH + gas fees`);
        return;
      }
      
      // Test price calculation
      const ethAmount = ethers.utils.parseEther('0.001');
      const { expectedOutput } = solution.calculateExpectedOutput(ethAmount, TONY_TOKEN);
      const minOut = expectedOutput.mul(7000).div(10000); // 30% slippage
      
      console.log(`📊 Price calculation:`);
      console.log(`  📤 Expected: ${ethers.utils.formatEther(expectedOutput)} TONY`);
      console.log(`  🛡️ Min out: ${ethers.utils.formatEther(minOut)} TONY`);
      
      // Test gas estimation
      const router = new ethers.Contract(solution.SWAP_ROUTER_02, solution.routerABI, wallet);
      
      const swapParams = {
        tokenIn: solution.WETH,
        tokenOut: TONY_TOKEN,
        fee: 10000, // 1%
        recipient: wallet.address,
        deadline: Math.floor(Date.now() / 1000) + 300,
        amountIn: ethAmount,
        amountOutMinimum: 1, // Minimal for testing
        sqrtPriceLimitX96: 0
      };
      
      console.log(`⛽ Testing gas estimation...`);
      
      const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
        value: ethAmount
      });
      
      console.log(`✅ Gas estimation successful: ${gasEstimate.toString()}`);
      console.log(`💰 Gas cost: ~${ethers.utils.formatEther(gasEstimate.mul(ethers.utils.parseUnits('1', 'gwei')))} ETH`);
      
      console.log(`\n🎉 DRY RUN SUCCESS!`);
      console.log(`✅ Your wallet can execute this trade`);
      console.log(`✅ Gas estimation works`);
      console.log(`✅ Price calculation accurate`);
      console.log(`🚀 Ready for real trade!`);
      
      console.log(`\n💡 To execute real trade, run:`);
      console.log(`   testRealTrade('${privateKey}');`);
      
    } catch (error) {
      console.log(`❌ Dry run failed: ${error.message}`);
      
      if (error.message.includes('insufficient funds')) {
        console.log(`💡 Solution: Add more ETH to your wallet`);
      } else if (error.message.includes('execution reverted')) {
        console.log(`💡 This might be a temporary network issue - try again`);
      }
    }
  };
  
  global.testRealTrade = async function(privateKey) {
    console.log(`\n🚀 ========== REAL TRADE TEST ==========`);
    console.log(`⚠️  THIS WILL SPEND REAL ETH!`);
    console.log(`💰 Amount: 0.001 ETH`);
    console.log(`🎯 Token: TONY`);
    console.log(`🛡️ Slippage: 30%`);
    
    try {
      const result = await solution.execBuy(privateKey, TONY_TOKEN, 0.001, 30);
      
      if (result.success) {
        console.log(`\n🎉 TRADE SUCCESSFUL!`);
        console.log(`📍 TX Hash: ${result.txHash}`);
        console.log(`⛽ Gas Used: ${result.gasUsed}`);
        console.log(`📤 Expected: ${result.expectedOutput}`);
        console.log(`🔗 View on Basescan: https://basescan.org/tx/${result.txHash}`);
        
        console.log(`\n✅ ACCESS CONTROL ISSUE SOLVED!`);
        console.log(`🎯 Your bot can now trade successfully`);
        
      } else {
        console.log(`\n❌ Trade failed: ${result.error}`);
        console.log(`💡 Check the error and try again`);
      }
      
    } catch (error) {
      console.log(`❌ Trade execution failed: ${error.message}`);
    }
  };
  
  console.log(`\n🎯 Functions loaded! You can now test:`);
  console.log(`   - testDryRun('your_private_key')`);
  console.log(`   - testRealTrade('your_private_key')`);
}

// Run the test setup
testSolution().catch(console.error);