#!/usr/bin/env node

/**
 * TEST SAFE EXEC BUY SYSTEM
 * Test the gas-protected exec buy system
 */

require('dotenv').config();
const SafeExecBuySystem = require('./chains/base/safe-exec-buy-system');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const { ethers } = require('ethers');

async function testSafeExecBuy() {
  try {
    console.log('🛡️ ========== TESTING SAFE EXEC BUY SYSTEM ==========');
    
    // Setup
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const safeExecBuy = new SafeExecBuySystem(provider);
    
    // Get wallet
    const userId = 6537510183;
    const chainWallets = await walletManager.getChainWallets(userId, 'base');
    const wallet = chainWallets['W1'];
    
    if (!wallet) {
      throw new Error('W1 wallet not found');
    }
    
    console.log(`👤 Using wallet: ${wallet.address}`);
    
    // Check wallet balance
    const provider_wallet = new ethers.Wallet(wallet.privateKey, provider);
    const balance = await provider_wallet.getBalance();
    console.log(`💰 ETH Balance: ${ethers.utils.formatEther(balance)} ETH`);
    
    // Test tokens
    const testTokens = [
      {
        name: 'USDC (High Liquidity - Should Work)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      },
      {
        name: 'TONY Token (Low/No Liquidity)',
        address: '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D',
        amount: 0.001
      }
    ];
    
    for (const token of testTokens) {
      console.log(`\n🎯 ========== TESTING: ${token.name} ==========`);
      console.log(`📍 Address: ${token.address}`);
      console.log(`💰 Amount: ${token.amount} ETH`);
      
      // Quick liquidity check first
      const hasLiquidity = await safeExecBuy.hasLiquidity(token.address);
      console.log(`💧 Has liquidity: ${hasLiquidity ? '✅ Yes' : '❌ No'}`);
      
      if (token.name.includes('USDC')) {
        console.log(`\n🚀 EXECUTING SAFE EXEC BUY...`);
        console.log(`⚠️  This will execute a REAL transaction!`);
        
        // Execute the safe exec buy
        const result = await safeExecBuy.execBuy(
          wallet.privateKey,
          token.address,
          token.amount
        );
        
        console.log(`\n🎉 SAFE EXEC BUY RESULT:`, result);
        
        if (result.success) {
          console.log(`✅ SUCCESS!`);
          console.log(`📝 Transaction: ${result.txHash}`);
          console.log(`⛽ Gas used: ${result.gasUsed}`);
          console.log(`🪙 Tokens received: ${result.tokensReceived}`);
          console.log(`🔧 Method: ${result.method}`);
        } else {
          console.log(`❌ FAILED: ${result.error}`);
          console.log(`🔧 Method: ${result.method}`);
          console.log(`⛽ Gas used: ${result.gasUsed || '0'}`);
        }
      } else {
        console.log(`\n⚠️  Skipping TONY token execution to save gas`);
        console.log(`💡 TONY token has no liquidity - would fail and waste gas`);
        console.log(`🎯 Use USDC test to verify the system works`);
      }
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ SAFE EXEC BUY TEST COMPLETE');
    console.log('🛡️ System protects your wallet from excessive gas usage');
    console.log('🎯 Shows "execBuy()" function name like professional Looter bots');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testSafeExecBuy();