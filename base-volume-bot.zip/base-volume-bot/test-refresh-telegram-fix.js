/**
 * TEST REFRESH TELEGRAM ERROR FIX
 * Test the fix for "message is not modified" Telegram error
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot that simulates the Telegram error
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
    this.simulateError = false;
    this.lastEditContent = null;
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 Message sent`);
    return message;
  }

  async editMessageText(text, options = {}) {
    // Simulate the "message is not modified" error if content is similar
    if (this.lastEditContent) {
      const currentContentCore = text.replace(/🔄 \*Last refreshed:.*?\*/g, '').trim();
      const lastContentCore = this.lastEditContent.replace(/🔄 \*Last refreshed:.*?\*/g, '').trim();
      
      if (currentContentCore === lastContentCore && this.simulateError) {
        const error = new Error('ETELEGRAM: 400 Bad Request: message is not modified: specified new message content and reply markup are exactly the same as a current content and reply markup of the message');
        throw error;
      }
    }
    
    this.edits.push({ text, options });
    this.lastEditContent = text;
    
    const hasTimestamp = text.includes('Last refreshed:');
    console.log(`✏️ Message edited - Has timestamp: ${hasTimestamp}`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ Callback: ${options.text || 'No text'}`);
    return true;
  }

  // Method to simulate the Telegram error
  enableErrorSimulation() {
    this.simulateError = true;
  }

  disableErrorSimulation() {
    this.simulateError = false;
  }
}

async function testRefreshTelegramFix() {
  console.log('🔧 ========== TELEGRAM REFRESH ERROR FIX TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Test environment initialized');

    // Step 1: Create token session
    console.log('\n📍 STEP 1: Create Token Session');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find refresh button
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    if (!tokenDisplay) {
      console.log('❌ FAIL: Token display not found');
      return false;
    }

    const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
    const refreshButton = keyboard.flat().find(btn => 
      btn.text.includes('📊 Refresh Info')
    );
    
    if (!refreshButton) {
      console.log('❌ FAIL: Refresh button not found');
      return false;
    }

    console.log('✅ Token session created with refresh button');

    // Step 2: Test refresh with timestamp (should work)
    console.log('\n📍 STEP 2: Test Refresh with Timestamp');
    
    const refreshCallback = {
      id: 'test_refresh_1',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    };
    
    await callbacks.handleBuyRefresh(refreshCallback);
    
    // Check if timestamp was added
    const refreshedMessage = mockBot.edits[mockBot.edits.length - 1];
    if (refreshedMessage.text.includes('Last refreshed:')) {
      console.log('✅ Timestamp added to prevent Telegram error');
    } else {
      console.log('❌ FAIL: Timestamp not added');
      return false;
    }

    // Step 3: Test rapid refresh clicks (should always work due to timestamp)
    console.log('\n📍 STEP 3: Test Rapid Refresh Clicks');
    
    // Wait a second to ensure different timestamps
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    await callbacks.handleBuyRefresh({
      id: 'test_refresh_2',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    });
    
    await callbacks.handleBuyRefresh({
      id: 'test_refresh_3',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    });
    
    console.log('✅ Multiple rapid refreshes completed');

    // Step 4: Test error handling scenario
    console.log('\n📍 STEP 4: Test Error Handling');
    
    // Enable error simulation
    mockBot.enableErrorSimulation();
    
    try {
      await callbacks.handleBuyRefresh({
        id: 'test_refresh_error',
        from: { id: testUserId },
        message: { message_id: 1001 },
        data: refreshButton.callback_data
      });
      
      console.log('✅ Error handling test completed');
    } catch (error) {
      // This should not happen as the error should be caught
      console.log('❌ FAIL: Error not properly handled');
      return false;
    }

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log(`📤 Messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Message edits: ${mockBot.edits.length}`);
    console.log(`✅ Callback responses: ${mockBot.callbacks.length}`);
    
    // Check if all edits have timestamps
    const editsWithTimestamp = mockBot.edits.filter(edit => 
      edit.text.includes('Last refreshed:')
    ).length;
    
    console.log(`🕐 Edits with timestamp: ${editsWithTimestamp}/${mockBot.edits.length - 1}`); // -1 for initial edit
    
    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    return false;
  }
}

// Run the test
testRefreshTelegramFix().then(success => {
  if (success) {
    console.log('\n🎉 ========== TELEGRAM ERROR FIX SUCCESSFUL! ==========');
    console.log('✅ Timestamp added to prevent "message not modified" error');
    console.log('✅ Error handling implemented for identical content');
    console.log('✅ Multiple rapid refreshes work properly');
    console.log('✅ User feedback provided in all scenarios');
    console.log('🚀 REFRESH BUTTON IS NOW BULLETPROOF!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== FIX TEST FAILED ==========');
    console.log('❌ Telegram error fix not working properly');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});