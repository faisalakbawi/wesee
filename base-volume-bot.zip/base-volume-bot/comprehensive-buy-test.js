#!/usr/bin/env node

/**
 * COMPREHENSIVE BUY TEST
 * This will show us EVERYTHING that happens during a buy transaction
 * - Pool state before/after
 * - Token balances before/after
 * - Gas usage
 * - Transaction details
 * - Price calculations
 * - Slippage analysis
 */

require('dotenv').config();
const { ethers } = require('ethers');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

class ComprehensiveBuyTest {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    
    // Addresses
    this.UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
    this.UNISWAP_V3_FACTORY = '0x33128a8fC17869897dcE68Ed026d694621f6FDfD';
    this.WETH = '0x4200000000000000000000000000000000000006';
    this.TONY_TOKEN = '0x36a947baa2492c72bf9d3307117237e79145a87d';
    this.TONY_POOL = '0x89649AF832915FF8F24100a58b6A6FBc498de911';
    
    // ABIs
    this.ROUTER_ABI = [
      'function exactInputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96)) external payable returns (uint256 amountOut)',
      'function exactInput((bytes path, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum)) external payable returns (uint256 amountOut)'
    ];
    
    this.POOL_ABI = [
      'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
      'function liquidity() external view returns (uint128)',
      'function token0() external view returns (address)',
      'function token1() external view returns (address)',
      'function fee() external view returns (uint24)',
      'function tickSpacing() external view returns (int24)',
      'function maxLiquidityPerTick() external view returns (uint128)'
    ];
    
    this.ERC20_ABI = [
      'function balanceOf(address account) external view returns (uint256)',
      'function decimals() external view returns (uint8)',
      'function name() external view returns (string)',
      'function symbol() external view returns (string)',
      'function totalSupply() external view returns (uint256)'
    ];
    
    this.FACTORY_ABI = [
      'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)'
    ];
  }
  
  async runComprehensiveTest(amountETH = 0.001) {
    console.log('🔍 ========== COMPREHENSIVE BUY TEST ==========');
    console.log(`💰 Test Amount: ${amountETH} ETH`);
    console.log(`🎯 Target Token: TONY`);
    console.log(`📊 This will show EVERYTHING that happens during a buy`);
    
    try {
      // Setup wallet
      const chainManager = new ChainManager();
      const walletManager = new WalletDBManager(chainManager);
      await walletManager.initialize();
      
      const userId = 6537510183;
      const chainWallets = await walletManager.getChainWallets(userId, 'base');
      const walletInfo = chainWallets['W1'];
      
      if (!walletInfo) {
        throw new Error('W1 wallet not found');
      }
      
      const wallet = new ethers.Wallet(walletInfo.privateKey, this.provider);
      console.log(`👤 Wallet: ${wallet.address}`);
      
      // Check wallet balance
      const ethBalance = await wallet.getBalance();
      console.log(`💰 ETH Balance: ${ethers.utils.formatEther(ethBalance)} ETH`);
      
      if (ethBalance.lt(ethers.utils.parseEther(amountETH.toString()))) {
        throw new Error(`Insufficient ETH balance. Need ${amountETH} ETH, have ${ethers.utils.formatEther(ethBalance)} ETH`);
      }
      
      // STEP 1: Analyze token and pool BEFORE transaction
      console.log('\n🔍 STEP 1: PRE-TRANSACTION ANALYSIS');
      const preAnalysis = await this.analyzeTokenAndPool(wallet);
      
      // STEP 2: Calculate expected output
      console.log('\n🧮 STEP 2: PRICE CALCULATION');
      const priceAnalysis = await this.calculateExpectedOutput(amountETH, preAnalysis);
      
      // STEP 3: Execute the transaction with full monitoring
      console.log('\n🚀 STEP 3: EXECUTE TRANSACTION');
      const transactionResult = await this.executeMonitoredTransaction(wallet, amountETH, priceAnalysis);
      
      // STEP 4: Analyze everything AFTER transaction
      console.log('\n📊 STEP 4: POST-TRANSACTION ANALYSIS');
      const postAnalysis = await this.analyzeTokenAndPool(wallet);
      
      // STEP 5: Compare before/after and show complete picture
      console.log('\n📈 STEP 5: COMPLETE ANALYSIS');
      await this.showCompleteAnalysis(preAnalysis, postAnalysis, transactionResult, amountETH);
      
      return {
        success: transactionResult.success,
        preAnalysis,
        postAnalysis,
        transactionResult,
        priceAnalysis
      };
      
    } catch (error) {
      console.error('❌ Comprehensive test failed:', error.message);
      return { success: false, error: error.message };
    }
  }
  
  async analyzeTokenAndPool(wallet) {
    console.log('  🔍 Analyzing token and pool state...');
    
    const token = new ethers.Contract(this.TONY_TOKEN, this.ERC20_ABI, this.provider);
    const pool = new ethers.Contract(this.TONY_POOL, this.POOL_ABI, this.provider);
    
    // Token analysis
    const [name, symbol, decimals, totalSupply, userBalance] = await Promise.all([
      token.name(),
      token.symbol(),
      token.decimals(),
      token.totalSupply(),
      token.balanceOf(wallet.address)
    ]);
    
    // Pool analysis
    const [slot0, liquidity, token0, token1, fee, tickSpacing] = await Promise.all([
      pool.slot0(),
      pool.liquidity(),
      pool.token0(),
      pool.token1(),
      pool.fee(),
      pool.tickSpacing()
    ]);
    
    // Calculate current price
    const sqrtPriceX96 = slot0.sqrtPriceX96;
    let price = ethers.BigNumber.from(0);
    
    try {
      if (sqrtPriceX96.gt(0)) {
        price = sqrtPriceX96.mul(sqrtPriceX96).div(ethers.BigNumber.from(2).pow(192));
      }
    } catch (error) {
      console.log(`    ⚠️ Price calculation error: ${error.message}`);
    }
    
    // Determine token order
    const isWETHToken0 = token0.toLowerCase() === this.WETH.toLowerCase();
    
    const analysis = {
      token: {
        address: this.TONY_TOKEN,
        name,
        symbol,
        decimals: typeof decimals === 'number' ? decimals : decimals.toNumber(),
        totalSupply: ethers.utils.formatUnits(totalSupply, decimals),
        userBalance: ethers.utils.formatUnits(userBalance, decimals)
      },
      pool: {
        address: this.TONY_POOL,
        token0,
        token1,
        fee: typeof fee === 'number' ? fee : fee.toNumber(),
        liquidity: liquidity.toString(),
        sqrtPriceX96: sqrtPriceX96.toString(),
        tick: slot0.tick,
        unlocked: slot0.unlocked,
        tickSpacing: typeof tickSpacing === 'number' ? tickSpacing : tickSpacing.toNumber(),
        isWETHToken0
      },
      price: {
        sqrtPriceX96: sqrtPriceX96.toString(),
        price: price.toString(),
        readablePrice: price.gt(0) ? (isWETHToken0 ? 
          ethers.utils.formatEther(price) : 
          ethers.utils.formatEther(ethers.utils.parseEther('1').div(price))) : '0'
      },
      timestamp: Date.now()
    };
    
    console.log('  📊 Token Analysis:');
    console.log(`    Name: ${analysis.token.name} (${analysis.token.symbol})`);
    console.log(`    Decimals: ${analysis.token.decimals}`);
    console.log(`    Total Supply: ${analysis.token.totalSupply}`);
    console.log(`    User Balance: ${analysis.token.userBalance} ${analysis.token.symbol}`);
    
    console.log('  🏊 Pool Analysis:');
    console.log(`    Address: ${analysis.pool.address}`);
    console.log(`    Token0: ${analysis.pool.token0} ${isWETHToken0 ? '(WETH)' : '(TONY)'}`);
    console.log(`    Token1: ${analysis.pool.token1} ${!isWETHToken0 ? '(WETH)' : '(TONY)'}`);
    console.log(`    Fee: ${analysis.pool.fee / 10000}%`);
    console.log(`    Liquidity: ${analysis.pool.liquidity}`);
    console.log(`    Current Tick: ${analysis.pool.tick}`);
    console.log(`    Unlocked: ${analysis.pool.unlocked}`);
    console.log(`    Price: ${analysis.price.readablePrice} ${isWETHToken0 ? 'TONY per ETH' : 'ETH per TONY'}`);
    
    return analysis;
  }
  
  async calculateExpectedOutput(amountETH, poolAnalysis) {
    console.log('  🧮 Calculating expected output...');
    
    const amountIn = ethers.utils.parseEther(amountETH.toString());
    const { pool, price } = poolAnalysis;
    
    // Simple price calculation (professional bots use more complex math)
    let expectedOutput = ethers.BigNumber.from(0);
    
    try {
      const priceValue = ethers.BigNumber.from(price.price);
      if (priceValue.gt(0)) {
        if (pool.isWETHToken0) {
          // WETH is token0, buying TONY (token1)
          expectedOutput = amountIn.mul(ethers.utils.parseEther('1')).div(priceValue);
        } else {
          // WETH is token1, buying TONY (token0)
          expectedOutput = amountIn.mul(priceValue).div(ethers.utils.parseEther('1'));
        }
      } else {
        // Fallback: use a rough estimate based on successful transaction ratio
        // From successful tx: 0.06 ETH -> 1,743,504 TONY = ~29M TONY per ETH
        const roughRate = ethers.utils.parseEther('29000000'); // 29M TONY per ETH
        expectedOutput = amountIn.mul(roughRate).div(ethers.utils.parseEther('1'));
      }
    } catch (error) {
      console.log(`    ⚠️ Expected output calculation error: ${error.message}`);
      // Use fallback calculation
      const roughRate = ethers.utils.parseEther('29000000');
      expectedOutput = amountIn.mul(roughRate).div(ethers.utils.parseEther('1'));
    }
    
    // Apply different slippage scenarios
    const slippageScenarios = [
      { name: '0% slippage', percent: 0, minOutput: expectedOutput },
      { name: '1% slippage', percent: 1, minOutput: expectedOutput.mul(99).div(100) },
      { name: '5% slippage', percent: 5, minOutput: expectedOutput.mul(95).div(100) },
      { name: '10% slippage', percent: 10, minOutput: expectedOutput.mul(90).div(100) }
    ];
    
    console.log('  📊 Price Calculations:');
    console.log(`    ETH Input: ${amountETH} ETH`);
    console.log(`    Expected TONY Output: ${ethers.utils.formatEther(expectedOutput)} TONY`);
    console.log(`    Rate: ${(parseFloat(ethers.utils.formatEther(expectedOutput)) / amountETH).toFixed(2)} TONY per ETH`);
    
    console.log('  💸 Slippage Scenarios:');
    slippageScenarios.forEach(scenario => {
      console.log(`    ${scenario.name}: Min ${ethers.utils.formatEther(scenario.minOutput)} TONY`);
    });
    
    return {
      amountIn,
      expectedOutput,
      slippageScenarios,
      pricePerETH: parseFloat(ethers.utils.formatEther(expectedOutput)) / amountETH
    };
  }
  
  async executeMonitoredTransaction(wallet, amountETH, priceAnalysis) {
    console.log('  🚀 Executing monitored transaction...');
    
    const router = new ethers.Contract(this.UNISWAP_V3_ROUTER, this.ROUTER_ABI, wallet);
    const amountIn = ethers.utils.parseEther(amountETH.toString());
    
    // Try different methods to see which one works
    const methods = [
      {
        name: 'exactInputSingle',
        params: {
          tokenIn: this.WETH,
          tokenOut: this.TONY_TOKEN,
          fee: 10000, // 1%
          recipient: wallet.address,
          deadline: Math.floor(Date.now() / 1000) + 300,
          amountIn: amountIn,
          amountOutMinimum: 0, // Accept any amount
          sqrtPriceLimitX96: 0
        }
      },
      {
        name: 'exactInput',
        params: {
          path: ethers.utils.solidityPack(
            ['address', 'uint24', 'address'],
            [this.WETH, 10000, this.TONY_TOKEN]
          ),
          recipient: wallet.address,
          deadline: Math.floor(Date.now() / 1000) + 300,
          amountIn: amountIn,
          amountOutMinimum: 0
        }
      }
    ];
    
    for (const method of methods) {
      try {
        console.log(`    🎯 Trying method: ${method.name}`);
        
        // Get gas estimate
        const gasEstimate = await router.estimateGas[method.name](method.params, {
          value: amountIn
        });
        
        console.log(`    ⛽ Gas estimate: ${gasEstimate.toString()}`);
        
        // Get gas price
        const gasPrice = await this.provider.getGasPrice();
        console.log(`    💸 Gas price: ${ethers.utils.formatUnits(gasPrice, 'gwei')} gwei`);
        
        // Calculate total gas cost
        const gasCost = gasEstimate.mul(gasPrice);
        console.log(`    💰 Estimated gas cost: ${ethers.utils.formatEther(gasCost)} ETH`);
        
        // Execute transaction
        console.log(`    📝 Executing ${method.name}...`);
        const tx = await router[method.name](method.params, {
          value: amountIn,
          gasLimit: gasEstimate.mul(120).div(100), // 20% buffer
          gasPrice: gasPrice
        });
        
        console.log(`    📝 Transaction hash: ${tx.hash}`);
        console.log(`    ⏳ Waiting for confirmation...`);
        
        const receipt = await tx.wait();
        
        console.log(`    ✅ Transaction confirmed!`);
        console.log(`    📊 Block number: ${receipt.blockNumber}`);
        console.log(`    ⛽ Gas used: ${receipt.gasUsed.toString()}`);
        console.log(`    💰 Actual gas cost: ${ethers.utils.formatEther(receipt.gasUsed.mul(gasPrice))} ETH`);
        
        // Analyze transaction logs
        console.log(`    📋 Transaction logs: ${receipt.logs.length} events`);
        receipt.logs.forEach((log, index) => {
          console.log(`      Log ${index}: ${log.address} - ${log.topics.length} topics`);
        });
        
        return {
          success: true,
          method: method.name,
          txHash: tx.hash,
          blockNumber: receipt.blockNumber,
          gasUsed: receipt.gasUsed.toString(),
          gasPrice: gasPrice.toString(),
          gasCost: ethers.utils.formatEther(receipt.gasUsed.mul(gasPrice)),
          logs: receipt.logs,
          receipt
        };
        
      } catch (error) {
        console.log(`    ❌ Method ${method.name} failed: ${error.message}`);
        continue;
      }
    }
    
    return {
      success: false,
      error: 'All transaction methods failed'
    };
  }
  
  async showCompleteAnalysis(preAnalysis, postAnalysis, transactionResult, amountETH) {
    console.log('  📈 Complete transaction analysis:');
    
    if (!transactionResult.success) {
      console.log('  ❌ Transaction failed, no analysis possible');
      return;
    }
    
    // Token balance changes
    const tokenBalanceBefore = parseFloat(preAnalysis.token.userBalance);
    const tokenBalanceAfter = parseFloat(postAnalysis.token.userBalance);
    const tokensReceived = tokenBalanceAfter - tokenBalanceBefore;
    
    console.log('  💰 Balance Changes:');
    console.log(`    ETH spent: ${amountETH} ETH`);
    console.log(`    TONY before: ${tokenBalanceBefore} TONY`);
    console.log(`    TONY after: ${tokenBalanceAfter} TONY`);
    console.log(`    TONY received: ${tokensReceived} TONY`);
    
    // Price analysis
    const actualRate = tokensReceived / amountETH;
    console.log(`    Actual rate: ${actualRate.toFixed(2)} TONY per ETH`);
    
    // Pool state changes
    console.log('  🏊 Pool State Changes:');
    console.log(`    Liquidity before: ${preAnalysis.pool.liquidity}`);
    console.log(`    Liquidity after: ${postAnalysis.pool.liquidity}`);
    console.log(`    Tick before: ${preAnalysis.pool.tick}`);
    console.log(`    Tick after: ${postAnalysis.pool.tick}`);
    console.log(`    Price before: ${preAnalysis.price.readablePrice}`);
    console.log(`    Price after: ${postAnalysis.price.readablePrice}`);
    
    // Transaction efficiency
    console.log('  ⚡ Transaction Efficiency:');
    console.log(`    Method used: ${transactionResult.method}`);
    console.log(`    Gas used: ${transactionResult.gasUsed}`);
    console.log(`    Gas cost: ${transactionResult.gasCost} ETH`);
    console.log(`    Gas efficiency: ${(tokensReceived / parseFloat(transactionResult.gasUsed)).toFixed(6)} TONY per gas`);
    
    // Success metrics
    if (tokensReceived > 0) {
      console.log('  🎉 SUCCESS METRICS:');
      console.log(`    ✅ Transaction successful`);
      console.log(`    ✅ Tokens received: ${tokensReceived} TONY`);
      console.log(`    ✅ Rate: ${actualRate.toFixed(2)} TONY per ETH`);
      console.log(`    ✅ Method: ${transactionResult.method}`);
    } else {
      console.log('  ❌ FAILURE: No tokens received despite successful transaction');
    }
    
    // Professional insights
    console.log('  🤖 PROFESSIONAL INSIGHTS:');
    console.log(`    💡 This method works for ANY amount`);
    console.log(`    💡 Key is using the correct pool (1% fee)`);
    console.log(`    💡 Method ${transactionResult.method} is the working approach`);
    console.log(`    💡 Gas cost is ${((parseFloat(transactionResult.gasCost) / amountETH) * 100).toFixed(2)}% of trade value`);
  }
}

async function runTest() {
  const test = new ComprehensiveBuyTest();
  
  // Test with small amount first
  console.log('🧪 Testing with 0.001 ETH...');
  const result = await test.runComprehensiveTest(0.001);
  
  if (result.success) {
    console.log('\n✅ COMPREHENSIVE TEST SUCCESSFUL!');
    console.log('🎯 We now understand the complete technique');
  } else {
    console.log('\n❌ Test failed:', result.error);
  }
}

// Run the comprehensive test
runTest();