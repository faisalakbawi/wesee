#!/usr/bin/env node

/**
 * ANALYZE FAILED TRANSACTION
 * Decode the exact transaction that failed to understand why
 */

const { ethers } = require('ethers');

function analyzeFailedTransaction() {
  console.log('🔍 ========== ANALYZING FAILED TRANSACTION ==========');
  
  const txHash = '0x83a33433b37e35908afb37f1b963071cfc77752da99d9368b286589336364ddc';
  const inputData = '0x414bf389000000000000000000000000420000000000000000000000000000000000000600000000000000000000000036a947baa2492c72bf9d3307117237e79145a87d00000000000000000000000000000000000000000000000000000000000027100000000000000000000000005e7480a0e1c80bb8e517cc287d0ffbaf7a77ee0a00000000000000000000000000000000000000000000000000000000688bf0aa00000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';
  
  console.log(`📝 Transaction Hash: ${txHash}`);
  console.log(`📊 Status: FAILED (execution reverted)`);
  console.log(`💰 Value: 0.001 ETH`);
  console.log(`⛽ Gas Used: 25,340 / 300,000 (8.45%)`);
  console.log(`🎯 Function: exactInputSingle (0x414bf389)`);
  
  // Decode the input data
  const abiCoder = new ethers.utils.AbiCoder();
  const functionSelector = inputData.slice(0, 10);
  const paramData = '0x' + inputData.slice(10);
  
  console.log(`\n🔍 DECODING TRANSACTION DATA:`);
  console.log(`Function Selector: ${functionSelector}`);
  
  try {
    // exactInputSingle parameters
    const decoded = abiCoder.decode([
      'address', // tokenIn
      'address', // tokenOut  
      'uint24',  // fee
      'address', // recipient
      'uint256', // deadline
      'uint256', // amountIn
      'uint256', // amountOutMinimum
      'uint160'  // sqrtPriceLimitX96
    ], paramData);
    
    console.log(`\n📋 DECODED PARAMETERS:`);
    console.log(`  Token In: ${decoded[0]}`);
    console.log(`  Token Out: ${decoded[1]}`);
    console.log(`  Fee: ${decoded[2]} (${decoded[2] / 10000}%)`);
    console.log(`  Recipient: ${decoded[3]}`);
    console.log(`  Deadline: ${decoded[4]} (${new Date(decoded[4] * 1000).toISOString()})`);
    console.log(`  Amount In: ${ethers.utils.formatEther(decoded[5])} ETH`);
    console.log(`  Amount Out Min: ${decoded[6]} (${ethers.utils.formatEther(decoded[6])} tokens)`);
    console.log(`  Price Limit: ${decoded[7]}`);
    
    // Verify addresses
    const WETH = '0x4200000000000000000000000000000000000006';
    const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
    const WALLET = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A';
    
    console.log(`\n✅ ADDRESS VERIFICATION:`);
    console.log(`  Token In is WETH: ${decoded[0].toLowerCase() === WETH.toLowerCase()}`);
    console.log(`  Token Out is TONY: ${decoded[1].toLowerCase() === TONY.toLowerCase()}`);
    console.log(`  Recipient is wallet: ${decoded[3].toLowerCase() === WALLET.toLowerCase()}`);
    console.log(`  Fee is 1%: ${decoded[2] == 10000}`);
    
    // Check if deadline was valid
    const now = Math.floor(Date.now() / 1000);
    const deadlineValid = decoded[4] > now;
    console.log(`  Deadline valid: ${deadlineValid} (${deadlineValid ? 'OK' : 'EXPIRED'})`);
    
    console.log(`\n🤔 POSSIBLE FAILURE REASONS:`);
    
    if (!deadlineValid) {
      console.log(`  ❌ DEADLINE EXPIRED - Transaction took too long`);
    }
    
    if (decoded[6] > 0) {
      console.log(`  ⚠️ Minimum output required: ${ethers.utils.formatEther(decoded[6])} tokens`);
      console.log(`  💡 This might be too high, causing slippage failure`);
    } else {
      console.log(`  ✅ No minimum output required (amountOutMinimum = 0)`);
    }
    
    console.log(`  🔍 MOST LIKELY CAUSES:`);
    console.log(`    1. Pool has insufficient liquidity for this trade size`);
    console.log(`    2. Pool price moved significantly during transaction`);
    console.log(`    3. Pool is temporarily locked or paused`);
    console.log(`    4. Token has transfer restrictions or fees`);
    console.log(`    5. Router contract has issues with this specific pool`);
    
    console.log(`\n💡 DEBUGGING STEPS:`);
    console.log(`  1. Check current pool liquidity and state`);
    console.log(`  2. Try with smaller amount (0.0001 ETH)`);
    console.log(`  3. Check if token has transfer fees or restrictions`);
    console.log(`  4. Verify pool is still active and unlocked`);
    console.log(`  5. Try different slippage settings`);
    
    return {
      tokenIn: decoded[0],
      tokenOut: decoded[1],
      fee: decoded[2],
      recipient: decoded[3],
      deadline: decoded[4],
      amountIn: decoded[5],
      amountOutMinimum: decoded[6],
      sqrtPriceLimitX96: decoded[7]
    };
    
  } catch (error) {
    console.error('❌ Failed to decode transaction:', error.message);
  }
}

// Run analysis
const result = analyzeFailedTransaction();
console.log('\n✅ TRANSACTION ANALYSIS COMPLETE');

module.exports = { analyzeFailedTransaction };