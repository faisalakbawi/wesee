/**
 * COMPREHENSIVE BOT TEST SUITE
 * Tests all major functionality to ensure everything works
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.callbacks = [];
    this.deletedMessages = [];
    this.editedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 50)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.editedMessages.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 50)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ DELETED: ${messageId}`);
    return true;
  }
}

async function runComprehensiveTest() {
  console.log('🧪 ========== COMPREHENSIVE BOT TEST ==========');

  try {
    // Initialize all components
    console.log('🔧 Initializing components...');
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ All components initialized successfully');

    // Test 1: Main Menu
    console.log('\n📍 TEST 1: Main Menu');
    const mainMenuCallback = {
      id: 'test_1',
      data: 'main_menu',
      from: { id: testUserId },
      message: { message_id: 1001 }
    };
    await callbacks.handle(mainMenuCallback);
    console.log('✅ Main menu test passed');

    // Test 2: Buy Token Menu
    console.log('\n📍 TEST 2: Buy Token Menu');
    const buyTokenCallback = {
      id: 'test_2',
      data: 'buy_menu',
      from: { id: testUserId },
      message: { message_id: 1002 }
    };
    await callbacks.handle(buyTokenCallback);
    console.log('✅ Buy token menu test passed');

    // Test 3: Wallet Management
    console.log('\n📍 TEST 3: Wallet Management');
    const walletsCallback = {
      id: 'test_3',
      data: 'wallets_menu',
      from: { id: testUserId },
      message: { message_id: 1003 }
    };
    await callbacks.handle(walletsCallback);
    console.log('✅ Wallet management test passed');

    // Test 4: Chain Selection
    console.log('\n📍 TEST 4: Chain Selection');
    const chainCallback = {
      id: 'test_4',
      data: 'chain_base',
      from: { id: testUserId },
      message: { message_id: 1004 }
    };
    await callbacks.handle(chainCallback);
    console.log('✅ Chain selection test passed');

    // Test 5: Custom Slippage Flow (The Fixed Feature!)
    console.log('\n📍 TEST 5: Custom Slippage Flow (CRITICAL TEST)');
    
    // First, simulate a token session
    const sessionId = 'test_session';
    const tokenData = {
      symbol: 'TEST',
      address: '0x1234567890123456789012345678901234567890',
      chain: 'base',
      price: 1.0,
      marketCap: 1000000
    };
    
    // Store token session
    callbacks.buyTokenUI.tokenSessions.set(`${testUserId}_${sessionId}`, {
      tokenData,
      createdAt: Date.now()
    });

    // Test custom slippage button click
    const customSlippageCallback = {
      id: 'test_5',
      data: `slippage_custom_${sessionId}`,
      from: { id: testUserId },
      message: { message_id: 1005 }
    };
    
    await callbacks.handle(customSlippageCallback);
    
    // Check if user state was set correctly
    const userState = userStates.get(testUserId);
    if (userState && userState.state === 'awaiting_custom_slippage') {
      console.log('✅ Custom slippage state set correctly');
    } else {
      console.log('❌ Custom slippage state not set correctly');
    }

    // Test custom slippage input
    const customSlippageMessage = {
      message_id: 1006,
      chat: { id: testUserId },
      text: '2.5',
      reply_to_message: { message_id: mockBot.messages[mockBot.messages.length - 1].message_id }
    };

    await callbacks.handleCustomSlippageInput(customSlippageMessage);
    console.log('✅ Custom slippage input test passed');

    // Test 6: Portfolio
    console.log('\n📍 TEST 6: Portfolio');
    const portfolioCallback = {
      id: 'test_6',
      data: 'portfolio_menu',
      from: { id: testUserId },
      message: { message_id: 1007 }
    };
    await callbacks.handle(portfolioCallback);
    console.log('✅ Portfolio test passed');

    // Test 7: Settings
    console.log('\n📍 TEST 7: Settings');
    const settingsCallback = {
      id: 'test_7',
      data: 'settings_menu',
      from: { id: testUserId },
      message: { message_id: 1008 }
    };
    await callbacks.handle(settingsCallback);
    console.log('✅ Settings test passed');

    // Test 8: Help
    console.log('\n📍 TEST 8: Help');
    const helpCallback = {
      id: 'test_8',
      data: 'help_menu',
      from: { id: testUserId },
      message: { message_id: 1009 }
    };
    await callbacks.handle(helpCallback);
    console.log('✅ Help test passed');

    // Test 9: Unknown Callback Handling
    console.log('\n📍 TEST 9: Unknown Callback Handling');
    const unknownCallback = {
      id: 'test_9',
      data: 'unknown_callback_data',
      from: { id: testUserId },
      message: { message_id: 1010 }
    };
    await callbacks.handle(unknownCallback);
    console.log('✅ Unknown callback handling test passed');

    // Test 10: Authorization Check
    console.log('\n📍 TEST 10: Authorization Check');
    const unauthorizedCallback = {
      id: 'test_10',
      data: 'main_menu',
      from: { id: 99999 }, // Unauthorized user
      message: { message_id: 1011 }
    };
    await callbacks.handle(unauthorizedCallback);
    console.log('✅ Authorization check test passed');

    // Summary
    console.log('\n📊 ========== TEST SUMMARY ==========');
    console.log(`📤 Messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Messages edited: ${mockBot.editedMessages.length}`);
    console.log(`✅ Callbacks answered: ${mockBot.callbacks.length}`);
    console.log(`🗑️ Messages deleted: ${mockBot.deletedMessages.length}`);

    // Check for any error callbacks
    const errorCallbacks = mockBot.callbacks.filter(c => 
      c.options.text && c.options.text.includes('❌')
    );
    
    if (errorCallbacks.length > 0) {
      console.log('\n⚠️ Error callbacks found:');
      errorCallbacks.forEach(cb => console.log(`   - ${cb.options.text}`));
    } else {
      console.log('\n✅ No error callbacks found - All systems working!');
    }

    console.log('\n🎉 ========== ALL TESTS PASSED! ==========');
    return true;

  } catch (error) {
    console.error('❌ TEST FAILED:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the comprehensive test
runComprehensiveTest().then(success => {
  if (success) {
    console.log('🚀 Bot is ready for live testing!');
    process.exit(0);
  } else {
    console.log('💥 Bot has issues that need fixing!');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test suite failed:', error);
  process.exit(1);
});