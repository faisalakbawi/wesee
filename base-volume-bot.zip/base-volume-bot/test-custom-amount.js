/**
 * CUSTOM AMOUNT FUNCTIONALITY TEST
 * Test the 💰 Custom Amount button and message handling
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
    this.deletedMessages = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 Message sent: ${text.substring(0, 50)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    const hasCustomAmount = text.includes('Custom:') || 
      (options.reply_markup && JSON.stringify(options.reply_markup).includes('Custom:'));
    console.log(`✏️ Message edited - Has custom amount display: ${hasCustomAmount}`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ Callback: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    this.deletedMessages.push({ chatId, messageId });
    console.log(`🗑️ Message deleted: ${messageId}`);
    return true;
  }
}

async function testCustomAmount() {
  console.log('💰 ========== CUSTOM AMOUNT FUNCTIONALITY TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Test environment initialized');

    // STEP 1: Create token session
    console.log('\n📍 STEP 1: Create Token Session');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find Custom Amount button
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && 
      JSON.stringify(edit.options.reply_markup).includes('Custom Amount')
    );
    
    if (!tokenDisplay) {
      console.log('❌ FAIL: Custom Amount button not found');
      return false;
    }

    const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
    const customAmountButton = keyboard.flat().find(btn => 
      btn.text.includes('💰 Custom Amount')
    );
    
    if (!customAmountButton) {
      console.log('❌ FAIL: 💰 Custom Amount button not found');
      return false;
    }

    console.log('✅ Custom Amount button found:', customAmountButton.text);

    // STEP 2: Click Custom Amount button
    console.log('\n📍 STEP 2: Click Custom Amount Button');
    
    const customAmountCallback = {
      id: 'test_custom_amount',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: customAmountButton.callback_data
    };
    
    const messagesBefore = mockBot.messages.length;
    
    await callbacks.handleBuyCustomAmount(customAmountCallback, 
      callbacks.buyTokenUI.getTokenSession(testUserId, 't1'));
    
    const messagesAfter = mockBot.messages.length;
    
    if (messagesAfter <= messagesBefore) {
      console.log('❌ FAIL: Custom amount prompt not sent');
      return false;
    }

    console.log('✅ Custom amount prompt sent');

    // Check if user state was set
    const userState = userStates.get(testUserId);
    if (!userState || !userStates.isWaitingForCustomAmount(testUserId)) {
      console.log('❌ FAIL: User state not set for custom amount');
      return false;
    }

    console.log('✅ User state set correctly');

    // STEP 3: Send custom amount input
    console.log('\n📍 STEP 3: Send Custom Amount Input');
    
    const customAmountInput = {
      message_id: 1002,
      chat: { id: testUserId },
      text: '0.25',
      from: { id: testUserId }
    };
    
    const editsBefore = mockBot.edits.length;
    
    await callbacks.handleCustomAmountMessage(customAmountInput);
    
    const editsAfter = mockBot.edits.length;
    
    if (editsAfter <= editsBefore) {
      console.log('❌ FAIL: Interface not updated with custom amount');
      return false;
    }

    console.log('✅ Interface updated with custom amount');

    // STEP 4: Check if custom amount is stored and shown
    console.log('\n📍 STEP 4: Verify Custom Amount Storage & Display');
    
    const selectedAmount = callbacks.buyTokenUI.getSelectedAmount(testUserId, 't1');
    if (selectedAmount !== 0.25) {
      console.log('❌ FAIL: Custom amount not stored correctly. Got:', selectedAmount);
      return false;
    }

    console.log('✅ Custom amount stored correctly:', selectedAmount);

    // Check if Custom Amount button shows the selected amount
    const latestEdit = mockBot.edits[mockBot.edits.length - 1];
    const latestKeyboard = latestEdit.options.reply_markup.inline_keyboard;
    const updatedCustomButton = latestKeyboard.flat().find(btn => 
      btn.text.includes('Custom') && btn.text.includes('0.25')
    );
    
    if (!updatedCustomButton) {
      console.log('❌ FAIL: Custom amount not shown in button');
      console.log('Available buttons:', latestKeyboard.flat().map(b => b.text));
      return false;
    }

    console.log('✅ Custom amount shown in button:', updatedCustomButton.text);

    // STEP 5: Test message cleanup
    console.log('\n📍 STEP 5: Verify Message Cleanup');
    
    if (mockBot.deletedMessages.length === 0) {
      console.log('❌ FAIL: Messages not cleaned up');
      return false;
    }

    console.log('✅ Messages cleaned up:', mockBot.deletedMessages.length, 'messages deleted');

    // STEP 6: Test user state cleanup
    console.log('\n📍 STEP 6: Verify User State Cleanup');
    
    if (userStates.isWaitingForCustomAmount(testUserId)) {
      console.log('❌ FAIL: User state not cleared');
      return false;
    }

    console.log('✅ User state cleared correctly');

    // STEP 7: Test invalid input handling
    console.log('\n📍 STEP 7: Test Invalid Input Handling');
    
    // Set state again for testing invalid input
    userStates.setCustomAmountState(testUserId, {
      sessionId: 't1',
      tokenData: callbacks.buyTokenUI.getTokenSession(testUserId, 't1'),
      messageId: 1001
    });
    
    const invalidInput = {
      message_id: 1003,
      chat: { id: testUserId },
      text: 'invalid_amount',
      from: { id: testUserId }
    };
    
    const invalidMessagesBefore = mockBot.messages.length;
    
    await callbacks.handleCustomAmountMessage(invalidInput);
    
    const invalidMessagesAfter = mockBot.messages.length;
    
    // Should send error message
    if (invalidMessagesAfter <= invalidMessagesBefore) {
      console.log('❌ FAIL: Invalid input error not sent');
      return false;
    }

    const errorMessage = mockBot.messages[mockBot.messages.length - 1];
    if (!errorMessage.text.includes('Invalid Amount')) {
      console.log('❌ FAIL: Invalid amount error message not correct');
      return false;
    }

    console.log('✅ Invalid input handled correctly');

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log(`📤 Messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Message edits: ${mockBot.edits.length}`);
    console.log(`✅ Callback responses: ${mockBot.callbacks.length}`);
    console.log(`🗑️ Messages deleted: ${mockBot.deletedMessages.length}`);
    
    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('Stack:', error.stack);
    return false;
  }
}

// Run the test
testCustomAmount().then(success => {
  if (success) {
    console.log('\n🎉 ========== CUSTOM AMOUNT TEST PASSED! ==========');
    console.log('✅ Custom Amount button working correctly');
    console.log('✅ Prompt message sent when clicked');
    console.log('✅ User state management working'); 
    console.log('✅ Custom amount input processed correctly');
    console.log('✅ Amount stored and displayed in button');
    console.log('✅ Messages cleaned up properly');
    console.log('✅ Invalid input handled with error messages');
    console.log('✅ User state cleared after processing');

    console.log('\n📋 ========== HOW CUSTOM AMOUNT WORKS ==========');
    console.log('1. 👆 User clicks "💰 Custom Amount" button');
    console.log('2. 📝 Bot sends prompt message asking for amount');
    console.log('3. ✍️ User types custom amount (e.g., "0.25")');
    console.log('4. ✅ Bot validates and stores the amount');
    console.log('5. 🔄 Interface updates with "✅ Custom: 0.25"');
    console.log('6. 🗑️ Input messages automatically deleted');
    console.log('7. 📊 User can now select wallets and CONFIRM');
    
    console.log('\n🚀 CUSTOM AMOUNT FUNCTIONALITY IS WORKING PERFECTLY!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== CUSTOM AMOUNT TEST FAILED ==========');
    console.log('❌ Please check the error messages above');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});