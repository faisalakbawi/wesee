/**
 * TEST UNIVERSAL ROUTER
 * Test the preferred UniversalRouter instead of SwapRouter02
 */

const { ethers } = require('ethers');

async function testUniversalRouter() {
  console.log(`🌐 ========== TESTING UNIVERSAL ROUTER ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  // Correct addresses from official Uniswap docs
  const UNIVERSAL_ROUTER = '0x6ff5693b99212da76ad316178a184ab56d299b43'; // Official UniversalRouter
  const SWAP_ROUTER_02 = '0x2626664c2603336E57B271c5C0b26F421741e481';   // SwapRouter02 (what we were using)
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  console.log(`🔍 Testing both routers:`);
  console.log(`  🌐 UniversalRouter: ${UNIVERSAL_ROUTER}`);
  console.log(`  🔄 SwapRouter02: ${SWAP_ROUTER_02}`);
  
  // Test SwapRouter02 first (what we were using)
  console.log(`\n1️⃣ Testing SwapRouter02 (current approach)...`);
  await testSwapRouter02(provider, SWAP_ROUTER_02, WETH, TONY);
  
  // Test UniversalRouter (preferred approach)
  console.log(`\n2️⃣ Testing UniversalRouter (preferred approach)...`);
  await testUniversalRouterApproach(provider, UNIVERSAL_ROUTER, WETH, TONY);
}

async function testSwapRouter02(provider, routerAddress, weth, tony) {
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  try {
    const router = new ethers.Contract(routerAddress, routerABI, provider);
    
    const swapParams = {
      tokenIn: weth,
      tokenOut: tony,
      fee: 10000,
      recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A',
      deadline: Math.floor(Date.now() / 1000) + 300,
      amountIn: ethers.utils.parseEther('0.001'),
      amountOutMinimum: ethers.utils.parseUnits('0.001', 18), // Almost zero
      sqrtPriceLimitX96: 0
    };
    
    const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
      value: ethers.utils.parseEther('0.001'),
      from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
    });
    
    console.log(`  ✅ SwapRouter02 works! Gas: ${gasEstimate.toString()}`);
    return { success: true, gas: gasEstimate.toString() };
    
  } catch (error) {
    console.log(`  ❌ SwapRouter02 failed: ${error.message.split('(')[0]}`);
    return { success: false, error: error.message };
  }
}

async function testUniversalRouterApproach(provider, routerAddress, weth, tony) {
  // UniversalRouter uses a different approach with commands
  // Let's try a simple approach first - check if the contract exists
  
  try {
    const code = await provider.getCode(routerAddress);
    console.log(`  📋 UniversalRouter code length: ${code.length} bytes`);
    
    if (code === '0x') {
      console.log(`  ❌ UniversalRouter does not exist at this address`);
      return { success: false, error: 'Contract not found' };
    }
    
    // UniversalRouter has a more complex interface
    // For now, let's just verify it exists and has the right interface
    console.log(`  ✅ UniversalRouter exists and has code`);
    console.log(`  💡 UniversalRouter requires different implementation (commands-based)`);
    
    return { success: true, note: 'Exists but needs different implementation' };
    
  } catch (error) {
    console.log(`  ❌ UniversalRouter test failed: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// Also test different fee tiers
async function testDifferentFeeTiers() {
  console.log(`\n💸 ========== TESTING DIFFERENT FEE TIERS ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  const SWAP_ROUTER_02 = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  const router = new ethers.Contract(SWAP_ROUTER_02, routerABI, provider);
  
  const feeTiers = [
    { name: '0.01%', fee: 100 },
    { name: '0.05%', fee: 500 },
    { name: '0.3%', fee: 3000 },
    { name: '1%', fee: 10000 }
  ];
  
  for (const tier of feeTiers) {
    console.log(`\n🧪 Testing ${tier.name} fee tier (${tier.fee})...`);
    
    const swapParams = {
      tokenIn: WETH,
      tokenOut: TONY,
      fee: tier.fee,
      recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A',
      deadline: Math.floor(Date.now() / 1000) + 300,
      amountIn: ethers.utils.parseEther('0.001'),
      amountOutMinimum: ethers.utils.parseUnits('0.001', 18),
      sqrtPriceLimitX96: 0
    };
    
    try {
      const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
        value: ethers.utils.parseEther('0.001'),
        from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
      });
      
      console.log(`  ✅ ${tier.name} fee tier works! Gas: ${gasEstimate.toString()}`);
      return { success: true, workingFee: tier.fee, gas: gasEstimate.toString() };
      
    } catch (error) {
      console.log(`  ❌ ${tier.name} failed: ${error.message.split('(')[0]}`);
    }
  }
  
  console.log(`\n❌ All fee tiers failed`);
  return { success: false };
}

// Run all tests
async function runAllTests() {
  console.log(`🧪 ========== COMPREHENSIVE ROUTER TESTS ==========`);
  
  await testUniversalRouter();
  const feeResult = await testDifferentFeeTiers();
  
  console.log(`\n📊 ========== FINAL ANALYSIS ==========`);
  if (feeResult.success) {
    console.log(`✅ SOLUTION FOUND!`);
    console.log(`🎯 Working fee tier: ${feeResult.workingFee} (${feeResult.workingFee / 10000}%)`);
    console.log(`⛽ Gas needed: ${feeResult.gas}`);
  } else {
    console.log(`❌ NO WORKING SOLUTION FOUND`);
    console.log(`💡 The issue might be:`);
    console.log(`   - Token has transfer restrictions`);
    console.log(`   - Pool doesn't exist for any fee tier`);
    console.log(`   - Router implementation issue`);
  }
}

runAllTests().catch(console.error);