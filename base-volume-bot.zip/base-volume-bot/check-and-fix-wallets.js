/**
 * 🔧 CHECK AND FIX WALLETS
 * Checks database wallets and fixes decryption issues
 */

const { Client } = require('pg');

async function checkAndFixWallets() {
  console.log('🔧 CHECKING AND FIXING WALLETS');
  console.log('==============================');
  
  const client = new Client({
    host: 'localhost',
    port: 5432,
    database: 'looter_ai_clone',
    user: 'faisal',
    password: ''
  });
  
  try {
    await client.connect();
    console.log('✅ Connected to database');
    
    const userId = 6537510183;
    
    // Check what wallets exist
    const result = await client.query(
      'SELECT * FROM wallets WHERE user_id = $1',
      [userId]
    );
    
    console.log(`\n📊 Found ${result.rows.length} wallet records for user ${userId}`);
    
    if (result.rows.length > 0) {
      console.log('\n🔍 WALLET RECORDS:');
      result.rows.forEach((row, index) => {
        console.log(`   ${index + 1}. ${row.wallet_slot} (${row.chain}): ${row.address}`);
        console.log(`      Created: ${row.created_at}`);
        console.log(`      Encrypted: ${row.encrypted_private_key ? 'YES' : 'NO'}`);
      });
      
      console.log('\n🚨 ISSUE: Wallets exist but decryption is failing');
      console.log('💡 SOLUTION: The wallets were encrypted with a different key');
      
      console.log('\n🔧 FIXING OPTIONS:');
      console.log('1. 🗑️ Delete corrupted wallets and re-import');
      console.log('2. 🔑 Try to find the original encryption key');
      console.log('3. 💾 Backup and recreate wallet database');
      
      // Option 1: Delete corrupted wallets
      console.log('\n🔧 EXECUTING FIX: Delete corrupted wallets...');
      
      const deleteResult = await client.query(
        'DELETE FROM wallets WHERE user_id = $1',
        [userId]
      );
      
      console.log(`✅ Deleted ${deleteResult.rowCount} corrupted wallet records`);
      
      console.log('\n💡 NEXT STEPS:');
      console.log('1. 🔄 Restart the bot');
      console.log('2. 📱 Send /start to the bot');
      console.log('3. 💼 Import your W5 wallet again');
      console.log('4. 🧪 Test trading with TONY token');
      
      return true;
      
    } else {
      console.log('\n❌ No wallet records found');
      console.log('💡 SOLUTION: Import wallets first');
      
      console.log('\n📱 STEPS TO IMPORT WALLET:');
      console.log('1. Send /start to the bot');
      console.log('2. Go to wallet management');
      console.log('3. Import your W5 wallet');
      console.log('4. Test trading');
      
      return false;
    }
    
  } catch (error) {
    console.error('❌ Database check failed:', error.message);
    return false;
  } finally {
    await client.end();
  }
}

// Run the check and fix
checkAndFixWallets().then(success => {
  if (success) {
    console.log('\n🎉 WALLET ISSUE FIXED!');
    console.log('✅ Corrupted wallets removed');
    console.log('🚀 Ready to import fresh wallets');
  } else {
    console.log('\n⚠️ MANUAL WALLET IMPORT NEEDED');
    console.log('📱 Use the bot to import wallets');
  }
}).catch(console.error);