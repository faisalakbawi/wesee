const TokenAnalyzer = require('./trading/token-analyzer');
const ChainManager = require('./chains/chain-manager');

async function testTokenAnalyzer() {
  const chainManager = new ChainManager();
  const analyzer = new TokenAnalyzer(chainManager);
  
  // Test with a known token address
  const testAddresses = [
    '0xA0b86a33E6441f5A8D887403F6e4a31989e8F7f8', // Example ETH
    'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDd1v' // Example SOL
  ];
  
  for (const address of testAddresses) {
    try {
      console.log(`Testing address: ${address}`);
      const result = await analyzer.analyzeToken(address);
      console.log('Result:', result);
    } catch (error) {
      console.error('Error:', error.message);
    }
  }
}

testTokenAnalyzer();
