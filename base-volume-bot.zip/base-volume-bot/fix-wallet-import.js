/**
 * FIX WALLET IMPORT & SMART SELECTION
 * Import your private key and test the new smart wallet selection system
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const BuyTokenUI = require('./callbacks/buy-token-ui');
const TokenAnalyzer = require('./trading/token-analyzer');

async function fixWalletImport() {
  console.log('🔧 ========== FIX WALLET IMPORT ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const tokenAnalyzer = new TokenAnalyzer();
    
    // Mock bot for testing
    const mockBot = { editMessageText: () => {}, sendMessage: () => {} };
    const buyTokenUI = new BuyTokenUI(mockBot, walletManager, tokenAnalyzer);
    
    // Your Telegram user ID (replace with your actual ID)
    const yourUserId = 12345; // Replace this with your actual Telegram user ID
    const chain = 'base';
    const targetSlot = 'W5'; // The slot you want to use
    
    console.log(`🔧 Fixing wallet import for user: ${yourUserId}`);
    console.log(`🔧 Target chain: ${chain}`);
    console.log(`🔧 Target slot: ${targetSlot}`);
    
    // IMPORTANT: Replace this with your actual private key
    // ⚠️ SECURITY NOTE: Only use this for testing, then delete the private key from this file
    const yourPrivateKey = 'YOUR_PRIVATE_KEY_HERE'; // Replace with your actual private key
    
    console.log('⚠️  SECURITY REMINDER: Make sure to delete your private key from this file after testing!');
    
    if (yourPrivateKey === 'YOUR_PRIVATE_KEY_HERE') {
      console.log('❌ Please edit this script and add your actual private key');
      console.log('❌ Replace "YOUR_PRIVATE_KEY_HERE" with your private key');
      process.exit(1);
    }
    
    // Validate private key format
    const cleanKey = yourPrivateKey.replace(/^0x/, '').trim();
    if (!/^[a-fA-F0-9]{64}$/.test(cleanKey)) {
      console.log('❌ Invalid private key format');
      console.log('❌ Private key must be exactly 64 hexadecimal characters');
      process.exit(1);
    }
    
    console.log('✅ Private key format is valid');
    
    // Check current wallet in target slot
    const currentWallets = await walletManager.getChainWallets(yourUserId, chain);
    const currentWallet = currentWallets[targetSlot];
    
    if (currentWallet) {
      console.log(`🔍 Current wallet in ${targetSlot}:`);
      console.log(`   Address: ${currentWallet.address}`);
      console.log(`   Balance: ${await walletManager.getWalletBalance(currentWallet.address, chain)} ETH`);
      console.log(`🔄 This wallet will be replaced...`);
    } else {
      console.log(`✅ Slot ${targetSlot} is empty, ready for import`);
    }
    
    // Import the wallet using the proper method (finds available slot automatically)
    console.log(`🔧 Importing private key...`);
    
    const result = await walletManager.importPrivateKey(yourUserId, `0x${cleanKey}`, chain);
    
    if (result.success) {
      console.log('✅ WALLET IMPORT SUCCESSFUL!');
      console.log(`🎯 Address: ${result.address}`);
      console.log(`💼 Slot: ${result.slot}`);
      console.log(`⛓️ Chain: ${result.chain}`);
      
      // Verify the import
      console.log('\n🔍 Verifying import...');
      const updatedWallets = await walletManager.getChainWallets(yourUserId, chain);
      const importedWallet = updatedWallets[result.slot];
      
      if (importedWallet && importedWallet.address.toLowerCase() === result.address.toLowerCase()) {
        console.log('✅ Import verified successfully!');
        console.log(`✅ Wallet is marked as imported: ${importedWallet.isImported}`);
        
        // Check balance
        const balance = await walletManager.getWalletBalance(importedWallet.address, chain);
        console.log(`💰 Wallet balance: ${balance} ETH`);
        
        if (parseFloat(balance) > 0) {
          console.log('🎉 SUCCESS! Your funded wallet is now in the bot and ready for trading!');
          
          // Test the smart wallet selection
          console.log('\n🧠 TESTING SMART WALLET SELECTION...');
          const walletPriorities = await buyTokenUI.getSmartWalletSelection(yourUserId, chain);
          
          if (walletPriorities.length > 0) {
            console.log('✅ Smart selection working! Top wallet:');
            const topWallet = walletPriorities[0];
            console.log(`   🥇 ${topWallet.walletSlot}: ${topWallet.priorityScore.toFixed(1)} points`);
            console.log(`   📍 Address: ${topWallet.address}`);
            console.log(`   💰 Balance: ${topWallet.balance} ETH`);
            console.log(`   📥 Imported: ${topWallet.isImported ? 'Yes' : 'No'}`);
            
            if (topWallet.address.toLowerCase() === result.address.toLowerCase()) {
              console.log('🎯 PERFECT! Your imported wallet is now the top priority!');
            } else {
              console.log('⚠️ Your imported wallet is not the top priority. This might be because:');
              console.log('   - Another wallet has a higher balance');
              console.log('   - Another wallet was imported more recently');
            }
          }
          
        } else {
          console.log('⚠️ Wallet imported but shows 0 balance. Please check:');
          console.log('   1. The private key is correct');
          console.log('   2. The wallet has ETH on Base network');
          console.log('   3. Network connection is working');
        }
      } else {
        console.log('❌ Import verification failed');
      }
    } else {
      console.log('❌ WALLET IMPORT FAILED');
      console.log(`❌ Error: ${result.error}`);
      
      // If slots are full, suggest replacement
      if (result.error.includes('full')) {
        console.log('\n💡 SOLUTION: All slots are full. You can:');
        console.log('   1. Delete an unused wallet first');
        console.log('   2. Use the replaceWalletWithPrivateKey method instead');
        
        console.log('\n🔄 Trying to replace the empty wallet in W5...');
        const replaceResult = await walletManager.replaceWalletWithPrivateKey(
          yourUserId, 
          `0x${cleanKey}`, 
          targetSlot, 
          chain
        );
        
        if (replaceResult.success) {
          console.log('✅ WALLET REPLACEMENT SUCCESSFUL!');
          console.log(`🎯 Address: ${replaceResult.address}`);
          console.log(`💼 Slot: ${replaceResult.walletSlot}`);
        } else {
          console.log('❌ WALLET REPLACEMENT FAILED');
          console.log(`❌ Error: ${replaceResult.error}`);
        }
      }
    }

  } catch (error) {
    console.error('❌ ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

fixWalletImport().then(() => {
  console.log('\n🎉 Fix completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Fix failed:', error);
  process.exit(1);
});