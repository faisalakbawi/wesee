/**
 * TEST WALLET IMPORT
 * Test the wallet import process directly to debug the issue
 */

const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function testWalletImport() {
  console.log('📥 ========== TEST WALLET IMPORT ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    const userId = 12345;
    const chain = 'base';
    const testPrivateKey = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'; // Test key
    
    console.log(`📥 Testing wallet import for user: ${userId}`);
    console.log(`📥 Chain: ${chain}`);
    console.log(`📥 Test private key: ${testPrivateKey}`);
    
    // Test the import process
    console.log(`\n🔧 Calling walletManager.importPrivateKey...`);
    const result = await walletManager.importPrivateKey(userId, testPrivateKey, chain);
    
    console.log(`\n📊 Import result:`, result);
    
    if (result.success) {
      console.log(`✅ SUCCESS: Wallet imported successfully!`);
      console.log(`   Address: ${result.address}`);
      console.log(`   Slot: ${result.slot}`);
      console.log(`   Chain: ${result.chain}`);
      
      // Verify it's in the database
      console.log(`\n🔍 Verifying wallet is in database...`);
      const chainWallets = await walletManager.getChainWallets(userId, chain);
      
      console.log(`📊 Chain wallets after import:`);
      Object.keys(chainWallets).forEach(slot => {
        const wallet = chainWallets[slot];
        const importedStatus = wallet.isImported ? '📥 IMPORTED' : '🔧 GENERATED';
        console.log(`   ${slot}: ${wallet.address} [${importedStatus}]`);
        
        if (wallet.address === result.address) {
          console.log(`      🎯 THIS IS THE IMPORTED WALLET!`);
        }
      });
      
    } else {
      console.log(`❌ FAILED: ${result.error}`);
    }

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

testWalletImport().then(() => {
  console.log('\n🎉 Wallet import test completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});