/**
 * CHECK USER WALLETS
 * See what wallets are available for trading
 */

const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');

async function checkUserWallets() {
  console.log('🔍 ========== CHECKING USER WALLETS ==========');

  try {
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    // Initialize the wallet manager
    await walletManager.initialize();
    
    const testUserId = 12345;  // Your test user ID
    
    console.log(`🔍 Checking wallets for user: ${testUserId}`);
    
    // Check all supported chains
    const chains = ['base', 'ethereum', 'bsc'];
    
    for (const chain of chains) {
      console.log(`\n⛓️ Chain: ${chain.toUpperCase()}`);
      
      const chainWallets = await walletManager.getChainWallets(testUserId, chain);
      
      if (Object.keys(chainWallets).length === 0) {
        console.log(`❌ No wallets found for ${chain}`);
      } else {
        console.log(`✅ Found ${Object.keys(chainWallets).length} wallets for ${chain}:`);
        
        for (const [slot, wallet] of Object.entries(chainWallets)) {
          console.log(`   ${slot}: ${wallet.address}`);
          console.log(`        Private Key: ${wallet.privateKey ? 'Available' : 'Missing'}`);
        }
      }
    }
    
    console.log('\n🔍 ========== RECOMMENDATION ==========');
    
    const baseWallets = await walletManager.getChainWallets(testUserId, 'base');
    if (Object.keys(baseWallets).length === 0) {
      console.log('❌ NO BASE WALLETS FOUND!');
      console.log('💡 You need to create wallets first:');
      console.log('   1. Send /wallets to the bot');
      console.log('   2. Click "💼 Manage Wallets"');
      console.log('   3. Click "➕ Generate New Wallet"');
      console.log('   4. Select "Base" chain');
      console.log('   5. Generate at least 1 wallet');
      console.log('   6. Add some ETH to the wallet for trading');
    } else {
      console.log('✅ Base wallets found!');
      console.log('💡 Now check if they have ETH balance:');
      
      for (const [slot, wallet] of Object.entries(baseWallets)) {
        console.log(`   ${slot} (${wallet.address}) - Check balance on Base network`);
      }
    }

  } catch (error) {
    console.error('❌ Error checking wallets:', error.message);
  }
}

checkUserWallets();