#!/usr/bin/env node

/**
 * WALLET SELECTION FLOW INVESTIGATION
 * Test the complete wallet selection and callback flow
 */

require('dotenv').config();
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

async function investigateWalletSelection() {
  const chainManager = new ChainManager();
  const walletManager = new WalletDBManager(chainManager);
  
  try {
    await walletManager.initialize();
    console.log('🔍 ========== WALLET SELECTION FLOW INVESTIGATION ==========');
    
    const userId = 6537510183; // Your Telegram ID
    const chain = 'base';
    
    // 1. Test getChainWallets method (used in buy flow)
    console.log('\n1️⃣ TESTING getChainWallets() METHOD:');
    const chainWallets = await walletManager.getChainWallets(userId, chain);
    console.log('📊 Chain wallets result:', chainWallets);
    
    if (Object.keys(chainWallets).length === 0) {
      console.log('❌ No wallets returned by getChainWallets!');
    } else {
      console.log('✅ Wallets found:');
      Object.keys(chainWallets).forEach(slot => {
        const wallet = chainWallets[slot];
        console.log(`   ${slot}: ${wallet.address}`);
        console.log(`      - Has Private Key: ${!!wallet.privateKey}`);
        console.log(`      - Is Imported: ${wallet.isImported}`);
        console.log(`      - Balance: ${wallet.balance || 'Not cached'}`);
      });
    }
    
    // 2. Test wallet validation
    console.log('\n2️⃣ TESTING WALLET VALIDATION:');
    if (Object.keys(chainWallets).length > 0) {
      const firstWallet = Object.values(chainWallets)[0];
      console.log(`Testing validation for: ${firstWallet.address}`);
      
      try {
        const validation = await walletManager.validateWalletForTrade(
          firstWallet.address,
          chain,
          '0.001' // 0.001 ETH
        );
        console.log('✅ Wallet validation result:', validation);
      } catch (error) {
        console.log('❌ Wallet validation failed:', error.message);
      }
    }
    
    // 3. Test balance fetching
    console.log('\n3️⃣ TESTING BALANCE FETCHING:');
    if (Object.keys(chainWallets).length > 0) {
      const firstWallet = Object.values(chainWallets)[0];
      console.log(`Testing balance for: ${firstWallet.address}`);
      
      try {
        const balance = await walletManager.getWalletBalance(firstWallet.address, chain);
        console.log('✅ Balance result:', balance);
      } catch (error) {
        console.log('❌ Balance fetching failed:', error.message);
      }
    }
    
    // 4. Test wallet slot selection logic
    console.log('\n4️⃣ TESTING WALLET SLOT SELECTION:');
    const testSlots = ['W1', 'W2', 'W3', 'W4', 'W5'];
    testSlots.forEach(slot => {
      const exists = !!chainWallets[slot];
      console.log(`   ${slot}: ${exists ? '✅ EXISTS' : '❌ MISSING'}`);
      if (exists) {
        console.log(`      Address: ${chainWallets[slot].address}`);
        console.log(`      Private Key: ${chainWallets[slot].privateKey ? 'Present' : 'Missing'}`);
      }
    });
    
    // 5. Simulate the exact wallet selection logic from trading.js
    console.log('\n5️⃣ SIMULATING TRADING.JS WALLET SELECTION:');
    const options = { walletSlot: 'W1' }; // This is what gets passed from the UI
    
    console.log(`🔍 ========== WALLET SELECTION DEBUG ==========`);
    console.log(`   - User ID: ${userId}`);
    console.log(`   - Chain: ${chain}`);
    console.log(`   - Requested slot: "${options.walletSlot}"`);
    console.log(`   - Available slots:`, Object.keys(chainWallets));
    console.log(`   - Slot exists:`, !!chainWallets[options.walletSlot]);
    
    // Show all available wallets
    Object.keys(chainWallets).forEach(slot => {
      const wallet = chainWallets[slot];
      console.log(`   - ${slot}: ${wallet.address} (imported: ${wallet.isImported})`);
    });
    
    let walletToUse;
    if (options.walletSlot && chainWallets[options.walletSlot]) {
      walletToUse = chainWallets[options.walletSlot];
      console.log(`🎯 ✅ USING SELECTED WALLET ${options.walletSlot}: ${walletToUse.address}`);
      console.log(`🎯 ✅ WALLET IS IMPORTED: ${walletToUse.isImported}`);
    } else {
      walletToUse = Object.values(chainWallets)[0];
      const firstSlot = Object.keys(chainWallets)[0];
      console.log(`🎯 ❌ FALLBACK TO FIRST WALLET ${firstSlot}: ${walletToUse?.address}`);
      console.log(`⚠️  FALLBACK REASON: ${!options.walletSlot ? 'No slot specified' : 'Requested slot not found'}`);
    }
    
    if (walletToUse && walletToUse.privateKey) {
      console.log(`✅ Selected wallet has private key: ${walletToUse.privateKey.substring(0, 10)}...`);
    } else {
      console.log(`❌ Selected wallet missing private key!`);
    }
    
    console.log('\n🔍 ========== INVESTIGATION COMPLETE ==========');
    
  } catch (error) {
    console.error('❌ Investigation failed:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    await walletManager.close();
  }
}

// Run investigation
investigateWalletSelection();