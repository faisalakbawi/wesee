#!/usr/bin/env node

/**
 * DEEP DATABASE WALLET INVESTIGATION
 * Check current state of wallets in database
 */

require('dotenv').config();
const Database = require('./database/database');

async function investigateDatabase() {
  const db = new Database();
  
  try {
    await db.initialize();
    console.log('🔍 ========== DATABASE WALLET INVESTIGATION ==========');
    
    const userId = 6537510183; // Your Telegram ID
    
    // 1. Check if user exists
    console.log('\n1️⃣ USER EXISTENCE CHECK:');
    const userResult = await db.query('SELECT * FROM users WHERE telegram_id = $1', [userId]);
    if (userResult.rows.length === 0) {
      console.log('❌ User not found in database!');
      return;
    }
    
    const user = userResult.rows[0];
    console.log('✅ User found:', {
      id: user.id,
      telegram_id: user.telegram_id,
      created_at: user.created_at,
      last_active: user.last_active
    });
    
    // 2. Check all chains
    console.log('\n2️⃣ AVAILABLE CHAINS:');
    const chainsResult = await db.query('SELECT * FROM chains ORDER BY name');
    chainsResult.rows.forEach(chain => {
      console.log(`   ${chain.icon} ${chain.name} (${chain.chain_id}) - UUID: ${chain.id}`);
    });
    
    // 3. Check all wallets for this user
    console.log('\n3️⃣ USER WALLETS (ALL CHAINS):');
    const walletsResult = await db.query(`
      SELECT w.*, c.chain_id, c.name as chain_name, c.icon
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1 AND w.is_active = TRUE
      ORDER BY c.name, w.wallet_slot
    `, [user.id]);
    
    if (walletsResult.rows.length === 0) {
      console.log('❌ No wallets found for this user!');
    } else {
      console.log(`✅ Found ${walletsResult.rows.length} wallets:`);
      walletsResult.rows.forEach(wallet => {
        console.log(`   ${wallet.icon} ${wallet.chain_name} - ${wallet.wallet_slot}: ${wallet.address}`);
        console.log(`      - Imported: ${wallet.is_imported}`);
        console.log(`      - Created: ${wallet.created_at}`);
        console.log(`      - Updated: ${wallet.updated_at}`);
        console.log(`      - Has Private Key: ${!!wallet.private_key}`);
        console.log(`      - Has Seed Phrase: ${!!wallet.seed_phrase}`);
        console.log('');
      });
    }
    
    // 4. Check Base chain specifically
    console.log('\n4️⃣ BASE CHAIN WALLETS DETAILED:');
    const baseWalletsResult = await db.query(`
      SELECT w.*, c.chain_id, c.name as chain_name
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1 AND c.chain_id = 'base' AND w.is_active = TRUE
      ORDER BY w.wallet_slot
    `, [user.id]);
    
    if (baseWalletsResult.rows.length === 0) {
      console.log('❌ No Base wallets found!');
    } else {
      console.log(`✅ Found ${baseWalletsResult.rows.length} Base wallets:`);
      baseWalletsResult.rows.forEach(wallet => {
        console.log(`   ${wallet.wallet_slot}: ${wallet.address}`);
        console.log(`      - UUID: ${wallet.id}`);
        console.log(`      - Imported: ${wallet.is_imported}`);
        console.log(`      - Active: ${wallet.is_active}`);
        console.log(`      - Created: ${wallet.created_at}`);
        console.log(`      - Updated: ${wallet.updated_at}`);
        
        // Try to decrypt private key
        try {
          const decryptedKey = db.decrypt(wallet.private_key);
          console.log(`      - Private Key: ${decryptedKey.substring(0, 10)}...${decryptedKey.substring(decryptedKey.length - 10)}`);
        } catch (error) {
          console.log(`      - Private Key: ❌ Decryption failed: ${error.message}`);
        }
        console.log('');
      });
    }
    
    // 5. Check wallet history
    console.log('\n5️⃣ WALLET HISTORY:');
    const historyResult = await db.query(`
      SELECT wh.*, w.wallet_slot, c.chain_id
      FROM wallet_history wh
      JOIN wallets w ON wh.wallet_id = w.id
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1
      ORDER BY wh.created_at DESC
      LIMIT 20
    `, [user.id]);
    
    if (historyResult.rows.length === 0) {
      console.log('❌ No wallet history found!');
    } else {
      console.log(`✅ Found ${historyResult.rows.length} history entries:`);
      historyResult.rows.forEach(entry => {
        console.log(`   ${entry.created_at}: ${entry.action_type} - ${entry.chain_id}/${entry.wallet_slot}`);
        console.log(`      - Old: ${entry.old_value || 'N/A'}`);
        console.log(`      - New: ${entry.new_value || 'N/A'}`);
        console.log(`      - Metadata: ${entry.metadata || 'N/A'}`);
        console.log('');
      });
    }
    
    // 6. Check for duplicate wallets (same address, different slots)
    console.log('\n6️⃣ DUPLICATE WALLET CHECK:');
    const duplicatesResult = await db.query(`
      SELECT address, COUNT(*) as count, array_agg(wallet_slot) as slots, c.chain_id
      FROM wallets w
      JOIN chains c ON w.chain_id = c.id
      WHERE w.user_id = $1 AND w.is_active = TRUE
      GROUP BY address, c.chain_id
      HAVING COUNT(*) > 1
    `, [user.id]);
    
    if (duplicatesResult.rows.length === 0) {
      console.log('✅ No duplicate wallets found');
    } else {
      console.log('⚠️ Found duplicate wallets:');
      duplicatesResult.rows.forEach(dup => {
        console.log(`   ${dup.chain_id}: ${dup.address} appears in slots: ${dup.slots.join(', ')}`);
      });
    }
    
    // 7. Check for missing slots
    console.log('\n7️⃣ MISSING WALLET SLOTS CHECK:');
    const expectedSlots = ['W1', 'W2', 'W3', 'W4', 'W5'];
    const chains = ['base', 'ethereum', 'bsc'];
    
    for (const chainId of chains) {
      const chainWalletsResult = await db.query(`
        SELECT w.wallet_slot
        FROM wallets w
        JOIN chains c ON w.chain_id = c.id
        WHERE w.user_id = $1 AND c.chain_id = $2 AND w.is_active = TRUE
      `, [user.id, chainId]);
      
      const existingSlots = chainWalletsResult.rows.map(w => w.wallet_slot);
      const missingSlots = expectedSlots.filter(slot => !existingSlots.includes(slot));
      
      console.log(`   ${chainId}: Existing: [${existingSlots.join(', ')}], Missing: [${missingSlots.join(', ')}]`);
    }
    
    console.log('\n🔍 ========== INVESTIGATION COMPLETE ==========');
    
  } catch (error) {
    console.error('❌ Investigation failed:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    await db.close();
  }
}

// Run investigation
investigateDatabase();