/**
 * LOOTER.AI CLONE - WALLET MANAGER
 * Enhanced multi-chain wallet system (YOUR design preserved!)
 */

const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const { Keypair } = require('@solana/web3.js');
const bip39 = require('bip39');
const { derivePath } = require('ed25519-hd-key');

class WalletManager {
  constructor() {
    this.walletsFile = path.join(__dirname, '../data/wallets.json');
    this.userWallets = new Map(); // chatId -> { chain -> { W1, W2, W3, W4, W5 } }
    this.loadWallets();
    console.log('💼 Wallet Manager initialized');
  }

  // Generate new wallet for specific chain with seed phrase
  generateWallet(chatId, walletSlot, chain = 'base') {
    try {
      let walletData;
      
      if (chain === 'solana') {
        // Generate Solana wallet with seed phrase
        const mnemonic = bip39.generateMnemonic();
        const seed = bip39.mnemonicToSeedSync(mnemonic);
        const derivedSeed = derivePath("m/44'/501'/0'/0'", seed.toString('hex')).key;
        const keypair = Keypair.fromSeed(derivedSeed);
        
        walletData = {
          address: keypair.publicKey.toString(),
          privateKey: Buffer.from(keypair.secretKey).toString('hex'),
          seedPhrase: mnemonic,
          type: 'generated_with_seed',
          createdAt: Date.now()
        };
      } else {
        // Generate EVM wallet with seed phrase
        const newWallet = ethers.Wallet.createRandom();
        
        walletData = {
          address: newWallet.address,
          privateKey: newWallet.privateKey,
          seedPhrase: newWallet.mnemonic.phrase,
          type: 'generated_with_seed',
          createdAt: Date.now()
        };
      }
      
      let userWallets = this.userWallets.get(chatId) || {};
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }
      
      userWallets[chain][walletSlot] = walletData;
      
      this.userWallets.set(chatId, userWallets);
      this.saveWallets();
      
      console.log(`✅ Generated wallet ${walletSlot} for user ${chatId} on ${chain} with seed phrase`);
      return walletData.address;
      
    } catch (error) {
      console.error('❌ Error generating wallet:', error.message);
      throw error;
    }
  }

  // Import existing wallet
  importWallet(chatId, walletSlot, privateKey, chain = 'base') {
    try {
      const wallet = new ethers.Wallet(privateKey);
      
      let userWallets = this.userWallets.get(chatId) || {};
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }
      
      userWallets[chain][walletSlot] = {
        address: wallet.address,
        privateKey: privateKey,
        type: 'imported',
        createdAt: Date.now()
      };
      
      this.userWallets.set(chatId, userWallets);
      this.saveWallets();
      
      console.log(`✅ Imported wallet ${walletSlot} for user ${chatId} on ${chain}`);
      return wallet.address;
      
    } catch (error) {
      console.error('❌ Error importing wallet:', error.message);
      throw new Error('Invalid private key');
    }
  }

  // Get wallets for specific chain
  getChainWallets(chatId, chain) {
    const userWallets = this.userWallets.get(chatId) || {};
    return userWallets[chain] || {};
  }

  // Get all user wallets
  getUserWallets(chatId) {
    return this.userWallets.get(chatId) || {};
  }

  // Delete wallet
  deleteWallet(chatId, walletSlot, chain) {
    try {
      const userWallets = this.userWallets.get(chatId) || {};
      if (userWallets[chain] && userWallets[chain][walletSlot]) {
        delete userWallets[chain][walletSlot];
        this.userWallets.set(chatId, userWallets);
        this.saveWallets();
        console.log(`🗑️ Deleted wallet ${walletSlot} for user ${chatId} on ${chain}`);
        return true;
      }
      return false;
    } catch (error) {
      console.error('❌ Error deleting wallet:', error.message);
      return false;
    }
  }

  // Export wallet private key
  exportWallet(chatId, walletSlot, chain) {
    try {
      const chainWallets = this.getChainWallets(chatId, chain);
      const wallet = chainWallets[walletSlot];
      
      if (!wallet) {
        throw new Error('Wallet not found');
      }
      
      return wallet.privateKey;
    } catch (error) {
      console.error('❌ Error exporting wallet:', error.message);
      throw error;
    }
  }

  // Initialize 5 fresh wallets for new user
  async initializeFreshWallets(chatId, chain = 'base') {
    try {
      const chainWallets = this.getChainWallets(chatId, chain);
      const existingCount = Object.keys(chainWallets).length;
      
      if (existingCount < 5) {
        for (let i = 1; i <= 5; i++) {
          const walletSlot = `W${i}`;
          if (!chainWallets[walletSlot]) {
            this.generateWallet(chatId, walletSlot, chain);
          }
        }
        console.log(`✅ Initialized fresh wallets for user ${chatId} on ${chain}`);
      }
    } catch (error) {
      console.error('❌ Error initializing fresh wallets:', error.message);
    }
  }

  // Get wallet balance using chain manager
  async getWalletBalance(address, chain) {
    try {
      const ChainManager = require('../chains/chain-manager');
      const chainManager = new ChainManager();
      return await chainManager.getWalletBalance(chain, address);
    } catch (error) {
      console.error('❌ Error getting wallet balance:', error.message);
      return "0.0";
    }
  }

  // Import wallet from private key
  async importPrivateKey(chatId, privateKey, chain = 'base') {
    try {
      // Validate private key format
      const cleanKey = privateKey.replace(/^0x/, '');
      if (!/^[a-fA-F0-9]{64}$/.test(cleanKey)) {
        return { success: false, error: 'Invalid private key format' };
      }

      // Create wallet from private key
      const wallet = new ethers.Wallet(`0x${cleanKey}`);
      const address = wallet.address;

      // Find available slot
      const userWallets = this.getUserWallets(chatId);
      const chainWallets = userWallets[chain] || {};
      
      console.log(`🔍 Checking slots for user ${chatId} on ${chain}:`);
      console.log('Chain wallets:', Object.keys(chainWallets));
      
      let availableSlot = null;
      for (let i = 1; i <= 5; i++) {
        const slot = `W${i}`;
        console.log(`Checking slot ${slot}: ${chainWallets[slot] ? 'OCCUPIED' : 'AVAILABLE'}`);
        if (!chainWallets[slot]) {
          availableSlot = slot;
          break;
        }
      }

      console.log(`Available slot: ${availableSlot}`);

      if (!availableSlot) {
        console.log('🚫 All slots full, returning SLOTS_FULL error');
        return { success: false, error: 'SLOTS_FULL', slotsFullMessage: true, chainWallets: chainWallets, chain: chain };
      }

      // Store wallet
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }

      userWallets[chain][availableSlot] = {
        address: address,
        privateKey: `0x${cleanKey}`,
        type: 'imported_privatekey',
        createdAt: new Date().toISOString()
      };

      this.userWallets.set(chatId, userWallets);
      this.saveWallets();

      console.log(`✅ Imported private key wallet ${availableSlot} for user ${chatId} on ${chain}`);
      
      return { 
        success: true, 
        address: address, 
        slot: availableSlot,
        chain: chain
      };

    } catch (error) {
      console.error('❌ Error importing private key:', error.message);
      return { success: false, error: error.message };
    }
  }

  // Import wallet from seed phrase (supports all chains)
  async importSeedPhrase(chatId, seedPhrase, chain = 'base') {
    try {
      // Validate seed phrase
      const words = seedPhrase.trim().split(/\s+/);
      if (words.length !== 12 && words.length !== 24) {
        return { success: false, error: 'Seed phrase must be 12 or 24 words' };
      }

      // Validate mnemonic
      if (!bip39.validateMnemonic(seedPhrase)) {
        return { success: false, error: 'Invalid seed phrase' };
      }

      let walletData;

      if (chain === 'solana') {
        // Create Solana wallet from seed phrase
        const seed = bip39.mnemonicToSeedSync(seedPhrase);
        const derivedSeed = derivePath("m/44'/501'/0'/0'", seed.toString('hex')).key;
        const keypair = Keypair.fromSeed(derivedSeed);
        
        walletData = {
          address: keypair.publicKey.toString(),
          privateKey: Buffer.from(keypair.secretKey).toString('hex'),
          seedPhrase: seedPhrase,
          type: 'imported_seedphrase',
          createdAt: new Date().toISOString()
        };
      } else {
        // Create EVM wallet from seed phrase
        const wallet = ethers.Wallet.fromMnemonic(seedPhrase);
        
        walletData = {
          address: wallet.address,
          privateKey: wallet.privateKey,
          seedPhrase: seedPhrase,
          type: 'imported_seedphrase',
          createdAt: new Date().toISOString()
        };
      }

      // Find available slot
      const userWallets = this.getUserWallets(chatId);
      const chainWallets = userWallets[chain] || {};
      
      let availableSlot = null;
      for (let i = 1; i <= 5; i++) {
        const slot = `W${i}`;
        if (!chainWallets[slot]) {
          availableSlot = slot;
          break;
        }
      }

      if (!availableSlot) {
        return { success: false, error: 'SLOTS_FULL', slotsFullMessage: true, chainWallets: chainWallets, chain: chain };
      }

      // Store wallet
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }

      userWallets[chain][availableSlot] = walletData;

      this.userWallets.set(chatId, userWallets);
      this.saveWallets();

      console.log(`✅ Imported seed phrase wallet ${availableSlot} for user ${chatId} on ${chain}`);
      
      return { 
        success: true, 
        address: walletData.address, 
        slot: availableSlot,
        chain: chain
      };

    } catch (error) {
      console.error('❌ Error importing seed phrase:', error.message);
      return { success: false, error: error.message };
    }
  }

  // Replace wallet in specific slot with private key
  async replaceWalletWithPrivateKey(chatId, privateKey, walletSlot, chain = 'base') {
    try {
      // Validate private key format
      const cleanKey = privateKey.replace(/^0x/, '');
      if (!/^[a-fA-F0-9]{64}$/.test(cleanKey)) {
        return { success: false, error: 'Invalid private key format' };
      }

      // Create wallet from private key
      const wallet = new ethers.Wallet(`0x${cleanKey}`);
      const address = wallet.address;

      // Get user wallets
      const userWallets = this.getUserWallets(chatId);
      
      // Store wallet in specific slot
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }

      userWallets[chain][walletSlot] = {
        address: address,
        privateKey: `0x${cleanKey}`,
        type: 'imported_privatekey',
        createdAt: new Date().toISOString()
      };

      this.userWallets.set(chatId, userWallets);
      this.saveWallets();

      console.log(`✅ Replaced wallet ${walletSlot} with private key for user ${chatId} on ${chain}`);
      
      return { 
        success: true, 
        address: address, 
        slot: walletSlot,
        chain: chain
      };

    } catch (error) {
      console.error('❌ Error replacing wallet with private key:', error.message);
      return { success: false, error: error.message };
    }
  }

  // Replace wallet in specific slot with seed phrase
  async replaceWalletWithSeedPhrase(chatId, seedPhrase, walletSlot, chain = 'base') {
    try {
      // Validate seed phrase
      const words = seedPhrase.trim().split(/\s+/);
      if (words.length !== 12 && words.length !== 24) {
        return { success: false, error: 'Seed phrase must be 12 or 24 words' };
      }

      // Create wallet from seed phrase
      const wallet = ethers.Wallet.fromMnemonic(seedPhrase);
      const address = wallet.address;

      // Get user wallets
      const userWallets = this.getUserWallets(chatId);
      
      // Store wallet in specific slot
      if (!userWallets[chain]) {
        userWallets[chain] = {};
      }

      userWallets[chain][walletSlot] = {
        address: address,
        privateKey: wallet.privateKey,
        seedPhrase: seedPhrase,
        type: 'imported_seedphrase',
        createdAt: new Date().toISOString()
      };

      this.userWallets.set(chatId, userWallets);
      this.saveWallets();

      console.log(`✅ Replaced wallet ${walletSlot} with seed phrase for user ${chatId} on ${chain}`);
      
      return { 
        success: true, 
        address: address, 
        slot: walletSlot,
        chain: chain
      };

    } catch (error) {
      console.error('❌ Error replacing wallet with seed phrase:', error.message);
      return { success: false, error: error.message };
    }
  }

  // Save wallets to disk
  saveWallets() {
    try {
      const walletsData = {};
      for (const [chatId, wallets] of this.userWallets.entries()) {
        walletsData[chatId] = wallets;
      }
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.walletsFile);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.walletsFile, JSON.stringify(walletsData, null, 2));
      console.log('💾 Wallets saved to disk');
    } catch (error) {
      console.error('❌ Error saving wallets:', error.message);
    }
  }

  // Load wallets from disk
  loadWallets() {
    try {
      if (fs.existsSync(this.walletsFile)) {
        const walletsData = JSON.parse(fs.readFileSync(this.walletsFile, 'utf8'));
        for (const [chatId, wallets] of Object.entries(walletsData)) {
          this.userWallets.set(chatId, wallets);
        }
        console.log('💾 Wallets loaded from disk');
      }
    } catch (error) {
      console.error('❌ Error loading wallets:', error.message);
    }
  }
}

module.exports = WalletManager;