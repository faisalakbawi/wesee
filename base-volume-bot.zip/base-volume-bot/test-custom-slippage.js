/**
 * TEST CUSTOM SLIPPAGE FUNCTIONALITY
 * Verify the new "💡 Custom %" button works correctly
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== MESSAGE EDITED ==========');
    console.log('📝 Text preview:', text.substring(0, 100) + '...');
    console.log('📝 Has reply_markup:', !!options.reply_markup);
    console.log('📝 Buttons:', options.reply_markup?.inline_keyboard?.map(row => 
      row.map(btn => btn.text).join(' | ')
    ).join('\n     '));
    console.log('📝 ===================================');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text) => {
    console.log('📤 Send message:', text.substring(0, 100));
    return { message_id: 124 };
  },
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ Callback answered:', options?.text || 'OK');
  },
  deleteMessage: async (chatId, messageId) => {
    console.log('🗑️ Message deleted:', messageId);
  }
};

async function testCustomSlippage() {
  console.log('🧪 ========== TESTING CUSTOM SLIPPAGE FUNCTIONALITY ==========');
  
  try {
    // Initialize components
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    const mockTrading = { chainManager: chainManager };
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    const buyTokenUI = callbacks.buyTokenUI;
    
    await walletManager.initialize();
    
    const testChatId = '6537510183';
    const testMessageId = 123;
    
    console.log('✅ Components initialized');
    
    // Step 1: Create token session
    console.log('\n1️⃣ Creating token session...');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await buyTokenUI.handleContractAddress(contractMsg);
    
    // Get session ID
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 2: Test slippage menu (should show new "Custom %" button)
    console.log('\n2️⃣ Opening slippage menu...');
    const slippageCallback = {
      id: 'test_123',
      data: `slippage_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    await callbacks.handle(slippageCallback);
    console.log('✅ Slippage menu opened (should show "💡 Custom %" button)');
    
    // Step 3: Test "Custom %" button
    console.log('\n3️⃣ Testing "💡 Custom %" button...');
    const customSlippageCallback = {
      id: 'test_124',
      data: `slippage_custom_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log('💡 Callback data:', customSlippageCallback.data);
    console.log('💡 About to handle custom slippage...');
    
    await callbacks.handle(customSlippageCallback);
    console.log('✅ Custom slippage prompt should be displayed');
    
    // Step 4: Test custom slippage input
    console.log('\n4️⃣ Testing custom slippage input...');
    const customInputMsg = {
      chat: { id: testChatId },
      text: '2.5',
      message_id: 125
    };
    
    console.log('💡 User input:', customInputMsg.text);
    console.log('💡 About to handle custom slippage input...');
    
    await callbacks.handleCustomSlippageInput(customInputMsg);
    console.log('✅ Custom slippage input processed');
    
    // Step 5: Verify slippage was set
    console.log('\n5️⃣ Verifying slippage was set...');
    const currentSlippage = buyTokenUI.getTokenSlippage(testChatId, sessionId);
    console.log('🔍 Current slippage after setting custom:', currentSlippage + '%');
    
    if (currentSlippage === 2.5) {
      console.log('✅ Custom slippage set correctly!');
    } else {
      throw new Error(`Expected 2.5%, got ${currentSlippage}%`);
    }
    
    // Step 6: Test invalid inputs
    console.log('\n6️⃣ Testing invalid inputs...');
    
    // Set state again for testing
    userStates.set(testChatId, {
      state: 'awaiting_custom_slippage',
      sessionId: sessionId,
      messageId: testMessageId
    });
    
    // Test invalid input
    const invalidInputMsg = {
      chat: { id: testChatId },
      text: 'abc',
      message_id: 126
    };
    
    await callbacks.handleCustomSlippageInput(invalidInputMsg);
    console.log('✅ Invalid input handled correctly');
    
    console.log('\n🎉 ========== TEST RESULTS ==========');
    console.log('✅ Token session creation: WORKING');
    console.log('✅ Slippage menu with "Custom %" button: WORKING');
    console.log('✅ Custom slippage prompt: WORKING');
    console.log('✅ Custom slippage input processing: WORKING');
    console.log('✅ Slippage value storage: WORKING');
    console.log('✅ Invalid input handling: WORKING');
    console.log('\n🚀 The "💡 Custom %" functionality is READY!');
    
    console.log('\n📋 ========== WHAT TO TEST IN TELEGRAM ==========');
    console.log('1. Send /start');
    console.log('2. Click "🔥 Buy Token"');
    console.log('3. Send: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913');
    console.log('4. Click "📊 Slippage X%"');
    console.log('5. Click "💡 Custom %" (NEW BUTTON!)');
    console.log('6. Type: 2.5');
    console.log('7. Check that main button shows "📊 Slippage 2.5%"');
    console.log('8. Test invalid inputs like "abc" or "100"');
    
  } catch (error) {
    console.error('\n❌ ========== TEST FAILED ==========');
    console.error('❌ Error:', error.message);
    console.error('❌ Stack:', error.stack);
  }
  
  process.exit(0);
}

testCustomSlippage();