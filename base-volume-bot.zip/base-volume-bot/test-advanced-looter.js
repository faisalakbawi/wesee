#!/usr/bin/env node

/**
 * TEST ADVANCED LOOTER SYSTEM
 * Test the advanced Looter system with no/low liquidity tokens
 */

require('dotenv').config();
const AdvancedLooterSystem = require('./chains/base/advanced-looter-system');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const { ethers } = require('ethers');

async function testAdvancedLooter() {
  try {
    console.log('🔥 ========== TESTING ADVANCED LOOTER SYSTEM ==========');
    
    // Setup
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const advancedLooter = new AdvancedLooterSystem(provider);
    
    // Test tokens
    const testTokens = [
      {
        name: 'TONY Token (No Liquidity)',
        address: '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D',
        amount: 0.001
      },
      {
        name: 'USDC (High Liquidity - Control)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      }
    ];
    
    // Get wallet
    const userId = 6537510183;
    const chainWallets = await walletManager.getChainWallets(userId, 'base');
    const wallet = chainWallets['W1'];
    
    if (!wallet) {
      throw new Error('W1 wallet not found');
    }
    
    console.log(`👤 Using wallet: ${wallet.address}`);
    
    for (const token of testTokens) {
      console.log(`\n🎯 ========== TESTING: ${token.name} ==========`);
      console.log(`📍 Address: ${token.address}`);
      
      // 1. Check if token is buyable
      console.log('\n1️⃣ BUYABLE CHECK:');
      const buyableCheck = await advancedLooter.isTokenBuyable(token.address);
      console.log('🔍 Buyable result:', buyableCheck);
      
      if (buyableCheck.buyable) {
        console.log(`✅ Token is buyable on ${buyableCheck.dex}`);
        console.log(`📍 Pair address: ${buyableCheck.pair}`);
        
        // 2. Execute advanced buy (SIMULATION ONLY)
        console.log('\n2️⃣ ADVANCED BUY SIMULATION:');
        console.log('⚠️  This would execute a real transaction:');
        console.log(`   - Token: ${token.address}`);
        console.log(`   - Amount: ${token.amount} ETH`);
        console.log(`   - Wallet: ${wallet.address}`);
        console.log(`   - Method: Advanced Looter with 5 techniques`);
        
        // Uncomment to execute real transaction:
        // const result = await advancedLooter.executeAdvancedLooterBuy(
        //   wallet.privateKey,
        //   token.address,
        //   token.amount
        // );
        // console.log('🚀 Advanced buy result:', result);
        
      } else {
        console.log(`❌ Token not buyable: ${buyableCheck.reason}`);
      }
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ ADVANCED LOOTER TEST COMPLETE');
    console.log('💡 Uncomment the execution code to test real transactions');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testAdvancedLooter();