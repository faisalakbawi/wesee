# 🗄️ PostgreSQL Database Setup Guide

This guide will help you set up PostgreSQL database for the Looter.ai Clone bot on your Mac Mini.

## 📋 Prerequisites

1. **Mac Mini** with macOS
2. **Node.js** (v16 or higher)
3. **PostgreSQL** (v12 or higher)

## 🚀 Step 1: Install PostgreSQL

### Option A: Using Homebrew (Recommended)
```bash
# Install Homebrew if you don't have it
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install PostgreSQL
brew install postgresql@15

# Start PostgreSQL service
brew services start postgresql@15

# Create a database user (optional, you can use default 'postgres' user)
createuser -s postgres
```

### Option B: Using PostgreSQL.app
1. Download PostgreSQL.app from https://postgresapp.com/
2. Install and run the app
3. Click "Initialize" to create a new server

### Option C: Using Official Installer
1. Download from https://www.postgresql.org/download/macosx/
2. Follow the installation wizard
3. Remember the password you set for the postgres user

## 🔧 Step 2: Configure PostgreSQL

### Set up database user and password
```bash
# Connect to PostgreSQL
psql postgres

# Create a new user (optional)
CREATE USER looter_user WITH PASSWORD 'your_secure_password';

# Grant privileges
ALTER USER looter_user CREATEDB;

# Exit psql
\q
```

## 📦 Step 3: Install Node.js Dependencies

```bash
# Navigate to your bot directory
cd /Users/faisal/Desktop/base-volume-bot

# Install PostgreSQL driver
npm install pg

# Install additional dependencies if needed
npm install dotenv crypto
```

## ⚙️ Step 4: Configure Environment Variables

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Edit the `.env` file with your database credentials:
```bash
nano .env
```

3. Update the database section:
```env
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=looter_ai_clone
DB_USER=postgres
DB_PASSWORD=your_actual_password_here

# Encryption Key (IMPORTANT: Generate a secure 32-character key)
ENCRYPTION_KEY=your-32-character-encryption-key-here
```

## 🏗️ Step 5: Set Up the Database

### Automatic Setup (Recommended)
```bash
# Run the database setup script
node database/setup.js
```

This will:
- Create the `looter_ai_clone` database
- Create all required tables
- Insert default chain data
- Run a test to verify everything works

### Manual Setup (Alternative)
```bash
# Create database manually
createdb looter_ai_clone

# Run the schema
psql looter_ai_clone < database/schema.sql
```

## 🧪 Step 6: Test the Database

```bash
# Test database connection and operations
node database/setup.js
```

You should see output like:
```
🔌 Connected to PostgreSQL server
🗄️ Connected to looter_ai_clone database
📋 Running database schema...
✅ Database schema applied successfully
🧪 Testing database operations...
✅ Found 9 chains
✅ Test user created
✅ Test wallet created
✅ Activity logging works
✅ Test data cleaned up
🎉 Database setup and test completed!
```

## 🔄 Step 7: Migrate Existing Data (Optional)

If you have existing wallet data in files, you can migrate it:

```bash
# The migration will happen automatically when you start the bot
# Or you can run it manually:
node -e "
const WalletDBManager = require('./database/wallet-db-manager');
const WalletManager = require('./utils/wallet-manager');

async function migrate() {
  const dbManager = new WalletDBManager();
  const oldManager = new WalletManager();
  await dbManager.migrateFromFileStorage(oldManager);
}

migrate().catch(console.error);
"
```

## 🚀 Step 8: Update Bot to Use Database

The bot will automatically use the database when you restart it:

```bash
# Stop the current bot
pkill -f "node main-bot.js"

# Start with database support
node main-bot.js
```

## 📊 Database Structure

The database includes these main tables:

### 👤 Users
- User information and authentication
- Activity tracking
- Settings and preferences

### 💼 Wallets
- Encrypted private keys and seed phrases
- Wallet organization by chain and slot
- Balance tracking and history

### 📈 Trades
- Complete trading history
- Profit/loss calculations
- Transaction details and status

### 💸 Transfers
- Native token transfer records
- Gas fee tracking
- Transfer status and confirmations

### 📝 Activity Logs
- Comprehensive audit trail
- All user actions logged
- Easy debugging and analytics

## 🔒 Security Features

1. **Encryption**: All private keys and seed phrases are encrypted
2. **Audit Trail**: Every action is logged with timestamps
3. **User Isolation**: Each user's data is completely separate
4. **Secure Storage**: No sensitive data in plain text

## 🛠️ Maintenance Commands

### View Database Status
```bash
# Connect to database
psql looter_ai_clone

# Check table sizes
\dt+

# View recent activity
SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 10;

# Check user count
SELECT COUNT(*) FROM users;

# Exit
\q
```

### Backup Database
```bash
# Create backup
pg_dump looter_ai_clone > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore from backup
psql looter_ai_clone < backup_file.sql
```

### Reset Database (⚠️ DANGER: This deletes all data)
```bash
# Drop and recreate database
dropdb looter_ai_clone
createdb looter_ai_clone
psql looter_ai_clone < database/schema.sql
```

## 🔍 Troubleshooting

### Connection Issues
```bash
# Check if PostgreSQL is running
brew services list | grep postgresql

# Start PostgreSQL if not running
brew services start postgresql@15

# Check connection
psql postgres -c "SELECT version();"
```

### Permission Issues
```bash
# Fix permissions
sudo chown -R $(whoami) /usr/local/var/postgres
```

### Port Conflicts
```bash
# Check what's using port 5432
lsof -i :5432

# Use different port in .env if needed
DB_PORT=5433
```

## 📈 Performance Optimization

### For High-Volume Usage
```sql
-- Add additional indexes
CREATE INDEX CONCURRENTLY idx_trades_user_created ON trades(user_id, created_at);
CREATE INDEX CONCURRENTLY idx_activity_logs_user_type ON activity_logs(user_id, activity_type);

-- Analyze tables for better query planning
ANALYZE;
```

### Regular Maintenance
```sql
-- Clean old activity logs (older than 30 days)
DELETE FROM activity_logs WHERE created_at < NOW() - INTERVAL '30 days';

-- Vacuum and analyze
VACUUM ANALYZE;
```

## 🎉 Success!

Your PostgreSQL database is now set up and ready to use! The bot will now:

✅ Store all user data securely in PostgreSQL  
✅ Encrypt sensitive information  
✅ Track all activities and transactions  
✅ Provide detailed analytics and reporting  
✅ Scale to handle many users efficiently  

## 📞 Support

If you encounter any issues:

1. Check the console logs for error messages
2. Verify your `.env` configuration
3. Ensure PostgreSQL is running
4. Test database connection manually

The database provides a robust, scalable foundation for your trading bot! 🚀