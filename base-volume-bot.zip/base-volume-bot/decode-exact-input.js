#!/usr/bin/env node

/**
 * DECODE EXACT INPUT DATA FROM SUCCESSFUL TRANSACTION
 * This will reveal the EXACT technique used by professional Looter bots
 */

const { ethers } = require('ethers');

function decodeExactInput() {
  console.log('🔍 ========== DECODING EXACT LOOTER BOT INPUT ==========');
  
  // EXACT input data from successful transaction
  const inputData = '0xc981cc3c000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000014c4805d0077af076ade500000000000000000000000000000000000000000001713394ae41334412168d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000174876e818000000000000000000000000000000000000000000000000000000000000002b420000000000000000000000000000000000000600271036a947baa2492c72bf9d3307117237e79145a87d000000000000000000000000000000000000000000';
  
  console.log('📝 Function Selector:', inputData.slice(0, 10));
  console.log('📊 ETH Amount Used: 0.06 ETH');
  
  // Decode the ABI-encoded parameters
  const abiCoder = new ethers.utils.AbiCoder();
  
  // Remove function selector (first 4 bytes = 8 hex chars)
  const paramData = '0x' + inputData.slice(10);
  
  try {
    // The function signature appears to be:
    // execBuy(uint256 slippage, bytes path, uint256 amountOutMin, uint256 expectedAmount, uint256 param4, uint256 param5, uint256 param6, uint256 maxGasPrice)
    
    const decoded = abiCoder.decode([
      'uint256', // slippage
      'bytes',   // path
      'uint256', // amountOutMin
      'uint256', // expectedAmount
      'uint256', // param4
      'uint256', // param5
      'uint256', // param6
      'uint256'  // maxGasPrice
    ], paramData);
    
    console.log('\n📋 DECODED PARAMETERS:');
    console.log(`  Slippage: ${decoded[0].toString()} (${decoded[0].toString() / 10}%)`);
    console.log(`  Path: ${decoded[1]}`);
    console.log(`  Amount Out Min: ${decoded[2].toString()}`);
    console.log(`  Expected Amount: ${decoded[3].toString()}`);
    console.log(`  Param 4: ${decoded[4].toString()}`);
    console.log(`  Param 5: ${decoded[5].toString()}`);
    console.log(`  Param 6: ${decoded[6].toString()}`);
    console.log(`  Max Gas Price: ${decoded[7].toString()}`);
    
    // Decode the path
    const path = decoded[1];
    console.log('\n🛤️ PATH ANALYSIS:');
    console.log(`  Path length: ${path.length} characters`);
    console.log(`  Path bytes: ${(path.length - 2) / 2} bytes`);
    
    if (path.length >= 86) { // 43 bytes minimum for Uniswap V3 path
      // Uniswap V3 path format: token0 (20 bytes) + fee (3 bytes) + token1 (20 bytes)
      const pathBytes = path.slice(2); // Remove 0x
      
      const token0 = '0x' + pathBytes.slice(0, 40);
      const feeHex = pathBytes.slice(40, 46);
      const token1 = '0x' + pathBytes.slice(46, 86);
      
      const fee = parseInt(feeHex, 16);
      
      console.log(`  🔄 Decoded Uniswap V3 Path:`);
      console.log(`    Token 0: ${token0}`);
      console.log(`    Fee: ${fee} (${fee / 10000}%)`);
      console.log(`    Token 1: ${token1}`);
      
      // Check if tokens match expected
      const WETH = '0x4200000000000000000000000000000000000006';
      const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
      
      console.log(`  ✅ Token 0 is WETH: ${token0.toLowerCase() === WETH.toLowerCase()}`);
      console.log(`  ✅ Token 1 is TONY: ${token1.toLowerCase() === TONY.toLowerCase()}`);
      console.log(`  ✅ Fee matches known pool: ${fee === 10000}`);
    }
    
    // Calculate expected tokens in human readable format
    const expectedTokens = ethers.utils.formatEther(decoded[3]);
    console.log(`\n🎯 EXPECTED TOKENS: ${expectedTokens} TONY`);
    console.log(`💰 ETH INPUT: 0.06 ETH`);
    console.log(`📊 RATIO: ${(parseFloat(expectedTokens) / 0.06).toFixed(2)} TONY per ETH`);
    
    // The key insight: Professional Looter bots PRE-CALCULATE the exact output!
    console.log('\n🤖 PROFESSIONAL TECHNIQUE REVEALED:');
    console.log('1. They use a CUSTOM CONTRACT (not direct Uniswap router)');
    console.log('2. They PRE-CALCULATE the exact expected output');
    console.log('3. They use specific slippage settings (1% in this case)');
    console.log('4. They encode the Uniswap V3 path manually');
    console.log('5. They set maximum gas price limits');
    
    return {
      slippage: decoded[0].toNumber(),
      path: decoded[1],
      amountOutMin: decoded[2],
      expectedAmount: decoded[3],
      maxGasPrice: decoded[7],
      decodedPath: {
        token0: '0x' + pathBytes.slice(0, 40),
        fee: parseInt(pathBytes.slice(40, 46), 16),
        token1: '0x' + pathBytes.slice(46, 86)
      }
    };
    
  } catch (error) {
    console.error('❌ Decoding failed:', error.message);
    
    // Try alternative decoding
    console.log('\n🔄 Trying alternative parameter structure...');
    
    // Maybe it's a different structure
    try {
      const altDecoded = abiCoder.decode([
        'uint256', // param1
        'uint256', // param2 (offset)
        'uint256', // param3
        'uint256', // param4
        'uint256', // param5
        'uint256', // param6
        'uint256', // param7
        'uint256', // param8
        'uint256', // path length
        'bytes'    // path data
      ], paramData);
      
      console.log('📋 ALTERNATIVE DECODING:');
      altDecoded.forEach((param, index) => {
        console.log(`  Param ${index}: ${param.toString()}`);
      });
      
    } catch (altError) {
      console.error('❌ Alternative decoding also failed:', altError.message);
    }
  }
}

// Run decoder
const result = decodeExactInput();
console.log('\n✅ DECODING COMPLETE');

module.exports = { decodeExactInput };