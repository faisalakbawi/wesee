/**
 * TEST REAL USER BASE WALLET
 * Test with the actual user who imported the funded wallet
 */

require('dotenv').config();
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const BuyTokenUI = require('./callbacks/buy-token-ui');
const TokenAnalyzer = require('./trading/token-analyzer');

async function testRealUserBaseWallet() {
  console.log('🎯 ========== TEST REAL USER BASE WALLET ==========');

  try {
    // Initialize components
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const tokenAnalyzer = new TokenAnalyzer();
    
    // Mock bot for testing
    const mockBot = { 
      editMessageText: () => {}, 
      sendMessage: () => {},
      answerCallbackQuery: () => {}
    };
    const buyTokenUI = new BuyTokenUI(mockBot, walletManager, tokenAnalyzer);
    
    // Use the REAL user ID who imported the funded wallet
    const userId = 6537510183;  // The actual user with the imported wallet
    const chain = 'base';
    const contractAddress = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'; // USDC on Base
    const expectedWallet = '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'; // The imported wallet
    
    console.log(`🎯 Testing with REAL user: ${userId}`);
    console.log(`🔵 Chain: ${chain}`);
    console.log(`💰 Expected funded wallet: ${expectedWallet}`);
    console.log(`🪙 Token: USDC on Base`);
    
    // Step 1: Get wallets for the real user
    console.log(`\n💼 STEP 1: Getting wallets for real user...`);
    const chainWallets = await walletManager.getChainWallets(userId, chain);
    
    if (!chainWallets || Object.keys(chainWallets).length === 0) {
      console.log(`❌ No wallets found for user ${userId} on Base chain`);
      console.log(`💡 This is unexpected since we found the wallet in database`);
      return;
    }
    
    console.log(`✅ Found ${Object.keys(chainWallets).length} wallets for user ${userId}:`);
    
    let fundedWallets = [];
    let targetWalletFound = false;
    
    for (let i = 1; i <= 5; i++) {
      const walletSlot = `W${i}`;
      const wallet = chainWallets[walletSlot];
      
      if (wallet) {
        console.log(`\n🔍 Checking ${walletSlot}: ${wallet.address}`);
        
        // Check if this is our target wallet
        const isTargetWallet = wallet.address.toLowerCase() === expectedWallet.toLowerCase();
        if (isTargetWallet) {
          targetWalletFound = true;
          console.log(`🎯 THIS IS THE IMPORTED WALLET!`);
        }
        
        // Get balance
        const balance = await walletManager.getWalletBalance(wallet.address, chain);
        const balanceNum = parseFloat(balance) || 0;
        
        const importedStatus = wallet.isImported ? '📥 IMPORTED' : '🔧 GENERATED';
        const balanceStatus = balanceNum > 0 ? '💰 FUNDED' : '🔴 EMPTY';
        
        console.log(`   Address: ${wallet.address}`);
        console.log(`   Balance: ${balance} ETH`);
        console.log(`   Type: ${importedStatus}`);
        console.log(`   Status: ${balanceStatus}`);
        
        if (balanceNum > 0) {
          fundedWallets.push({ slot: walletSlot, wallet, balance: balanceNum });
          console.log(`   🎉 WALLET HAS FUNDS: ${balance} ETH`);
        }
      } else {
        console.log(`\n${walletSlot}: EMPTY SLOT`);
      }
    }
    
    console.log(`\n📊 Real User Wallet Summary:`);
    console.log(`   👤 User ID: ${userId}`);
    console.log(`   💼 Total wallets: ${Object.keys(chainWallets).length}`);
    console.log(`   💰 Funded wallets: ${fundedWallets.length}`);
    console.log(`   🎯 Target wallet found: ${targetWalletFound ? 'YES' : 'NO'}`);
    
    if (!targetWalletFound) {
      console.log(`\n⚠️ WARNING: Expected wallet ${expectedWallet} not found in results`);
      console.log(`💡 This might be due to decryption issues we saw earlier`);
      console.log(`💡 The wallet exists in database but can't be decrypted properly`);
    }
    
    // Step 2: Test token analysis
    console.log(`\n🔍 STEP 2: Testing token analysis...`);
    const analysisResult = await tokenAnalyzer.analyzeToken(contractAddress);
    
    if (!analysisResult.success) {
      console.log(`❌ Token analysis failed: ${analysisResult.error}`);
      return;
    }
    
    const tokenData = analysisResult.data;
    console.log(`✅ Token analyzed:`);
    console.log(`   Name: ${tokenData.name || 'Unknown'}`);
    console.log(`   Symbol: ${tokenData.symbol || 'Unknown'}`);
    console.log(`   Chain: ${tokenData.chain || 'Unknown'}`);
    console.log(`   Price: $${tokenData.price || 'Unknown'}`);
    
    // Step 3: Test UI generation with real user
    console.log(`\n⌨️ STEP 3: Testing UI generation with real user...`);
    
    const sessionId = buyTokenUI.createTokenSession(userId, tokenData);
    console.log(`✅ Created session for real user: ${sessionId}`);
    
    // Test keyboard generation
    const keyboard = await buyTokenUI.buildKeyboard(userId, sessionId, tokenData, 'ETH');
    console.log(`✅ Keyboard generated for real user`);
    
    console.log(`📊 Wallet buttons for real user:`);
    const walletRow = keyboard.inline_keyboard[0];
    walletRow.forEach((button, index) => {
      const walletNum = index + 1;
      const walletSlot = `W${walletNum}`;
      const wallet = chainWallets[walletSlot];
      
      if (wallet) {
        const fundedWallet = fundedWallets.find(fw => fw.slot === walletSlot);
        const expectedEmoji = fundedWallet ? '💰' : '⚪';
        const isTarget = wallet.address.toLowerCase() === expectedWallet.toLowerCase();
        
        console.log(`   ${button.text} (callback: ${button.callback_data}) ${isTarget ? '🎯 TARGET' : ''}`);
        
        if (fundedWallet) {
          console.log(`     ✅ FUNDED: ${fundedWallet.balance} ETH`);
        } else {
          console.log(`     🔴 EMPTY: 0 ETH`);
        }
        
        if (button.text.includes(expectedEmoji)) {
          console.log(`     ✅ CORRECT: Button shows proper emoji`);
        } else {
          console.log(`     ❌ ERROR: Button should show ${expectedEmoji}`);
        }
      }
    });
    
    // Step 4: Test manual selection with funded wallets
    console.log(`\n👆 STEP 4: Testing manual selection...`);
    
    if (fundedWallets.length > 0) {
      const firstFundedWallet = fundedWallets[0];
      const walletNum = parseInt(firstFundedWallet.slot.replace('W', ''));
      
      console.log(`👤 Selecting funded wallet: ${firstFundedWallet.slot} (${firstFundedWallet.balance} ETH)`);
      
      // Simulate user clicking the funded wallet
      const selectedWallets = buyTokenUI.toggleWallet(userId, sessionId, walletNum);
      console.log(`📊 Selected wallets: ${Array.from(selectedWallets)}`);
      
      // Set a reasonable amount (10% of balance or 0.001 ETH, whichever is smaller)
      const testAmount = Math.min(0.001, firstFundedWallet.balance * 0.1);
      buyTokenUI.setSelectedAmount(userId, sessionId, testAmount);
      console.log(`💰 Selected amount: ${testAmount} ETH`);
      
      // Test validation
      console.log(`\n✅ STEP 5: Testing validation...`);
      const selectedAmount = buyTokenUI.getSelectedAmount(userId, sessionId);
      
      console.log(`📊 Validation test:`);
      console.log(`   User: ${userId}`);
      console.log(`   Wallet: ${firstFundedWallet.slot} (${firstFundedWallet.wallet.address})`);
      console.log(`   Balance: ${firstFundedWallet.balance} ETH`);
      console.log(`   Amount: ${selectedAmount} ETH`);
      
      if (firstFundedWallet.balance >= selectedAmount) {
        console.log(`   ✅ VALIDATION PASSED: Sufficient balance`);
        console.log(`   🎉 TRADING WOULD SUCCEED!`);
        
        console.log(`\n🚀 REAL TRADING SCENARIO:`);
        console.log(`   1. User ${userId} opens buy menu`);
        console.log(`   2. User enters USDC contract address`);
        console.log(`   3. System shows wallet buttons with 💰 for funded wallets`);
        console.log(`   4. User clicks ${firstFundedWallet.slot} (shows as funded)`);
        console.log(`   5. User selects ${selectedAmount} ETH`);
        console.log(`   6. User clicks CONFIRM`);
        console.log(`   7. System validates: ✅ PASS`);
        console.log(`   8. Trade executes on Base chain`);
        console.log(`   9. User successfully buys USDC with ETH`);
        
      } else {
        console.log(`   ❌ VALIDATION FAILED: Insufficient balance`);
      }
      
    } else {
      console.log(`⚠️ No funded wallets available for selection test`);
      console.log(`💡 This might be due to decryption issues`);
    }
    
    // Final summary
    console.log(`\n${'='.repeat(60)}`);
    console.log(`🎯 REAL USER BASE WALLET TEST RESULTS`);
    console.log(`${'='.repeat(60)}`);
    
    console.log(`\n📊 TEST STATUS:`);
    console.log(`   👤 Real user ID: ${userId} ✅`);
    console.log(`   🔵 Base chain: Working ✅`);
    console.log(`   💼 Wallets found: ${Object.keys(chainWallets).length} ✅`);
    console.log(`   💰 Funded wallets: ${fundedWallets.length} ${fundedWallets.length > 0 ? '✅' : '⚠️'}`);
    console.log(`   🎯 Target wallet: ${targetWalletFound ? 'Found ✅' : 'Missing ⚠️'}`);
    console.log(`   🪙 Token analysis: Working ✅`);
    console.log(`   ⌨️ UI generation: Working ✅`);
    
    console.log(`\n🎯 KEY FINDINGS:`);
    if (fundedWallets.length > 0) {
      console.log(`   ✅ User has ${fundedWallets.length} funded wallet(s) on Base`);
      console.log(`   ✅ Wallet selection UI works correctly`);
      console.log(`   ✅ Manual selection works perfectly`);
      console.log(`   ✅ Validation works as expected`);
      console.log(`   ✅ Ready for real trading on Base chain`);
    } else {
      console.log(`   ⚠️ Funded wallets not showing up in UI`);
      console.log(`   ⚠️ Likely due to decryption issues`);
      console.log(`   💡 Database has the wallet but can't decrypt private key`);
      console.log(`   💡 This affects balance display and trading functionality`);
    }
    
    if (!targetWalletFound) {
      console.log(`   ⚠️ Imported wallet ${expectedWallet} not accessible`);
      console.log(`   💡 Decryption errors prevent proper wallet loading`);
      console.log(`   💡 Need to fix encryption/decryption system`);
    }

  } catch (error) {
    console.error('❌ REAL USER TEST ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

testRealUserBaseWallet().then(() => {
  console.log('\n🎉 Real user Base wallet test completed!');
  process.exit(0);
}).catch(error => {
  console.error('💥 Real user test failed:', error);
  process.exit(1);
});