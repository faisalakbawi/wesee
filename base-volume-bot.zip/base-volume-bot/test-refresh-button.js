/**
 * TEST REFRESH INFO BUTTON
 * Test the "📊 Refresh Info" button functionality
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT: ${text.substring(0, 80)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED: ${text.substring(0, 80)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED: Message ${messageId}`);
    return true;
  }
}

async function testRefreshButton() {
  console.log('📊 ========== REFRESH INFO BUTTON TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // Test 1: Send token address to create session
    console.log('\n📍 TEST 1: Create Token Session');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find the token display with refresh button
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    let refreshButton = null;
    if (tokenDisplay) {
      const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
      refreshButton = keyboard.flat().find(btn => 
        btn.text.includes('📊 Refresh Info')
      );
      
      if (refreshButton) {
        console.log('✅ FOUND REFRESH BUTTON:', refreshButton.text);
        console.log('✅ Callback data:', refreshButton.callback_data);
      } else {
        console.log('❌ FAIL: Refresh button not found');
        return false;
      }
    } else {
      console.log('❌ FAIL: Token display not found');
      return false;
    }

    // Test 2: Click the refresh button
    console.log('\n📍 TEST 2: Click Refresh Button');
    
    const refreshCallback = {
      id: 'test_refresh_callback',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    };
    
    // Count edits before refresh
    const editsBefore = mockBot.edits.length;
    console.log('📊 Edits before refresh:', editsBefore);
    
    await callbacks.handleBuyRefresh(refreshCallback);
    
    // Count edits after refresh
    const editsAfter = mockBot.edits.length;
    console.log('📊 Edits after refresh:', editsAfter);
    
    if (editsAfter > editsBefore) {
      console.log('✅ PASS: Refresh button triggered message update');
      
      // Check if the latest edit contains token info
      const latestEdit = mockBot.edits[mockBot.edits.length - 1];
      if (latestEdit.text.includes('USD Coin') || latestEdit.text.includes('USDC')) {
        console.log('✅ PASS: Refreshed content contains token information');
        
        // Check if it has the refresh button again
        if (latestEdit.options.reply_markup) {
          const newKeyboard = latestEdit.options.reply_markup.inline_keyboard;
          const newRefreshButton = newKeyboard.flat().find(btn => 
            btn.text.includes('📊 Refresh Info')
          );
          
          if (newRefreshButton) {
            console.log('✅ PASS: Refresh button still present after refresh');
          } else {
            console.log('❌ FAIL: Refresh button missing after refresh');
            return false;
          }
        }
        
      } else {
        console.log('❌ FAIL: Refreshed content does not contain token info');
        return false;
      }
      
    } else {
      console.log('❌ FAIL: Refresh button did not trigger any updates');
      return false;
    }

    // Test 3: Check if refresh actually updates data (simulate time passage)
    console.log('\n📍 TEST 3: Multiple Refresh Clicks');
    
    // Click refresh button again
    await callbacks.handleBuyRefresh({
      id: 'test_refresh_callback_2',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    });
    
    const finalEdits = mockBot.edits.length;
    if (finalEdits > editsAfter) {
      console.log('✅ PASS: Multiple refresh clicks work');
    } else {
      console.log('❌ FAIL: Multiple refresh clicks not working');
      return false;
    }

    console.log('\n📊 ========== TEST RESULTS ==========');
    console.log(`📤 Total messages sent: ${mockBot.messages.length}`);
    console.log(`✏️ Total message edits: ${mockBot.edits.length}`);
    console.log(`✅ Total callback responses: ${mockBot.callbacks.length}`);
    
    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('❌ STACK:', error.stack);
    return false;
  }
}

// Run the test
testRefreshButton().then(success => {
  if (success) {
    console.log('\n🎉 ========== REFRESH BUTTON TEST PASSED! ==========');
    console.log('✅ Refresh button is present in token interface');
    console.log('✅ Refresh button callback is handled correctly');
    console.log('✅ Refresh updates the token information');
    console.log('✅ Refresh button remains functional after refresh');
    console.log('✅ Multiple refresh clicks work properly');
    console.log('🚀 Refresh functionality is working perfectly!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== REFRESH BUTTON TEST FAILED ==========');
    console.log('❌ Some refresh functionality is not working properly');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});