#!/usr/bin/env node

/**
 * TEST EXACT LOOTER BOT CLONE
 * Test the exact replica of professional Looter bots
 */

require('dotenv').config();
const ExactLooterClone = require('./chains/base/exact-looter-clone');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const { ethers } = require('ethers');

async function testExactLooterClone() {
  try {
    console.log('🤖 ========== TESTING EXACT LOOTER BOT CLONE ==========');
    console.log('🎯 Replicating transaction: 0x1a48e98e1293308ef5e5715de033db093a0b64c7c9b162486d08e6d504ffc736');
    
    // Setup
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const exactLooter = new ExactLooterClone(provider);
    
    // Get wallet
    const userId = 6537510183;
    const chainWallets = await walletManager.getChainWallets(userId, 'base');
    const wallet = chainWallets['W1'];
    
    if (!wallet) {
      throw new Error('W1 wallet not found');
    }
    
    console.log(`👤 Using wallet: ${wallet.address}`);
    
    // Check wallet balance
    const provider_wallet = new ethers.Wallet(wallet.privateKey, provider);
    const balance = await provider_wallet.getBalance();
    console.log(`💰 ETH Balance: ${ethers.utils.formatEther(balance)} ETH`);
    
    // Test tokens
    const testTokens = [
      {
        name: 'TONY Token (Same as successful transaction)',
        address: '0x36a947baa2492c72bf9d3307117237e79145a87d', // EXACT same token from successful tx
        amount: 0.06 // Same amount as successful tx
      },
      {
        name: 'USDC (Control test)',
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        amount: 0.001
      }
    ];
    
    for (const token of testTokens) {
      console.log(`\n🎯 ========== TESTING: ${token.name} ==========`);
      console.log(`📍 Address: ${token.address}`);
      console.log(`💰 Amount: ${token.amount} ETH`);
      
      // Check Uniswap V3 liquidity first
      const liquidityCheck = await exactLooter.hasUniswapV3Liquidity(token.address);
      console.log(`💧 Uniswap V3 liquidity:`, liquidityCheck);
      
      if (token.name.includes('USDC') || token.name.includes('TONY')) {
        console.log(`\n🚀 EXECUTING EXACT LOOTER CLONE...`);
        console.log(`⚠️  This will execute a REAL transaction!`);
        console.log(`🤖 Using EXACT same method as professional Looter bots`);
        
        // Execute the exact looter clone
        const result = await exactLooter.execBuy(
          wallet.privateKey,
          token.address,
          token.amount
        );
        
        console.log(`\n🎉 EXACT LOOTER CLONE RESULT:`, result);
        
        if (result.success) {
          console.log(`✅ SUCCESS!`);
          console.log(`📝 Transaction: ${result.txHash}`);
          console.log(`⛽ Gas used: ${result.gasUsed}`);
          console.log(`🪙 Tokens received: ${result.tokensReceived}`);
          console.log(`🔧 Method: ${result.method}`);
          console.log(`📊 Token info:`, result.tokenInfo);
        } else {
          console.log(`❌ FAILED: ${result.error}`);
          console.log(`🔧 Method: ${result.method}`);
        }
        
        // Only test one token to save gas
        break;
      }
      
      console.log('\n' + '='.repeat(60));
    }
    
    console.log('\n✅ EXACT LOOTER CLONE TEST COMPLETE');
    console.log('🤖 System replicates professional Looter bot behavior exactly');
    console.log('🎯 Uses same Uniswap V3 router and path encoding');
    console.log('📝 Shows "execBuy()" function name in transactions');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

// Run test
testExactLooterClone();