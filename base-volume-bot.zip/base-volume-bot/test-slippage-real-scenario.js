/**
 * Test Real Slippage Scenario
 * Simulates the exact user flow that causes the error
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');
const Auth = require('./auth/auth');

// Mock bot that captures errors
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 Edit message called successfully');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text, options) => {
    console.log('📤 Send message called successfully');
    return { message_id: 124 };
  },
  answerCallbackQuery: async (callbackId, options) => {
    if (options && options.text && options.text.includes('❌')) {
      console.error('🚨 ERROR CALLBACK DETECTED:', options.text);
      throw new Error(`Callback error: ${options.text}`);
    }
    console.log('✅ Callback answered successfully');
  }
};

async function testRealSlippageScenario() {
  console.log('🧪 ========== TESTING REAL SLIPPAGE SCENARIO ==========');
  
  try {
    // Initialize all components exactly like the real bot
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const userStates = new UserStates();
    const auth = new Auth();
    
    await walletManager.initialize();
    
    // Create mock trading object
    const mockTrading = {
      chainManager: chainManager
    };
    
    const callbacks = new Callbacks(mockBot, auth, walletManager, mockTrading, userStates);
    
    // Use the SAME BuyTokenUI instance that the callbacks will use
    const buyTokenUI = callbacks.buyTokenUI;
    
    const testChatId = '6537510183';
    
    console.log('✅ All components initialized');
    
    // ========== SIMULATE REAL USER FLOW ==========
    console.log('\n🔥 ========== SIMULATING REAL USER FLOW ==========');
    
    // Step 1: User clicks "🔥 Buy Token"
    console.log('\n1️⃣ User clicks: 🔥 Buy Token');
    await buyTokenUI.handleBuyTokenMenu(testChatId, 123);
    
    // Step 2: User sends contract address
    console.log('\n2️⃣ User sends contract address');
    const contractMsg = {
      chat: { id: testChatId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'
    };
    await buyTokenUI.handleContractAddress(contractMsg);
    
    // Get the session that was created
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    if (!sessionId) {
      throw new Error('No session created!');
    }
    
    console.log(`✅ Token session created: ${sessionId}`);
    
    // Step 3: User clicks slippage button
    console.log('\n3️⃣ User clicks: 📊 Slippage button');
    const slippageCallback = {
      id: 'callback_123',
      data: `slippage_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: 123 }
    };
    
    // This is where the error might occur - test through the full callback handler
    console.log('🔍 Testing through full callback handler...');
    await callbacks.handle(slippageCallback);
    
    console.log('✅ Slippage callback handled successfully!');
    
    // Step 4: User clicks a slippage value
    console.log('\n4️⃣ User clicks: 💡 Use Recommended (1%)');
    const slippageSetCallback = {
      id: 'callback_124',
      data: `slippage_set_${sessionId}_1.0`,
      from: { id: testChatId },
      message: { message_id: 123 }
    };
    
    await callbacks.handle(slippageSetCallback);
    console.log('✅ Slippage set callback handled successfully!');
    
    // Step 5: Test edge cases that might cause errors
    console.log('\n5️⃣ Testing edge cases...');
    
    // Test with invalid session
    const invalidCallback = {
      id: 'callback_125',
      data: `slippage_invalid123`,
      from: { id: testChatId },
      message: { message_id: 123 }
    };
    
    try {
      await callbacks.handle(invalidCallback);
      console.log('⚠️ Invalid session handled gracefully');
    } catch (error) {
      if (error.message.includes('❌')) {
        console.log('✅ Invalid session error properly caught and handled');
      } else {
        throw error;
      }
    }
    
    // Test with malformed callback data
    const malformedCallback = {
      id: 'callback_126',
      data: `slippage_`,
      from: { id: testChatId },
      message: { message_id: 123 }
    };
    
    try {
      await callbacks.handle(malformedCallback);
      console.log('⚠️ Malformed callback handled gracefully');
    } catch (error) {
      if (error.message.includes('❌')) {
        console.log('✅ Malformed callback error properly caught and handled');
      } else {
        throw error;
      }
    }
    
    console.log('\n🎉 ========== ALL TESTS PASSED! ==========');
    console.log('✅ Buy Token menu works');
    console.log('✅ Contract address analysis works');
    console.log('✅ Slippage menu display works');
    console.log('✅ Slippage value setting works');
    console.log('✅ Error handling works');
    
    console.log('\n🔍 ========== CONCLUSION ==========');
    console.log('🟢 The slippage functionality is working correctly!');
    console.log('🟢 No "❌ An error occurred" should appear in normal flow');
    console.log('🟢 If you\'re still seeing errors, please share:');
    console.log('   1. The exact steps you\'re taking');
    console.log('   2. The exact contract address you\'re using');
    console.log('   3. When exactly the error appears');
    
  } catch (error) {
    console.error('\n❌ ========== ERROR FOUND! ==========');
    console.error('❌ Error message:', error.message);
    console.error('❌ Error stack:', error.stack);
    
    // Check if this is the error the user is seeing
    if (error.message.includes('❌ An error occurred')) {
      console.error('🎯 THIS IS THE ERROR THE USER IS SEEING!');
      console.error('🔍 Root cause identified in the callback handling');
    }
  }
  
  process.exit(0);
}

testRealSlippageScenario();