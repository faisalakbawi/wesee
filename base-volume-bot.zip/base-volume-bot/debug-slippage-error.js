/**
 * DEBUG SLIPPAGE ERROR - ENHANCED
 * Captures the exact error when showing slippage menu with detailed logging
 */

const BuyTokenUI = require('./callbacks/buy-token-ui');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');

// Enhanced mock bot that captures all details
const mockBot = {
  editMessageText: async (text, options) => {
    console.log('📝 ========== EDIT MESSAGE CALLED ==========');
    console.log('📝 Text length:', text.length);
    console.log('📝 Text preview:', text.substring(0, 200));
    console.log('📝 Options:', JSON.stringify(options, null, 2));
    console.log('📝 ==========================================');
    return { message_id: 123 };
  },
  sendMessage: async (chatId, text, options) => {
    console.log('📤 ========== SEND MESSAGE CALLED ==========');
    console.log('📤 Chat ID:', chatId);
    console.log('📤 Text:', text.substring(0, 200));
    console.log('📤 Options:', JSON.stringify(options, null, 2));
    console.log('📤 ==========================================');
    return { message_id: 124 };
  },
  answerCallbackQuery: async (callbackId, options) => {
    console.log('✅ ========== CALLBACK ANSWERED ==========');
    console.log('✅ Callback ID:', callbackId);
    console.log('✅ Options:', options);
    console.log('✅ =====================================');
  }
};

async function debugSlippageError() {
  console.log('🔍 ========== DEBUGGING SLIPPAGE ERROR ==========');
  
  try {
    // Initialize components
    console.log('🔧 Initializing components...');
    const walletManager = new WalletDBManager();
    const chainManager = new ChainManager();
    const buyTokenUI = new BuyTokenUI(mockBot, walletManager, chainManager);
    
    await walletManager.initialize();
    console.log('✅ Components initialized');
    
    const testChatId = '6537510183';
    const testMessageId = 123;
    
    // ========== STEP 1: CREATE TOKEN SESSION ==========
    console.log('\n🔥 ========== STEP 1: CREATE TOKEN SESSION ==========');
    
    const testAddress = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'; // USDC on Base
    const mockMsg = {
      chat: { id: testChatId },
      text: testAddress
    };
    
    console.log(`1️⃣ Creating token session with: ${testAddress}`);
    await buyTokenUI.handleContractAddress(mockMsg);
    
    // Get session ID
    const sessions = Array.from(buyTokenUI.tokenSessions.keys());
    console.log('📊 Available sessions:', sessions);
    
    const sessionKey = sessions.find(key => key.startsWith(testChatId));
    const sessionId = sessionKey ? sessionKey.split('_')[1] : null;
    
    console.log(`📝 Session key: ${sessionKey}`);
    console.log(`📝 Session ID: ${sessionId}`);
    
    if (!sessionId) {
      console.error('❌ No session ID found! Cannot test slippage menu.');
      return;
    }
    
    // Check session data
    const sessionData = buyTokenUI.getTokenSession(testChatId, sessionId);
    console.log('📊 Session data:', JSON.stringify(sessionData, null, 2));
    
    // ========== STEP 2: TEST SLIPPAGE MENU ==========
    console.log('\n💧 ========== STEP 2: TEST SLIPPAGE MENU ==========');
    
    const slippageQuery = {
      data: `slippage_${sessionId}`,
      from: { id: testChatId },
      message: { message_id: testMessageId }
    };
    
    console.log(`2️⃣ Testing slippage menu with query:`, slippageQuery);
    
    try {
      console.log('🚀 Calling handleSlippageMenu...');
      await buyTokenUI.handleSlippageMenu(slippageQuery);
      console.log('✅ Slippage menu handled successfully!');
      
    } catch (slippageError) {
      console.error('\n❌ ========== SLIPPAGE ERROR CAUGHT! ==========');
      console.error('❌ Error message:', slippageError.message);
      console.error('❌ Error name:', slippageError.name);
      console.error('❌ Error stack:');
      console.error(slippageError.stack);
      console.error('❌ ==========================================');
      
      // Additional debugging
      console.log('\n🔍 ========== DEBUGGING INFO ==========');
      console.log('🔍 Session ID used:', sessionId);
      console.log('🔍 Chat ID used:', testChatId);
      console.log('🔍 Session exists?', buyTokenUI.tokenSessions.has(`${testChatId}_${sessionId}`));
      console.log('🔍 Session data type:', typeof sessionData);
      console.log('🔍 Session data keys:', sessionData ? Object.keys(sessionData) : 'null');
      
      // Check specific properties that might be causing issues
      if (sessionData) {
        console.log('🔍 Token name:', sessionData.name);
        console.log('🔍 Token symbol:', sessionData.symbol);
        console.log('🔍 Token address:', sessionData.address);
        console.log('🔍 Token chain:', sessionData.chain);
        console.log('🔍 Token price:', sessionData.price);
        console.log('🔍 Token tax:', sessionData.tax);
        console.log('🔍 Token liquidity:', sessionData.liquidity);
        console.log('🔍 Token marketCap:', sessionData.marketCap);
      }
      
      // Check if it's a specific method call that's failing
      try {
        console.log('🔍 Testing getRecommendedSlippage...');
        const recommended = buyTokenUI.getRecommendedSlippage(sessionData);
        console.log('🔍 Recommended slippage:', recommended);
      } catch (recError) {
        console.error('❌ getRecommendedSlippage failed:', recError.message);
      }
      
      try {
        console.log('🔍 Testing getTokenSlippage...');
        const currentSlippage = buyTokenUI.getTokenSlippage(testChatId, sessionId);
        console.log('🔍 Current slippage:', currentSlippage);
      } catch (getError) {
        console.error('❌ getTokenSlippage failed:', getError.message);
      }
    }
    
  } catch (error) {
    console.error('\n❌ ========== MAIN ERROR ==========');
    console.error('❌ Error message:', error.message);
    console.error('❌ Error stack:', error.stack);
    console.error('❌ ==============================');
  }
  
  process.exit(0);
}

debugSlippageError();