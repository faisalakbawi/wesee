/**
 * SLIPPAGE TEST MONITOR
 * Run this while testing to see detailed logs of slippage operations
 */

const fs = require('fs');
const { spawn } = require('child_process');

console.log('🔍 ========== SLIPPAGE TEST MONITOR ==========');
console.log('📊 Monitoring bot.log for slippage-related activities...');
console.log('🎯 Look for these key indicators:');
console.log('   ✅ Session creation/retrieval');
console.log('   ✅ Slippage menu display');
console.log('   ✅ Slippage value changes');
console.log('   ❌ Any error messages');
console.log('📝 Press Ctrl+C to stop monitoring');
console.log('==========================================\n');

// Monitor the bot log file
const tail = spawn('tail', ['-f', '/Users/faisal/Desktop/base-volume-bot/bot.log']);

tail.stdout.on('data', (data) => {
  const lines = data.toString().split('\n');
  
  lines.forEach(line => {
    if (line.trim()) {
      // Highlight slippage-related logs
      if (line.includes('slippage') || line.includes('Slippage') || line.includes('SLIPPAGE')) {
        console.log(`🎯 ${line}`);
      }
      // Highlight session-related logs
      else if (line.includes('session') || line.includes('Session') || line.includes('SESSION')) {
        console.log(`📝 ${line}`);
      }
      // Highlight callback logs
      else if (line.includes('CALLBACK') || line.includes('callback')) {
        console.log(`🔘 ${line}`);
      }
      // Highlight errors
      else if (line.includes('❌') || line.includes('ERROR') || line.includes('error')) {
        console.log(`❌ ${line}`);
      }
      // Highlight success messages
      else if (line.includes('✅') || line.includes('SUCCESS')) {
        console.log(`✅ ${line}`);
      }
      // Show other important logs
      else if (line.includes('🔧') || line.includes('🚀') || line.includes('📊')) {
        console.log(`📋 ${line}`);
      }
    }
  });
});

tail.stderr.on('data', (data) => {
  console.error(`❌ Monitor error: ${data}`);
});

tail.on('close', (code) => {
  console.log(`\n🔍 Monitor stopped (exit code: ${code})`);
});

// Handle Ctrl+C
process.on('SIGINT', () => {
  console.log('\n🛑 Stopping monitor...');
  tail.kill();
  process.exit(0);
});