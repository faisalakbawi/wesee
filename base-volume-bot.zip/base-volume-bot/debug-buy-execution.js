#!/usr/bin/env node

/**
 * DEBUG BUY EXECUTION
 * Test the actual buy execution to see where it's failing
 */

require('dotenv').config();
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');

async function debugBuyExecution() {
  try {
    console.log('🔍 ========== DEBUGGING BUY EXECUTION ==========');
    
    // Initialize managers
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const userId = 6537510183;
    const chain = 'base';
    const tokenAddress = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'; // USDC (has liquidity)
    const amount = 0.001;
    
    console.log(`🎯 Testing buy execution:`);
    console.log(`   User: ${userId}`);
    console.log(`   Chain: ${chain}`);
    console.log(`   Token: ${tokenAddress}`);
    console.log(`   Amount: ${amount} ETH`);
    
    // Get wallet
    const chainWallets = await walletManager.getChainWallets(userId, chain);
    const walletSlot = 'W1';
    const wallet = chainWallets[walletSlot];
    
    if (!wallet) {
      throw new Error(`Wallet ${walletSlot} not found`);
    }
    
    console.log(`💼 Using wallet: ${wallet.address}`);
    console.log(`🔑 Has private key: ${!!wallet.privateKey}`);
    
    // Test direct chain manager call
    console.log('\n1️⃣ TESTING DIRECT CHAIN MANAGER CALL:');
    try {
      const result = await chainManager.executeBuy(
        chain,
        wallet.privateKey,
        tokenAddress,
        amount,
        1.0 // 1% slippage
      );
      
      console.log('✅ Direct call result:', result);
      
    } catch (error) {
      console.error('❌ Direct call failed:', error.message);
      console.error('❌ Error stack:', error.stack);
    }
    
    // Test base trading directly
    console.log('\n2️⃣ TESTING BASE TRADING DIRECTLY:');
    try {
      const baseTrading = chainManager.getChain('base');
      const result = await baseTrading.executeBuy(
        wallet.privateKey,
        tokenAddress,
        amount,
        1.0
      );
      
      console.log('✅ Base trading result:', result);
      
    } catch (error) {
      console.error('❌ Base trading failed:', error.message);
      console.error('❌ Error stack:', error.stack);
    }
    
    console.log('\n🔍 DEBUG COMPLETE');
    
  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  } finally {
    process.exit(0);
  }
}

// Run debug
debugBuyExecution();