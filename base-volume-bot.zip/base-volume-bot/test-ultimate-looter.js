#!/usr/bin/env node

/**
 * TEST ULTIMATE LOOTER SYSTEM
 * Test the most aggressive Looter system
 */

require('dotenv').config();
const UltimateLooterSystem = require('./chains/base/ultimate-looter-system');
const WalletDBManager = require('./database/wallet-db-manager');
const ChainManager = require('./chains/chain-manager');
const { ethers } = require('ethers');

async function testUltimateLooter() {
  try {
    console.log('🔥 ========== TESTING ULTIMATE LOOTER SYSTEM ==========');
    
    // Setup
    const provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    await walletManager.initialize();
    
    const ultimateLooter = new UltimateLooterSystem(provider);
    
    // Get wallet
    const userId = 6537510183;
    const chainWallets = await walletManager.getChainWallets(userId, 'base');
    const wallet = chainWallets['W1'];
    
    if (!wallet) {
      throw new Error('W1 wallet not found');
    }
    
    console.log(`👤 Using wallet: ${wallet.address}`);
    
    // Test TONY token
    const tokenAddress = '0x0983e421e35a880090fa1fD99A7AeEFC62A3254D';
    const amountETH = 0.001;
    
    console.log(`\n🎯 ========== ULTIMATE TEST: TONY TOKEN ==========`);
    console.log(`📍 Address: ${tokenAddress}`);
    console.log(`💰 Amount: ${amountETH} ETH`);
    
    // Get token info first
    const tokenInfo = await ultimateLooter.getTokenInfo(tokenAddress);
    console.log(`📋 Token info:`, tokenInfo);
    
    console.log(`\n🚀 EXECUTING ULTIMATE BUY...`);
    console.log(`⚠️  This will execute REAL transactions!`);
    console.log(`💪 Using 6 ultimate techniques:`);
    console.log(`   1. Scan All DEXs`);
    console.log(`   2. Direct Transfer Attempts`);
    console.log(`   3. Create Liquidity and Buy`);
    console.log(`   4. Bridge Detection`);
    console.log(`   5. Alternative Token Sources`);
    console.log(`   6. Brute Force All Routers`);
    
    // Execute the ultimate buy
    const result = await ultimateLooter.executeUltimateBuy(
      wallet.privateKey,
      tokenAddress,
      amountETH
    );
    
    console.log(`\n🎉 ULTIMATE BUY RESULT:`, result);
    
    if (result.success) {
      console.log(`✅ SUCCESS! Tokens received: ${result.tokensReceived}`);
      console.log(`📝 Transaction: ${result.txHash}`);
      console.log(`⛽ Gas used: ${result.gasUsed}`);
      console.log(`🔧 Method: ${result.method}`);
    } else {
      console.log(`❌ FAILED: ${result.error}`);
      console.log(`🔧 Method: ${result.method}`);
    }
    
  } catch (error) {
    console.error('❌ Ultimate test failed:', error.message);
  }
}

// Run test
testUltimateLooter();