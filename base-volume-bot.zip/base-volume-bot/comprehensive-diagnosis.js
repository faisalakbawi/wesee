/**
 * 🔍 COMPREHENSIVE BOT DIAGNOSIS
 * Deep analysis to find the root cause of trading failures
 */

const fs = require('fs');
const path = require('path');

class ComprehensiveDiagnosis {
  constructor() {
    this.issues = [];
    this.fixes = [];
  }

  async runFullDiagnosis() {
    console.log('🔍 COMPREHENSIVE BOT DIAGNOSIS');
    console.log('==============================');
    console.log('Analyzing entire bot system to find root cause...\n');

    // 1. Check execution flow
    await this.checkExecutionFlow();
    
    // 2. Check wallet configuration
    await this.checkWalletConfiguration();
    
    // 3. Check chain configuration
    await this.checkChainConfiguration();
    
    // 4. Check trading implementation
    await this.checkTradingImplementation();
    
    // 5. Check callback routing
    await this.checkCallbackRouting();
    
    // 6. Check token analysis
    await this.checkTokenAnalysis();
    
    // 7. Generate comprehensive report
    this.generateComprehensiveReport();
  }

  async checkExecutionFlow() {
    console.log('🔍 1. EXECUTION FLOW ANALYSIS');
    console.log('=============================');
    
    try {
      // Check if trading.js has the smart slippage code
      const tradingContent = fs.readFileSync('./trading/trading.js', 'utf8');
      
      const hasSmartSlippage = tradingContent.includes('CRITICAL FIX: Apply smart slippage');
      console.log(`✅ Smart slippage in trading.js: ${hasSmartSlippage ? 'PRESENT' : 'MISSING'}`);
      
      if (!hasSmartSlippage) {
        this.issues.push('Smart slippage code missing from trading.js');
        this.fixes.push('Add smart slippage calculation to trading.js');
      }
      
      // Check if the code path is being reached
      const hasLogging = tradingContent.includes('Original slippage') && tradingContent.includes('Final slippage');
      console.log(`✅ Execution logging: ${hasLogging ? 'PRESENT' : 'MISSING'}`);
      
      // Check if TokenAnalyzer is being imported correctly
      const hasTokenAnalyzerImport = tradingContent.includes("require('./token-analyzer')");
      console.log(`✅ TokenAnalyzer import: ${hasTokenAnalyzerImport ? 'PRESENT' : 'MISSING'}`);
      
      if (!hasTokenAnalyzerImport) {
        this.issues.push('TokenAnalyzer not imported in trading.js');
        this.fixes.push('Fix TokenAnalyzer import path');
      }
      
    } catch (error) {
      console.error('❌ Execution flow check failed:', error.message);
      this.issues.push(`Execution flow check failed: ${error.message}`);
    }
  }

  async checkWalletConfiguration() {
    console.log('\n🔍 2. WALLET CONFIGURATION ANALYSIS');
    console.log('===================================');
    
    try {
      // Check if W5 wallet exists and has the right address
      const Database = require('./database/database');
      const WalletManager = require('./database/wallet-db-manager');
      
      const database = new Database();
      const walletManager = new WalletManager(database);
      
      // Check user wallets
      const userId = 6537510183; // Your user ID
      const baseWallets = await walletManager.getChainWallets(userId, 'base');
      
      console.log(`✅ Base wallets found: ${Object.keys(baseWallets).length}`);
      
      if (baseWallets.W5) {
        console.log(`✅ W5 wallet exists: ${baseWallets.W5.address}`);
        console.log(`✅ W5 has private key: ${baseWallets.W5.privateKey ? 'YES' : 'NO'}`);
        
        // Check balance
        const { ethers } = require('ethers');
        const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
        const balance = await provider.getBalance(baseWallets.W5.address);
        const balanceETH = ethers.utils.formatEther(balance);
        
        console.log(`✅ W5 balance: ${balanceETH} ETH`);
        
        if (parseFloat(balanceETH) < 0.006) {
          this.issues.push(`W5 balance too low: ${balanceETH} ETH (need 0.006+ ETH)`);
          this.fixes.push('Add more ETH to W5 wallet');
        }
      } else {
        console.log('❌ W5 wallet not found');
        this.issues.push('W5 wallet not found in database');
        this.fixes.push('Import or create W5 wallet');
      }
      
    } catch (error) {
      console.error('❌ Wallet configuration check failed:', error.message);
      this.issues.push(`Wallet check failed: ${error.message}`);
    }
  }

  async checkChainConfiguration() {
    console.log('\n🔍 3. CHAIN CONFIGURATION ANALYSIS');
    console.log('==================================');
    
    try {
      const ChainManager = require('./chains/chain-manager');
      const chainManager = new ChainManager();
      
      // Check if Base chain is configured
      const baseChain = chainManager.getChain('base');
      console.log(`✅ Base chain configured: ${baseChain ? 'YES' : 'NO'}`);
      
      if (baseChain) {
        console.log(`✅ Base chain ID: ${baseChain.chainId}`);
        console.log(`✅ Base RPC URL: ${baseChain.rpcUrl ? 'CONFIGURED' : 'MISSING'}`);
        
        // Check if executeBuy method exists
        const hasExecuteBuy = typeof baseChain.executeBuy === 'function';
        console.log(`✅ Base executeBuy method: ${hasExecuteBuy ? 'PRESENT' : 'MISSING'}`);
        
        if (!hasExecuteBuy) {
          this.issues.push('Base chain missing executeBuy method');
          this.fixes.push('Implement executeBuy in base-trading.js');
        }
      } else {
        this.issues.push('Base chain not configured');
        this.fixes.push('Configure Base chain in chain-manager.js');
      }
      
    } catch (error) {
      console.error('❌ Chain configuration check failed:', error.message);
      this.issues.push(`Chain check failed: ${error.message}`);
    }
  }

  async checkTradingImplementation() {
    console.log('\n🔍 4. TRADING IMPLEMENTATION ANALYSIS');
    console.log('====================================');
    
    try {
      // Check base-trading.js implementation
      const baseTradingPath = './chains/base/base-trading.js';
      if (fs.existsSync(baseTradingPath)) {
        const baseTradingContent = fs.readFileSync(baseTradingPath, 'utf8');
        
        console.log(`✅ Base trading file exists`);
        
        // Check for key methods
        const hasExecuteBuy = baseTradingContent.includes('async executeBuy');
        const hasUniswapV3 = baseTradingContent.includes('UniswapV3') || baseTradingContent.includes('exactInputSingle');
        const hasErrorHandling = baseTradingContent.includes('try') && baseTradingContent.includes('catch');
        
        console.log(`✅ executeBuy method: ${hasExecuteBuy ? 'PRESENT' : 'MISSING'}`);
        console.log(`✅ Uniswap V3 integration: ${hasUniswapV3 ? 'PRESENT' : 'MISSING'}`);
        console.log(`✅ Error handling: ${hasErrorHandling ? 'PRESENT' : 'MISSING'}`);
        
        // Check for the specific error we're seeing
        const hasGasEstimation = baseTradingContent.includes('estimateGas');
        console.log(`✅ Gas estimation: ${hasGasEstimation ? 'PRESENT' : 'MISSING'}`);
        
        if (!hasExecuteBuy) {
          this.issues.push('executeBuy method missing in base-trading.js');
          this.fixes.push('Implement proper executeBuy method');
        }
        
        if (!hasUniswapV3) {
          this.issues.push('Uniswap V3 integration missing');
          this.fixes.push('Add proper Uniswap V3 router integration');
        }
        
      } else {
        console.log('❌ Base trading file missing');
        this.issues.push('base-trading.js file missing');
        this.fixes.push('Create base-trading.js with proper implementation');
      }
      
    } catch (error) {
      console.error('❌ Trading implementation check failed:', error.message);
      this.issues.push(`Trading implementation check failed: ${error.message}`);
    }
  }

  async checkCallbackRouting() {
    console.log('\n🔍 5. CALLBACK ROUTING ANALYSIS');
    console.log('===============================');
    
    try {
      const callbacksContent = fs.readFileSync('./callbacks/callbacks.js', 'utf8');
      
      // Check if buy_multi_confirm is handled
      const hasBuyMultiConfirm = callbacksContent.includes('buy_multi_confirm');
      console.log(`✅ buy_multi_confirm handler: ${hasBuyMultiConfirm ? 'PRESENT' : 'MISSING'}`);
      
      // Check if executeActualTrades is called
      const hasExecuteActualTrades = callbacksContent.includes('executeActualTrades');
      console.log(`✅ executeActualTrades call: ${hasExecuteActualTrades ? 'PRESENT' : 'MISSING'}`);
      
      // Check if trading.executeBuy is called
      const hasTradingExecuteBuy = callbacksContent.includes('this.trading.executeBuy');
      console.log(`✅ trading.executeBuy call: ${hasTradingExecuteBuy ? 'PRESENT' : 'MISSING'}`);
      
      if (!hasBuyMultiConfirm) {
        this.issues.push('buy_multi_confirm handler missing');
        this.fixes.push('Add buy_multi_confirm handler to callbacks.js');
      }
      
    } catch (error) {
      console.error('❌ Callback routing check failed:', error.message);
      this.issues.push(`Callback routing check failed: ${error.message}`);
    }
  }

  async checkTokenAnalysis() {
    console.log('\n🔍 6. TOKEN ANALYSIS SYSTEM');
    console.log('===========================');
    
    try {
      const TokenAnalyzer = require('./trading/token-analyzer');
      const ChainManager = require('./chains/chain-manager');
      
      const chainManager = new ChainManager();
      const tokenAnalyzer = new TokenAnalyzer(chainManager);
      
      // Test with TONY token
      const tonyAddress = '0x36A947Baa2492C72Bf9D3307117237E79145A87d';
      
      console.log(`🔍 Testing token analysis with TONY: ${tonyAddress}`);
      
      // Test token analysis
      const tokenAnalysis = await tokenAnalyzer.analyzeEVMToken(tonyAddress, 'base');
      console.log(`✅ Token analysis: ${tokenAnalysis ? 'SUCCESS' : 'FAILED'}`);
      
      if (tokenAnalysis) {
        console.log(`✅ Market cap: $${tokenAnalysis.marketCap}`);
        console.log(`✅ Liquidity: $${tokenAnalysis.liquidity}`);
        
        // Test liquidity analysis
        const liquidityAnalysis = await tokenAnalyzer.analyzeLiquidityConditions(tokenAnalysis);
        console.log(`✅ Liquidity category: ${liquidityAnalysis.liquidityCategory}`);
        console.log(`✅ Risk level: ${liquidityAnalysis.riskLevel}`);
        
        // Test smart slippage
        const smartSlippage = tokenAnalyzer.getSmartSlippageRecommendation(liquidityAnalysis, 0.001);
        console.log(`✅ Smart slippage: ${smartSlippage}%`);
        
        if (smartSlippage < 30) {
          this.issues.push(`Smart slippage too low: ${smartSlippage}% (should be 30%+ for micro liquidity)`);
          this.fixes.push('Increase smart slippage for micro liquidity tokens');
        }
      } else {
        this.issues.push('Token analysis failed for TONY');
        this.fixes.push('Fix token analysis for Base chain tokens');
      }
      
    } catch (error) {
      console.error('❌ Token analysis check failed:', error.message);
      this.issues.push(`Token analysis failed: ${error.message}`);
    }
  }

  generateComprehensiveReport() {
    console.log('\n🎯 COMPREHENSIVE DIAGNOSIS REPORT');
    console.log('=================================');
    
    console.log(`\n📊 ISSUES FOUND: ${this.issues.length}`);
    if (this.issues.length > 0) {
      this.issues.forEach((issue, index) => {
        console.log(`   ${index + 1}. ❌ ${issue}`);
      });
    } else {
      console.log('   ✅ No issues found');
    }
    
    console.log(`\n🔧 FIXES NEEDED: ${this.fixes.length}`);
    if (this.fixes.length > 0) {
      this.fixes.forEach((fix, index) => {
        console.log(`   ${index + 1}. 🔧 ${fix}`);
      });
    } else {
      console.log('   ✅ No fixes needed');
    }
    
    console.log('\n🎯 ROOT CAUSE ANALYSIS:');
    console.log('======================');
    
    if (this.issues.length === 0) {
      console.log('✅ All systems appear to be working correctly.');
      console.log('🤔 The issue may be with the specific tokens being tested.');
      console.log('💡 Recommendation: Test with a highly liquid token like USDC.');
    } else {
      console.log('🚨 Multiple issues detected in the bot system.');
      console.log('🎯 Primary issues appear to be:');
      
      // Categorize issues
      const criticalIssues = this.issues.filter(issue => 
        issue.includes('missing') || 
        issue.includes('failed') || 
        issue.includes('not found')
      );
      
      const configIssues = this.issues.filter(issue => 
        issue.includes('balance') || 
        issue.includes('slippage') || 
        issue.includes('configuration')
      );
      
      if (criticalIssues.length > 0) {
        console.log('   🚨 CRITICAL: System components missing or broken');
      }
      
      if (configIssues.length > 0) {
        console.log('   ⚠️ CONFIGURATION: Settings need adjustment');
      }
    }
    
    console.log('\n🚀 NEXT STEPS:');
    console.log('==============');
    console.log('1. 🔧 Fix all identified issues');
    console.log('2. 🧪 Test with a liquid token (USDC)');
    console.log('3. 📊 Verify smart slippage is being applied');
    console.log('4. 🎯 Test with the original TONY token');
    console.log('5. 📈 Monitor logs for execution flow');
  }
}

// Run comprehensive diagnosis
async function runDiagnosis() {
  const diagnosis = new ComprehensiveDiagnosis();
  await diagnosis.runFullDiagnosis();
}

// Export for use in other files
module.exports = ComprehensiveDiagnosis;

// Run if called directly
if (require.main === module) {
  runDiagnosis().catch(console.error);
}