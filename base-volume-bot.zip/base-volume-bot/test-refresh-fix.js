/**
 * TEST REFRESH BUTTON FIX
 * Test the refresh button with the chain validation fix
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot for testing
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`📤 SENT MESSAGE`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`✏️ EDITED MESSAGE`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ CALLBACK: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`🗑️ DELETED MESSAGE`);
    return true;
  }
}

async function testRefreshFix() {
  console.log('🔧 ========== REFRESH BUTTON FIX TEST ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // Test 1: Send token address to create session
    console.log('\n📍 TEST 1: Create Token Session');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    
    // Find refresh button
    const tokenDisplay = mockBot.edits.find(edit => 
      edit.options.reply_markup && edit.text.includes('USD Coin')
    );
    
    if (!tokenDisplay) {
      console.log('❌ FAIL: Token display not found');
      return false;
    }

    const keyboard = tokenDisplay.options.reply_markup.inline_keyboard;
    const refreshButton = keyboard.flat().find(btn => 
      btn.text.includes('📊 Refresh Info')
    );
    
    if (!refreshButton) {
      console.log('❌ FAIL: Refresh button not found');
      return false;
    }

    console.log('✅ FOUND REFRESH BUTTON:', refreshButton.text);

    // Test 2: Click the refresh button (this should trigger the fix)
    console.log('\n📍 TEST 2: Click Refresh Button');
    
    const refreshCallback = {
      id: 'test_refresh_callback',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: refreshButton.callback_data
    };
    
    // Count edits before refresh
    const editsBefore = mockBot.edits.length;
    console.log('📊 Edits before refresh:', editsBefore);
    
    await callbacks.handleBuyRefresh(refreshCallback);
    
    // Count edits after refresh
    const editsAfter = mockBot.edits.length;
    console.log('📊 Edits after refresh:', editsAfter);
    
    if (editsAfter > editsBefore) {
      console.log('✅ PASS: Refresh button worked without errors');
      
      // Check the latest edit
      const latestEdit = mockBot.edits[mockBot.edits.length - 1];
      if (latestEdit.text.includes('USD Coin') || latestEdit.text.includes('USDC')) {
        console.log('✅ PASS: Token info displayed correctly');
        return true;
      } else if (latestEdit.text.includes('Refresh Failed')) {
        console.log('❌ FAIL: Refresh still failing');
        console.log('❌ Error details:', latestEdit.text.substring(0, 200));
        return false;
      }
    } else {
      console.log('❌ FAIL: Refresh button did not update content');
      return false;
    }

    return true;

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    return false;
  }
}

// Run the test
testRefreshFix().then(success => {
  if (success) {
    console.log('\n🎉 ========== REFRESH FIX TEST PASSED! ==========');
    console.log('✅ Refresh button working without chain errors');
    console.log('✅ Token data validation implemented');
    console.log('✅ Automatic re-analysis when needed');
    console.log('🚀 Refresh functionality is now robust!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== REFRESH FIX TEST FAILED ==========');
    console.log('❌ Refresh button still has issues');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test failed:', error);
  process.exit(1);
});