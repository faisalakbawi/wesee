#!/usr/bin/env node

/**
 * DECODE PROFESSIONAL LOOTER BOT TRANSACTION
 * Analyze the exact input data to understand the technique
 */

const { ethers } = require('ethers');

function decodeLooterTransaction() {
  console.log('🔍 ========== DECODING PROFESSIONAL LOOTER BOT ==========');
  
  // Input data from successful transaction
  const inputData = '0xc981cc3c000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000014c4805d0077af076ade500000000000000000000000000000000000000000001713394ae41334412168d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000174876e818000000000000000000000000000000000000000000000000000000000000002b420000000000000000000000000000000000000600271036a947baa2492c72bf9d3307117237e79145a87d000000000000000000000000000000000000000000';
  
  console.log('📝 Input Data:', inputData);
  console.log('📏 Length:', inputData.length);
  
  // Function selector
  const functionSelector = inputData.slice(0, 10);
  console.log('🎯 Function Selector:', functionSelector);
  
  // Remove function selector
  const paramData = inputData.slice(10);
  console.log('📊 Parameter Data:', paramData);
  
  // Decode parameters (each parameter is 32 bytes = 64 hex chars)
  const params = [];
  for (let i = 0; i < paramData.length; i += 64) {
    const param = paramData.slice(i, i + 64);
    if (param.length === 64) {
      params.push('0x' + param);
    }
  }
  
  console.log('\n📋 DECODED PARAMETERS:');
  params.forEach((param, index) => {
    const decimal = ethers.BigNumber.from(param);
    console.log(`  ${index}: ${param}`);
    console.log(`      Decimal: ${decimal.toString()}`);
    
    // Try to interpret as address
    if (param.startsWith('0x000000000000000000000000') && param.length === 66) {
      const address = '0x' + param.slice(26);
      console.log(`      Address: ${address}`);
    }
    
    // Try to interpret as ETH amount
    try {
      const ethAmount = ethers.utils.formatEther(decimal);
      if (parseFloat(ethAmount) > 0 && parseFloat(ethAmount) < 1000000) {
        console.log(`      ETH: ${ethAmount}`);
      }
    } catch (e) {}
    
    console.log('');
  });
  
  // Look for addresses in the data
  console.log('🔍 SEARCHING FOR ADDRESSES:');
  const addressPattern = /[0-9a-fA-F]{40}/g;
  const addresses = inputData.match(addressPattern);
  
  if (addresses) {
    addresses.forEach((addr, index) => {
      const fullAddress = '0x' + addr;
      console.log(`  Address ${index + 1}: ${fullAddress}`);
      
      // Check if it's WETH
      if (fullAddress.toLowerCase() === '0x4200000000000000000000000000000000000006') {
        console.log('    ✅ This is WETH (Base)');
      }
      
      // Check if it's TONY token
      if (fullAddress.toLowerCase() === '0x36a947baa2492c72bf9d3307117237e79145a87d') {
        console.log('    ✅ This is TONY token');
      }
    });
  }
  
  // Analyze the path data
  console.log('\n🛤️ PATH ANALYSIS:');
  const pathStart = inputData.indexOf('420000000000000000000000000000000000000006');
  if (pathStart !== -1) {
    console.log('📍 Found WETH in path at position:', pathStart);
    
    // Extract path section
    const pathSection = inputData.slice(pathStart - 6); // Include fee before WETH
    console.log('🛤️ Path section:', pathSection);
    
    // Try to decode as Uniswap V3 path
    // Format: token0 (20 bytes) + fee (3 bytes) + token1 (20 bytes)
    if (pathSection.length >= 86) { // 20 + 3 + 20 bytes = 43 bytes = 86 hex chars
      const token0 = '0x' + pathSection.slice(0, 40);
      const fee = parseInt(pathSection.slice(40, 46), 16);
      const token1 = '0x' + pathSection.slice(46, 86);
      
      console.log('🔄 Decoded Path:');
      console.log(`  Token 0: ${token0}`);
      console.log(`  Fee: ${fee} (${fee / 10000}%)`);
      console.log(`  Token 1: ${token1}`);
    }
  }
  
  console.log('\n🎯 CONCLUSION:');
  console.log('The professional Looter bot uses a custom contract that:');
  console.log('1. Takes multiple parameters including slippage, path, amounts');
  console.log('2. Uses Uniswap V3 path encoding (WETH + fee + token)');
  console.log('3. Has custom logic for handling low-liquidity tokens');
  console.log('4. Likely has MEV protection and advanced routing');
}

// Run decoder
decodeLooterTransaction();