/**
 * TEST FIXED TRADING EXECUTION
 * Test that the ✅ CONFIRM button now actually executes trades
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot
class MockBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = { message_id: messageId, chat: { id: chatId }, text, ...options };
    this.messages.push(message);
    console.log(`📤 Message: ${text.substring(0, 60)}...`);
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options, timestamp: Date.now() });
    
    if (text.includes('Trade Execution Complete')) {
      const hasSuccess = text.includes('✅ Successful: 1 wallets');
      const hasFailed = text.includes('❌ Failed: 0 wallets');
      const hasResults = text.includes('• W5: ✅ Success');
      const hasPnL = text.includes('Live P&L Tracking');
      
      console.log(`✏️ TRADE COMPLETION MESSAGE:`);
      console.log(`   ✅ Successful wallets: ${hasSuccess}`);
      console.log(`   ❌ Failed wallets: ${hasFailed}`);
      console.log(`   📊 Wallet results: ${hasResults}`);
      console.log(`   💹 P&L tracking: ${hasPnL}`);
      
      if (hasSuccess && !text.includes('❌ Failed: 1 wallets')) {
        console.log('🎉 TRADE SUCCESS! Bot is now buying tokens correctly!');
      }
    }
    
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`✅ Callback: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    return true;
  }
}

async function testFixedTrading() {
  console.log('🔧 ========== TESTING FIXED TRADING EXECUTION ==========');

  try {
    // Initialize components
    const mockBot = new MockBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(mockBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(mockBot, auth, walletManager, trading, userStates);

    const testUserId = 12345;
    auth.addUser(testUserId);

    console.log('✅ Components initialized');

    // STEP 1: Create token session
    console.log('\n📍 STEP 1: Create Token Session');
    
    const tokenMessage = {
      message_id: 1001,
      chat: { id: testUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      from: { id: testUserId }
    };

    await callbacks.buyTokenUI.handleContractAddress(tokenMessage);
    console.log('✅ Token session created');

    // STEP 2: Select wallet W5 (the one that failed before)
    console.log('\n📍 STEP 2: Select Wallet W5');
    
    await callbacks.handleWalletSelect({
      id: 'test_wallet_select',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'ws_t1_5'  // Select W5 specifically
    });
    
    console.log('✅ Wallet W5 selected');

    // STEP 3: Select amount 0.001
    console.log('\n📍 STEP 3: Select Amount 0.001');
    
    await callbacks.handleBuySelectAmount({
      id: 'test_amount_select',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'buy_select_amount_t1_0.01'
    });
    
    console.log('✅ Amount 0.01 selected');

    // STEP 4: Click CONFIRM (this should now work!)
    console.log('\n📍 STEP 4: Click ✅ CONFIRM Button');
    console.log('🚀 This should now execute a real trade...');
    
    const confirmCallback = {
      id: 'test_confirm',
      from: { id: testUserId },
      message: { message_id: 1001 },
      data: 'buy_confirm_new_t1'
    };
    
    // Execute the confirm action
    await callbacks.handleBuyConfirmNew(confirmCallback);
    
    console.log('✅ CONFIRM button executed');

    // Wait for async operations
    await new Promise(resolve => setTimeout(resolve, 3000));

    // STEP 5: Check results
    console.log('\n📍 STEP 5: Check Trade Results');
    
    const tradeCompletionEdit = mockBot.edits.find(edit => 
      edit.text.includes('Trade Execution Complete')
    );
    
    if (!tradeCompletionEdit) {
      console.log('❌ No trade completion message found');
      console.log('Available edits:', mockBot.edits.map(e => e.text.substring(0, 50)));
      return false;
    }

    const completionText = tradeCompletionEdit.text;
    
    // Check for success indicators
    const hasSuccess = completionText.includes('✅ Successful: 1 wallets');
    const hasNoFailures = !completionText.includes('❌ Failed: 1 wallets');
    const hasWalletSuccess = completionText.includes('• W5: ✅ Success');
    const hasTxHash = completionText.includes('📝 TX:');
    const hasPnL = completionText.includes('Live P&L Tracking');
    
    console.log('\n📊 ========== TRADE RESULTS ANALYSIS ==========');
    console.log(`✅ Successful execution: ${hasSuccess}`);
    console.log(`❌ No failures: ${hasNoFailures}`);
    console.log(`🏦 Wallet W5 success: ${hasWalletSuccess}`);
    console.log(`📝 Transaction hash: ${hasTxHash}`);
    console.log(`💹 P&L tracking: ${hasPnL}`);

    if (hasSuccess && hasNoFailures && hasWalletSuccess && hasTxHash && hasPnL) {
      console.log('\n🎉 ========== TRADING FIX SUCCESSFUL! ==========');
      console.log('✅ Wallets are now accessible');
      console.log('✅ Trades execute successfully');
      console.log('✅ Transaction hashes generated');
      console.log('✅ P&L tracking active');
      console.log('✅ Your ✅ CONFIRM button now WORKS!');
      return true;
    } else {
      console.log('\n❌ ========== TRADING STILL HAS ISSUES ==========');
      console.log('❌ Some aspects of trading execution failed');
      return false;
    }

  } catch (error) {
    console.error('❌ TEST ERROR:', error.message);
    console.error('Stack:', error.stack);
    return false;
  }
}

// Run the test
testFixedTrading().then(success => {
  if (success) {
    console.log('\n🚀 ========== TRADING EXECUTION FIXED! ==========');
    console.log('🎉 Your bot now successfully executes trades!');
    console.log('');
    console.log('📱 **User Experience:**');
    console.log('1. User selects token → ✅ Works');
    console.log('2. User selects wallet → ✅ Works');
    console.log('3. User selects amount → ✅ Works');
    console.log('4. User clicks CONFIRM → ✅ NOW WORKS!');
    console.log('5. Bot executes trade → ✅ SUCCESS!');
    console.log('6. Bot shows P&L → ✅ LIVE TRACKING!');
    console.log('');
    console.log('🔥 Your trading bot is now fully functional!');
    process.exit(0);
  } else {
    console.log('\n💥 ========== TRADING NEEDS MORE FIXES ==========');
    console.log('❌ Check the error messages above');
    process.exit(1);
  }
}).catch(error => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});