/**
 * DEBUG REAL TRADING EXECUTION
 * Check what's actually happening when trades are executed
 */

const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');

async function debugRealTrading() {
  console.log('🔍 ========== DEBUGGING REAL TRADING EXECUTION ==========');

  try {
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    
    await walletManager.initialize();
    
    const testUserId = 12345;
    
    // Get Base wallets
    console.log('\n📍 STEP 1: Get User Wallets');
    const baseWallets = await walletManager.getChainWallets(testUserId, 'base');
    console.log(`✅ Found ${Object.keys(baseWallets).length} Base wallets`);
    
    if (Object.keys(baseWallets).length === 0) {
      console.log('❌ No wallets found - cannot test trading');
      return;
    }
    
    // Get the first wallet
    const firstWallet = Object.values(baseWallets)[0];
    console.log(`🔧 Using wallet: ${firstWallet.address}`);
    console.log(`🔑 Private key available: ${!!firstWallet.privateKey}`);
    
    // Test token address (Based Marie Rose)
    const tokenAddress = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'; // USDC for testing
    const amount = '0.001';
    
    console.log('\n📍 STEP 2: Execute Trade via Chain Manager');
    console.log(`🎯 Token: ${tokenAddress}`);
    console.log(`💰 Amount: ${amount} ETH`);
    console.log(`🏦 Wallet: ${firstWallet.address}`);
    
    // This should trigger the REAL trading logic
    try {
      const result = await chainManager.executeBuy(
        'base', 
        firstWallet.privateKey, 
        tokenAddress, 
        amount, 
        1.0 // 1% slippage
      );
      
      console.log('\n✅ TRADE RESULT:');
      console.log(`📝 Success: ${result.success}`);
      console.log(`📝 TX Hash: ${result.txHash}`);
      console.log(`📝 Chain: ${result.chain}`);
      console.log(`📝 Gas Used: ${result.gasUsed}`);
      console.log(`📝 Fee Tier: ${result.feeTier || 'Not specified'}`);
      
      // Check if it's a real or fake hash
      if (result.txHash && result.txHash.length === 66 && result.txHash.startsWith('0x')) {
        console.log('\n🔍 TRANSACTION HASH ANALYSIS:');
        console.log(`📝 Hash: ${result.txHash}`);
        console.log(`📝 Length: ${result.txHash.length} (should be 66)`);
        console.log(`📝 Format: ${result.txHash.startsWith('0x') ? 'Valid' : 'Invalid'}`);
        
        // Try to determine if it's fake
        const hashWithoutPrefix = result.txHash.slice(2);
        const isAllSameChar = [...new Set(hashWithoutPrefix)].length === 1;
        const hasRepeatingPattern = /(.{2})\1{3,}/.test(hashWithoutPrefix);
        
        if (isAllSameChar || hasRepeatingPattern) {
          console.log('🚨 THIS LOOKS LIKE A FAKE HASH!');
        } else {
          console.log('✅ This looks like a real transaction hash');
          console.log(`🔗 Check on BaseScan: https://basescan.org/tx/${result.txHash}`);
        }
      }
      
    } catch (error) {
      console.log('\n❌ TRADE FAILED:');
      console.log(`📝 Error: ${error.message}`);
      console.log(`📝 Stack: ${error.stack}`);
    }
    
    console.log('\n📍 STEP 3: Check Base Trading Class Directly');
    
    const baseTrading = chainManager.getChain('base');
    if (baseTrading) {
      console.log('✅ Base trading class found');
      
      // Check if it has the real executeBuy method
      const executeBuySource = baseTrading.executeBuy.toString();
      
      if (executeBuySource.includes('generateTxHash')) {
        console.log('🚨 FAKE TRADING DETECTED! Still using generateTxHash()');
      } else if (executeBuySource.includes('router.exactInputSingle')) {
        console.log('✅ REAL TRADING DETECTED! Using Uniswap V3 router');
      } else {
        console.log('❓ UNKNOWN TRADING TYPE');
      }
      
      console.log('\n📝 ExecuteBuy method preview:');
      console.log(executeBuySource.substring(0, 500) + '...');
    }

  } catch (error) {
    console.error('❌ Debug error:', error.message);
  }
}

debugRealTrading();