/**
 * DEBUG LIVE TOKEN INPUT
 * Simulate exactly what happens when user sends a token CA
 */

const TelegramBot = require('node-telegram-bot-api');
const Auth = require('./auth/auth');
const ChainManager = require('./chains/chain-manager');
const WalletDBManager = require('./database/wallet-db-manager');
const Trading = require('./trading/trading');
const Callbacks = require('./callbacks/callbacks');
const UserStates = require('./utils/user-states');

// Mock bot that logs everything
class DebugBot {
  constructor() {
    this.messages = [];
    this.edits = [];
    this.callbacks = [];
  }

  async sendMessage(chatId, text, options = {}) {
    const messageId = Date.now() + Math.random();
    const message = {
      message_id: messageId,
      chat: { id: chatId },
      text: text,
      ...options
    };
    this.messages.push(message);
    console.log(`\n📤 BOT WOULD SEND MESSAGE:`);
    console.log(`   Chat ID: ${chatId}`);
    console.log(`   Text: ${text.substring(0, 200)}...`);
    console.log(`   Options:`, options.reply_markup ? 'Has keyboard' : 'No keyboard');
    return message;
  }

  async editMessageText(text, options = {}) {
    this.edits.push({ text, options });
    console.log(`\n✏️ BOT WOULD EDIT MESSAGE:`);
    console.log(`   Text: ${text.substring(0, 200)}...`);
    return { message_id: options.message_id };
  }

  async answerCallbackQuery(callbackId, options = {}) {
    this.callbacks.push({ callbackId, options });
    console.log(`\n✅ BOT WOULD ANSWER CALLBACK:`);
    console.log(`   Text: ${options.text || 'No text'}`);
    return true;
  }

  async deleteMessage(chatId, messageId) {
    console.log(`\n🗑️ BOT WOULD DELETE MESSAGE: ${messageId}`);
    return true;
  }
}

async function debugLiveTokenInput() {
  console.log('🔍 ========== DEBUG LIVE TOKEN INPUT ==========');

  try {
    // Initialize components exactly like the real bot
    console.log('🔧 Initializing components...');
    const debugBot = new DebugBot();
    const auth = new Auth();
    const chainManager = new ChainManager();
    const walletManager = new WalletDBManager(chainManager);
    const trading = new Trading(debugBot, walletManager);
    const userStates = new UserStates();
    const callbacks = new Callbacks(debugBot, auth, walletManager, trading, userStates);

    // Add your user ID (replace with your actual Telegram user ID)
    const yourUserId = 12345; // Replace this with your actual user ID
    auth.addUser(yourUserId);
    console.log(`✅ Added user ${yourUserId} to authorized list`);

    // Simulate the exact flow
    console.log('\n📍 STEP 1: User clicks Buy Token button');
    const buyTokenCallback = {
      id: 'callback_1',
      data: 'buy_menu',
      from: { id: yourUserId },
      message: { message_id: 1001 }
    };
    
    await callbacks.handle(buyTokenCallback);
    console.log('✅ Buy token menu should be displayed');

    // Check if user is now waiting for contract address
    const isWaiting = callbacks.buyTokenUI.isWaitingForContractAddress(yourUserId);
    console.log(`🔍 Is user waiting for contract address? ${isWaiting}`);

    console.log('\n📍 STEP 2: User sends contract address');
    const contractMessage = {
      message_id: 1002,
      chat: { id: yourUserId },
      text: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDC on Base
      from: { id: yourUserId },
      date: Math.floor(Date.now() / 1000)
    };

    console.log('🎯 Simulating contract address input...');
    console.log(`   Address: ${contractMessage.text}`);
    console.log(`   User ID: ${yourUserId}`);

    // This is what should happen in the main bot message handler
    console.log('\n🔍 CHECKING MESSAGE HANDLER CONDITIONS:');
    
    // Check if user is waiting for contract address
    const waitingForCA = callbacks.buyTokenUI.isWaitingForContractAddress(yourUserId);
    console.log(`   1. Waiting for contract address: ${waitingForCA}`);
    
    // Check if it's a contract address
    const isContractAddress = /^0x[a-fA-F0-9]{40}$/.test(contractMessage.text) || 
                             (contractMessage.text.length >= 32 && contractMessage.text.length <= 44);
    console.log(`   2. Is contract address format: ${isContractAddress}`);

    // Check user authorization
    const isAuthorized = auth.isAuthorized(yourUserId);
    console.log(`   3. User authorized: ${isAuthorized}`);

    if (waitingForCA || isContractAddress) {
      console.log('\n✅ CONDITIONS MET - Processing contract address...');
      await callbacks.buyTokenUI.handleContractAddress(contractMessage);
    } else {
      console.log('\n❌ CONDITIONS NOT MET - Contract address not processed');
    }

    // Summary
    console.log('\n📊 ========== SUMMARY ==========');
    console.log(`📤 Messages that would be sent: ${debugBot.messages.length}`);
    console.log(`✏️ Messages that would be edited: ${debugBot.edits.length}`);
    console.log(`✅ Callbacks that would be answered: ${debugBot.callbacks.length}`);

    if (debugBot.messages.length === 0) {
      console.log('\n❌ PROBLEM: No messages would be sent to user!');
      console.log('🔍 This explains why you\'re not getting a response');
      
      // Let's check what might be blocking it
      console.log('\n🔍 DEBUGGING FURTHER...');
      
      // Check user states
      const userState = userStates.get(yourUserId);
      console.log(`   User state: ${userState ? JSON.stringify(userState) : 'None'}`);
      
      // Check buy token UI state
      const buyTokenState = callbacks.buyTokenUI.userStates.get(yourUserId);
      console.log(`   Buy token state: ${buyTokenState ? JSON.stringify(buyTokenState) : 'None'}`);
      
    } else {
      console.log('\n✅ SUCCESS: Bot would respond with token information');
      debugBot.messages.forEach((msg, i) => {
        console.log(`   Message ${i + 1}: ${msg.text.substring(0, 100)}...`);
      });
    }

  } catch (error) {
    console.error('\n❌ ERROR DURING DEBUG:', error.message);
    console.error('❌ STACK:', error.stack);
  }
}

debugLiveTokenInput().then(() => {
  console.log('\n🎉 Debug completed');
  process.exit(0);
}).catch(error => {
  console.error('💥 Debug failed:', error);
  process.exit(1);
});