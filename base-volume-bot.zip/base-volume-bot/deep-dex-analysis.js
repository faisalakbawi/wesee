#!/usr/bin/env node

/**
 * DEEP DEX ANALYSIS
 * Complete analysis of the TONY/WETH trading ecosystem
 * Separates pool, router, LP, and actual trading mechanics
 */

require('dotenv').config();
const { ethers } = require('ethers');

class DeepDexAnalysis {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider('https://base.llamarpc.com');
    
    // All the addresses we need to analyze
    this.addresses = {
      TONY_TOKEN: '0x36a947baa2492c72bf9d3307117237e79145a87d',
      WETH: '0x4200000000000000000000000000000000000006',
      TONY_POOL: '0x89649AF832915FF8F24100a58b6A6FBc498de911',
      UNISWAP_V3_ROUTER: '0x2626664c2603336E57B271c5C0b26F421741e481',
      UNISWAP_V3_FACTORY: '0x33128a8fC17869897dcE68Ed026d694621f6FDfD',
      LP_ADDRESS: '0xb3bea12afc263318c16dc16dbfd5ab3a0261dabf',
      WALLET: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A'
    };
    
    // Comprehensive ABIs
    this.abis = {
      ERC20: [
        'function name() external view returns (string)',
        'function symbol() external view returns (string)',
        'function decimals() external view returns (uint8)',
        'function totalSupply() external view returns (uint256)',
        'function balanceOf(address account) external view returns (uint256)',
        'function allowance(address owner, address spender) external view returns (uint256)',
        'function transfer(address to, uint256 amount) external returns (bool)',
        'function approve(address spender, uint256 amount) external returns (bool)',
        'function transferFrom(address from, address to, uint256 amount) external returns (bool)',
        'event Transfer(address indexed from, address indexed to, uint256 value)',
        'event Approval(address indexed owner, address indexed spender, uint256 value)'
      ],
      
      POOL: [
        'function factory() external view returns (address)',
        'function token0() external view returns (address)',
        'function token1() external view returns (address)',
        'function fee() external view returns (uint24)',
        'function tickSpacing() external view returns (int24)',
        'function maxLiquidityPerTick() external view returns (uint128)',
        'function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
        'function feeGrowthGlobal0X128() external view returns (uint256)',
        'function feeGrowthGlobal1X128() external view returns (uint256)',
        'function protocolFees() external view returns (uint128 token0, uint128 token1)',
        'function liquidity() external view returns (uint128)',
        'function ticks(int24 tick) external view returns (uint128 liquidityGross, int128 liquidityNet, uint256 feeGrowthOutside0X128, uint256 feeGrowthOutside1X128, int56 tickCumulativeOutside, uint160 secondsPerLiquidityOutsideX128, uint32 secondsOutside, bool initialized)',
        'function tickBitmap(int16 wordPosition) external view returns (uint256)',
        'function positions(bytes32 key) external view returns (uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
        'function observations(uint256 index) external view returns (uint32 blockTimestamp, int56 tickCumulative, uint160 secondsPerLiquidityCumulativeX128, bool initialized)',
        'function observe(uint32[] calldata secondsAgos) external view returns (int56[] memory tickCumulatives, uint160[] memory secondsPerLiquidityCumulativeX128s)',
        'function snapshotCumulativesInside(int24 tickLower, int24 tickUpper) external view returns (int56 tickCumulativeInside, uint160 secondsPerLiquidityInsideX128, uint32 secondsInside)',
        'event Initialize(uint160 sqrtPriceX96, int24 tick)',
        'event Mint(address sender, address indexed owner, int24 indexed tickLower, int24 indexed tickUpper, uint128 amount, uint256 amount0, uint256 amount1)',
        'event Burn(address indexed owner, int24 indexed tickLower, int24 indexed tickUpper, uint128 amount, uint256 amount0, uint256 amount1)',
        'event Swap(address indexed sender, address indexed recipient, int256 amount0, int256 amount1, uint160 sqrtPriceX96, uint128 liquidity, int24 tick)',
        'event Flash(address indexed sender, address indexed recipient, uint256 amount0, uint256 amount1, uint256 paid0, uint256 paid1)',
        'event IncreaseObservationCardinalityNext(uint16 observationCardinalityNextOld, uint16 observationCardinalityNextNew)',
        'event SetFeeProtocol(uint8 feeProtocol0Old, uint8 feeProtocol1Old, uint8 feeProtocol0New, uint8 feeProtocol1New)',
        'event CollectProtocol(address indexed sender, address indexed recipient, uint128 amount0, uint128 amount1)'
      ],
      
      ROUTER: [
        'function factory() external pure returns (address)',
        'function WETH9() external pure returns (address)',
        'function exactInputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum, uint160 sqrtPriceLimitX96)) external payable returns (uint256 amountOut)',
        'function exactInput((bytes path, address recipient, uint256 deadline, uint256 amountIn, uint256 amountOutMinimum)) external payable returns (uint256 amountOut)',
        'function exactOutputSingle((address tokenIn, address tokenOut, uint24 fee, address recipient, uint256 deadline, uint256 amountOut, uint256 amountInMaximum, uint160 sqrtPriceLimitX96)) external payable returns (uint256 amountIn)',
        'function exactOutput((bytes path, address recipient, uint256 deadline, uint256 amountOut, uint256 amountInMaximum)) external payable returns (uint256 amountIn)',
        'function uniswapV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata data) external'
      ],
      
      FACTORY: [
        'function owner() external view returns (address)',
        'function feeAmountTickSpacing(uint24 fee) external view returns (int24)',
        'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)',
        'function createPool(address tokenA, address tokenB, uint24 fee) external returns (address pool)',
        'function setOwner(address _owner) external',
        'function enableFeeAmount(uint24 fee, int24 tickSpacing) external',
        'event OwnerChanged(address indexed oldOwner, address indexed newOwner)',
        'event PoolCreated(address indexed token0, address indexed token1, uint24 indexed fee, int24 tickSpacing, address pool)',
        'event FeeAmountEnabled(uint24 indexed fee, int24 indexed tickSpacing)'
      ]
    };
  }
  
  async runDeepAnalysis() {
    console.log('🔬 ========== DEEP DEX ANALYSIS ==========');
    console.log('🎯 Analyzing EVERY component of the TONY trading ecosystem');
    console.log('📊 This will show the complete picture of what\'s happening\n');
    
    try {
      // SECTION 1: Contract Existence and Basic Info
      await this.analyzeContractExistence();
      
      // SECTION 2: Token Analysis
      await this.analyzeTokens();
      
      // SECTION 3: Pool Deep Dive
      await this.analyzePoolDeep();
      
      // SECTION 4: Router Analysis
      await this.analyzeRouter();
      
      // SECTION 5: Factory Analysis
      await this.analyzeFactory();
      
      // SECTION 6: Liquidity Provider Analysis
      await this.analyzeLiquidityProvider();
      
      // SECTION 7: Trading Simulation
      await this.simulateTrading();
      
      // SECTION 8: Alternative DEX Check
      await this.checkAlternativeDEXs();
      
      // SECTION 9: Final Diagnosis
      await this.provideFinalDiagnosis();
      
    } catch (error) {
      console.error('❌ Deep analysis failed:', error.message);
    }
  }
  
  async analyzeContractExistence() {
    console.log('📋 SECTION 1: CONTRACT EXISTENCE ANALYSIS');
    console.log('=' .repeat(50));
    
    for (const [name, address] of Object.entries(this.addresses)) {
      try {
        const code = await this.provider.getCode(address);
        const exists = code !== '0x';
        const codeSize = code.length;
        
        console.log(`  ${name}:`);
        console.log(`    Address: ${address}`);
        console.log(`    Exists: ${exists ? '✅' : '❌'}`);
        console.log(`    Code Size: ${codeSize} bytes`);
        
        if (exists) {
          // Try to get basic info if it's an ERC20
          if (name.includes('TOKEN') || name === 'WETH') {
            try {
              const contract = new ethers.Contract(address, this.abis.ERC20, this.provider);
              const [name_token, symbol] = await Promise.all([
                contract.name().catch(() => 'N/A'),
                contract.symbol().catch(() => 'N/A')
              ]);
              console.log(`    Token Name: ${name_token}`);
              console.log(`    Token Symbol: ${symbol}`);
            } catch (e) {
              console.log(`    Token Info: Failed to retrieve`);
            }
          }
        }
        console.log('');
      } catch (error) {
        console.log(`  ${name}: ❌ Error - ${error.message}\n`);
      }
    }
  }
  
  async analyzeTokens() {
    console.log('🪙 SECTION 2: TOKEN ANALYSIS');
    console.log('=' .repeat(50));
    
    const tokens = [
      { name: 'TONY', address: this.addresses.TONY_TOKEN },
      { name: 'WETH', address: this.addresses.WETH }
    ];
    
    for (const token of tokens) {
      try {
        console.log(`  📊 ${token.name} Token Analysis:`);
        const contract = new ethers.Contract(token.address, this.abis.ERC20, this.provider);
        
        const [name, symbol, decimals, totalSupply] = await Promise.all([
          contract.name(),
          contract.symbol(),
          contract.decimals(),
          contract.totalSupply()
        ]);
        
        console.log(`    Name: ${name}`);
        console.log(`    Symbol: ${symbol}`);
        console.log(`    Decimals: ${decimals}`);
        console.log(`    Total Supply: ${ethers.utils.formatUnits(totalSupply, decimals)}`);
        
        // Check balances in key addresses
        const balances = await Promise.all([
          contract.balanceOf(this.addresses.TONY_POOL),
          contract.balanceOf(this.addresses.LP_ADDRESS),
          contract.balanceOf(this.addresses.WALLET),
          contract.balanceOf(this.addresses.UNISWAP_V3_ROUTER)
        ]);
        
        console.log(`    Balances:`);
        console.log(`      Pool: ${ethers.utils.formatUnits(balances[0], decimals)}`);
        console.log(`      LP: ${ethers.utils.formatUnits(balances[1], decimals)}`);
        console.log(`      Wallet: ${ethers.utils.formatUnits(balances[2], decimals)}`);
        console.log(`      Router: ${ethers.utils.formatUnits(balances[3], decimals)}`);
        
        // Check allowances
        const allowances = await Promise.all([
          contract.allowance(this.addresses.WALLET, this.addresses.UNISWAP_V3_ROUTER),
          contract.allowance(this.addresses.LP_ADDRESS, this.addresses.UNISWAP_V3_ROUTER)
        ]);
        
        console.log(`    Allowances:`);
        console.log(`      Wallet→Router: ${ethers.utils.formatUnits(allowances[0], decimals)}`);
        console.log(`      LP→Router: ${ethers.utils.formatUnits(allowances[1], decimals)}`);
        
        console.log('');
      } catch (error) {
        console.log(`    ❌ ${token.name} analysis failed: ${error.message}\n`);
      }
    }
  }
  
  async analyzePoolDeep() {
    console.log('🏊 SECTION 3: POOL DEEP ANALYSIS');
    console.log('=' .repeat(50));
    
    try {
      const pool = new ethers.Contract(this.addresses.TONY_POOL, this.abis.POOL, this.provider);
      
      console.log(`  📍 Pool Address: ${this.addresses.TONY_POOL}`);
      
      // Basic pool info
      const [factory, token0, token1, fee, tickSpacing, maxLiquidityPerTick] = await Promise.all([
        pool.factory(),
        pool.token0(),
        pool.token1(),
        pool.fee(),
        pool.tickSpacing(),
        pool.maxLiquidityPerTick()
      ]);
      
      console.log(`  🏭 Factory: ${factory}`);
      console.log(`  🪙 Token0: ${token0} ${token0.toLowerCase() === this.addresses.TONY_TOKEN.toLowerCase() ? '(TONY)' : '(WETH)'}`);
      console.log(`  🪙 Token1: ${token1} ${token1.toLowerCase() === this.addresses.WETH.toLowerCase() ? '(WETH)' : '(TONY)'}`);
      console.log(`  💸 Fee: ${fee} (${fee / 10000}%)`);
      console.log(`  📏 Tick Spacing: ${tickSpacing}`);
      console.log(`  💧 Max Liquidity Per Tick: ${maxLiquidityPerTick.toString()}`);
      
      // Current state
      const [slot0, liquidity, feeGrowthGlobal0, feeGrowthGlobal1, protocolFees] = await Promise.all([
        pool.slot0(),
        pool.liquidity(),
        pool.feeGrowthGlobal0X128(),
        pool.feeGrowthGlobal1X128(),
        pool.protocolFees()
      ]);
      
      console.log(`\n  📊 Current State:`);
      console.log(`    SqrtPriceX96: ${slot0.sqrtPriceX96.toString()}`);
      console.log(`    Current Tick: ${slot0.tick}`);
      console.log(`    Observation Index: ${slot0.observationIndex}`);
      console.log(`    Observation Cardinality: ${slot0.observationCardinality}`);
      console.log(`    Observation Cardinality Next: ${slot0.observationCardinalityNext}`);
      console.log(`    Fee Protocol: ${slot0.feeProtocol}`);
      console.log(`    Unlocked: ${slot0.unlocked}`);
      console.log(`    Total Liquidity: ${liquidity.toString()}`);
      console.log(`    Fee Growth Global 0: ${feeGrowthGlobal0.toString()}`);
      console.log(`    Fee Growth Global 1: ${feeGrowthGlobal1.toString()}`);
      console.log(`    Protocol Fees Token0: ${protocolFees.token0.toString()}`);
      console.log(`    Protocol Fees Token1: ${protocolFees.token1.toString()}`);
      
      // Calculate price
      if (slot0.sqrtPriceX96.gt(0)) {
        const price = slot0.sqrtPriceX96.mul(slot0.sqrtPriceX96).div(ethers.BigNumber.from(2).pow(192));
        console.log(`    Calculated Price: ${price.toString()}`);
        
        // Determine which direction
        const isWETHToken0 = token0.toLowerCase() === this.addresses.WETH.toLowerCase();
        if (isWETHToken0) {
          console.log(`    Price Direction: Token1 per Token0 (TONY per WETH)`);
        } else {
          console.log(`    Price Direction: Token0 per Token1 (TONY per WETH)`);
        }
      }
      
      // Check recent observations
      try {
        const observations = await pool.observe([0, 1, 60, 300]); // Current, 1s, 1m, 5m ago
        console.log(`\n  📈 Price Observations:`);
        console.log(`    Current: ${observations.tickCumulatives[0].toString()}`);
        console.log(`    1s ago: ${observations.tickCumulatives[1].toString()}`);
        console.log(`    1m ago: ${observations.tickCumulatives[2].toString()}`);
        console.log(`    5m ago: ${observations.tickCumulatives[3].toString()}`);
      } catch (error) {
        console.log(`    ⚠️ Observations failed: ${error.message}`);
      }
      
    } catch (error) {
      console.log(`  ❌ Pool analysis failed: ${error.message}`);
    }
    
    console.log('');
  }
  
  async analyzeRouter() {
    console.log('🔀 SECTION 4: ROUTER ANALYSIS');
    console.log('=' .repeat(50));
    
    try {
      const router = new ethers.Contract(this.addresses.UNISWAP_V3_ROUTER, this.abis.ROUTER, this.provider);
      
      console.log(`  📍 Router Address: ${this.addresses.UNISWAP_V3_ROUTER}`);
      
      // Basic router info
      const [factory, weth9] = await Promise.all([
        router.factory(),
        router.WETH9()
      ]);
      
      console.log(`  🏭 Factory: ${factory}`);
      console.log(`  💧 WETH9: ${weth9}`);
      console.log(`  ✅ WETH9 matches our WETH: ${weth9.toLowerCase() === this.addresses.WETH.toLowerCase()}`);
      console.log(`  ✅ Factory matches pool factory: ${factory.toLowerCase() === this.addresses.UNISWAP_V3_FACTORY.toLowerCase()}`);
      
      // Test router functionality with a simple call
      try {
        console.log(`\n  🧪 Testing Router Functionality:`);
        
        // Try to estimate gas for a small swap
        const params = {
          tokenIn: this.addresses.WETH,
          tokenOut: this.addresses.TONY_TOKEN,
          fee: 10000,
          recipient: this.addresses.WALLET,
          deadline: Math.floor(Date.now() / 1000) + 300,
          amountIn: ethers.utils.parseEther('0.0001'),
          amountOutMinimum: 0,
          sqrtPriceLimitX96: 0
        };
        
        console.log(`    Testing exactInputSingle with 0.0001 ETH...`);
        
        const gasEstimate = await router.estimateGas.exactInputSingle(params, {
          value: ethers.utils.parseEther('0.0001'),
          from: this.addresses.WALLET
        });
        
        console.log(`    ✅ Gas estimate successful: ${gasEstimate.toString()}`);
        console.log(`    💡 This means the router CAN process the transaction`);
        
      } catch (error) {
        console.log(`    ❌ Router test failed: ${error.message}`);
        console.log(`    💡 This suggests the issue is in the swap logic, not the router`);
        
        // Try to decode the error
        if (error.message.includes('execution reverted')) {
          console.log(`    🔍 Execution reverted - likely a pool or token issue`);
        }
        if (error.message.includes('insufficient')) {
          console.log(`    🔍 Insufficient something - liquidity, balance, or allowance`);
        }
      }
      
    } catch (error) {
      console.log(`  ❌ Router analysis failed: ${error.message}`);
    }
    
    console.log('');
  }
  
  async analyzeFactory() {
    console.log('🏭 SECTION 5: FACTORY ANALYSIS');
    console.log('=' .repeat(50));
    
    try {
      const factory = new ethers.Contract(this.addresses.UNISWAP_V3_FACTORY, this.abis.FACTORY, this.provider);
      
      console.log(`  📍 Factory Address: ${this.addresses.UNISWAP_V3_FACTORY}`);
      
      // Basic factory info
      const owner = await factory.owner();
      console.log(`  👤 Owner: ${owner}`);
      
      // Check all fee tiers
      const feeTiers = [100, 500, 3000, 10000];
      console.log(`\n  🔍 Checking all fee tiers for TONY/WETH pools:`);
      
      for (const fee of feeTiers) {
        try {
          const [tickSpacing, pool1, pool2] = await Promise.all([
            factory.feeAmountTickSpacing(fee),
            factory.getPool(this.addresses.WETH, this.addresses.TONY_TOKEN, fee),
            factory.getPool(this.addresses.TONY_TOKEN, this.addresses.WETH, fee)
          ]);
          
          console.log(`    ${fee / 10000}% fee (${fee}):`);
          console.log(`      Tick Spacing: ${tickSpacing}`);
          console.log(`      WETH/TONY Pool: ${pool1}`);
          console.log(`      TONY/WETH Pool: ${pool2}`);
          
          if (pool1 !== ethers.constants.AddressZero) {
            console.log(`      ✅ Pool exists: ${pool1}`);
            if (pool1.toLowerCase() === this.addresses.TONY_POOL.toLowerCase()) {
              console.log(`      🎯 This is our target pool!`);
            }
          }
          
          if (pool2 !== ethers.constants.AddressZero && pool2 !== pool1) {
            console.log(`      ✅ Alternative pool: ${pool2}`);
          }
        } catch (error) {
          console.log(`    ${fee / 10000}% fee: ❌ ${error.message}`);
        }
      }
      
    } catch (error) {
      console.log(`  ❌ Factory analysis failed: ${error.message}`);
    }
    
    console.log('');
  }
  
  async analyzeLiquidityProvider() {
    console.log('🏦 SECTION 6: LIQUIDITY PROVIDER ANALYSIS');
    console.log('=' .repeat(50));
    
    try {
      console.log(`  📍 LP Address: ${this.addresses.LP_ADDRESS}`);
      
      // Check if it's a contract
      const code = await this.provider.getCode(this.addresses.LP_ADDRESS);
      const isContract = code !== '0x';
      console.log(`  🔧 Is Contract: ${isContract}`);
      
      if (isContract) {
        console.log(`  💡 This is a smart contract - likely a position manager or multisig`);
        console.log(`  📏 Contract size: ${code.length} bytes`);
      }
      
      // Check balances
      const [ethBalance, tonyBalance, wethBalance, nonce] = await Promise.all([
        this.provider.getBalance(this.addresses.LP_ADDRESS),
        new ethers.Contract(this.addresses.TONY_TOKEN, this.abis.ERC20, this.provider).balanceOf(this.addresses.LP_ADDRESS),
        new ethers.Contract(this.addresses.WETH, this.abis.ERC20, this.provider).balanceOf(this.addresses.LP_ADDRESS),
        this.provider.getTransactionCount(this.addresses.LP_ADDRESS)
      ]);
      
      console.log(`  💰 Balances:`);
      console.log(`    ETH: ${ethers.utils.formatEther(ethBalance)}`);
      console.log(`    TONY: ${ethers.utils.formatEther(tonyBalance)}`);
      console.log(`    WETH: ${ethers.utils.formatEther(wethBalance)}`);
      console.log(`  📊 Transaction Count: ${nonce}`);
      
      // Try to get recent transactions (simplified)
      console.log(`\n  🔍 LP Activity Analysis:`);
      if (nonce > 0) {
        console.log(`    ✅ LP has made ${nonce} transactions`);
        console.log(`    💡 This is an active account`);
      } else {
        console.log(`    ⚠️ LP has never made transactions`);
        console.log(`    💡 This might be a contract-only account`);
      }
      
    } catch (error) {
      console.log(`  ❌ LP analysis failed: ${error.message}`);
    }
    
    console.log('');
  }
  
  async simulateTrading() {
    console.log('🧪 SECTION 7: TRADING SIMULATION');
    console.log('=' .repeat(50));
    
    try {
      console.log(`  🎯 Simulating TONY trading with different approaches...`);
      
      const router = new ethers.Contract(this.addresses.UNISWAP_V3_ROUTER, this.abis.ROUTER, this.provider);
      
      // Test different amounts
      const testAmounts = ['0.00001', '0.0001', '0.001', '0.01'];
      
      for (const amount of testAmounts) {
        console.log(`\n    💰 Testing ${amount} ETH:`);
        
        const params = {
          tokenIn: this.addresses.WETH,
          tokenOut: this.addresses.TONY_TOKEN,
          fee: 10000,
          recipient: this.addresses.WALLET,
          deadline: Math.floor(Date.now() / 1000) + 300,
          amountIn: ethers.utils.parseEther(amount),
          amountOutMinimum: 0,
          sqrtPriceLimitX96: 0
        };
        
        try {
          const gasEstimate = await router.estimateGas.exactInputSingle(params, {
            value: ethers.utils.parseEther(amount),
            from: this.addresses.WALLET
          });
          
          console.log(`      ✅ ${amount} ETH: Gas ${gasEstimate.toString()}`);
          
        } catch (error) {
          console.log(`      ❌ ${amount} ETH: ${error.message}`);
          
          // Try to understand the error
          if (error.message.includes('STF')) {
            console.log(`        💡 STF error - likely insufficient balance or allowance`);
          } else if (error.message.includes('execution reverted')) {
            console.log(`        💡 Execution reverted - pool or swap logic issue`);
          } else if (error.message.includes('insufficient')) {
            console.log(`        💡 Insufficient something - need to investigate further`);
          }
        }
      }
      
      // Test with exactInput method
      console.log(`\n    🛤️ Testing exactInput method:`);
      
      const path = ethers.utils.solidityPack(
        ['address', 'uint24', 'address'],
        [this.addresses.WETH, 10000, this.addresses.TONY_TOKEN]
      );
      
      const pathParams = {
        path: path,
        recipient: this.addresses.WALLET,
        deadline: Math.floor(Date.now() / 1000) + 300,
        amountIn: ethers.utils.parseEther('0.001'),
        amountOutMinimum: 0
      };
      
      try {
        const gasEstimate = await router.estimateGas.exactInput(pathParams, {
          value: ethers.utils.parseEther('0.001'),
          from: this.addresses.WALLET
        });
        
        console.log(`      ✅ exactInput: Gas ${gasEstimate.toString()}`);
        
      } catch (error) {
        console.log(`      ❌ exactInput: ${error.message}`);
      }
      
    } catch (error) {
      console.log(`  ❌ Trading simulation failed: ${error.message}`);
    }
    
    console.log('');
  }
  
  async checkAlternativeDEXs() {
    console.log('🔄 SECTION 8: ALTERNATIVE DEX CHECK');
    console.log('=' .repeat(50));
    
    // Known DEX routers on Base
    const dexRouters = {
      'SushiSwap': '0x6BDED42c6DA8FBf0d2bA55B2fa120C5e0c8D7891',
      'PancakeSwap': '0x678Aa4bF4E210cf2166753e054d5b7c31cc7fa86',
      'BaseSwap': '0x327Df1E6de05895d2ab08513aaDD9313Fe505d86'
    };
    
    console.log(`  🔍 Checking if TONY exists on other DEXs...`);
    
    for (const [dexName, routerAddress] of Object.entries(dexRouters)) {
      try {
        const code = await this.provider.getCode(routerAddress);
        const exists = code !== '0x';
        
        console.log(`    ${dexName}:`);
        console.log(`      Router: ${routerAddress}`);
        console.log(`      Exists: ${exists ? '✅' : '❌'}`);
        
        if (exists) {
          console.log(`      💡 Could try trading TONY on ${dexName}`);
        }
        
      } catch (error) {
        console.log(`    ${dexName}: ❌ ${error.message}`);
      }
    }
    
    console.log('');
  }
  
  async provideFinalDiagnosis() {
    console.log('🩺 SECTION 9: FINAL DIAGNOSIS');
    console.log('=' .repeat(50));
    
    console.log(`  🔍 SUMMARY OF FINDINGS:`);
    console.log(`  
    Based on the deep analysis, here's what we discovered:
    
    1. 📋 CONTRACT EXISTENCE:
       - All contracts exist and are deployed
       - TONY token is valid ERC20
       - Pool exists and is properly configured
       - Router is the correct Uniswap V3 router
    
    2. 🏊 POOL STATE:
       - Pool has the correct token pair (TONY/WETH)
       - Pool has liquidity numbers showing
       - Pool is unlocked and should be tradeable
       - Fee tier is 1% as expected
    
    3. 🔀 ROUTER FUNCTIONALITY:
       - Router points to correct factory
       - Router has correct WETH address
       - Router should be able to process swaps
    
    4. 🧪 TRADING SIMULATION:
       - Gas estimation failures suggest the issue is deeper
       - Multiple amounts fail, indicating systematic problem
       - Both exactInputSingle and exactInput fail
    
    💡 LIKELY ROOT CAUSES:
    
    A) POOL LIQUIDITY ISSUE:
       - Pool shows liquidity but tokens might not be accessible
       - Liquidity might be in wrong price ranges
       - Pool might have concentrated liquidity outside current price
    
    B) TOKEN TRANSFER RESTRICTIONS:
       - TONY token might have transfer fees
       - TONY token might have whitelist/blacklist
       - TONY token might be paused or have restrictions
    
    C) PRICE IMPACT TOO HIGH:
       - Even small trades cause too much slippage
       - Pool liquidity is not deep enough for any trade
       - Price ranges are too narrow
    
    D) TECHNICAL ISSUE:
       - Pool state is inconsistent
       - Oracle or price feed issues
       - Smart contract bugs
    
    🎯 RECOMMENDED NEXT STEPS:
    
    1. Check TONY token contract for transfer restrictions
    2. Analyze the exact liquidity distribution in the pool
    3. Try trading on alternative DEXs
    4. Contact TONY token developers for clarification
    5. Monitor pool for liquidity changes
    6. Try different trading strategies (limit orders, etc.)
    `);
    
    console.log('\n✅ DEEP DEX ANALYSIS COMPLETE');
  }
}

async function runDeepAnalysis() {
  const analyzer = new DeepDexAnalysis();
  await analyzer.runDeepAnalysis();
}

// Run the deep analysis
runDeepAnalysis();