/**
 * Test Bot Startup - Check for initialization errors
 */

console.log('🔍 Testing bot startup...');

try {
  console.log('1️⃣ Loading TelegramBot...');
  const TelegramBot = require('node-telegram-bot-api');
  console.log('✅ TelegramBot loaded');

  console.log('2️⃣ Loading environment...');
  require('dotenv').config();
  console.log('✅ Environment loaded');

  console.log('3️⃣ Checking bot token...');
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error('❌ TELEGRAM_BOT_TOKEN not found in environment');
    process.exit(1);
  }
  console.log('✅ Bot token found');

  console.log('4️⃣ Loading database...');
  const WalletDBManager = require('./database/wallet-db-manager');
  console.log('✅ Database manager loaded');

  console.log('5️⃣ Loading chain manager...');
  const ChainManager = require('./chains/chain-manager');
  console.log('✅ Chain manager loaded');

  console.log('6️⃣ Loading callbacks...');
  const Callbacks = require('./callbacks/callbacks');
  console.log('✅ Callbacks loaded');

  console.log('7️⃣ Loading auth...');
  const Auth = require('./auth/auth');
  console.log('✅ Auth loaded');

  console.log('8️⃣ Creating bot instance...');
  const bot = new TelegramBot(token, { polling: true });
  console.log('✅ Bot instance created');

  console.log('9️⃣ Initializing components...');
  const walletManager = new WalletDBManager();
  const chainManager = new ChainManager();
  const auth = new Auth();
  console.log('✅ Components created');

  console.log('🔟 Initializing database...');
  walletManager.initialize().then(() => {
    console.log('✅ Database initialized');
    console.log('🎉 All components loaded successfully!');
    console.log('🤖 Bot should be able to start now');
    process.exit(0);
  }).catch(error => {
    console.error('❌ Database initialization failed:', error.message);
    process.exit(1);
  });

} catch (error) {
  console.error('❌ Startup error:', error.message);
  console.error('❌ Stack:', error.stack);
  process.exit(1);
}