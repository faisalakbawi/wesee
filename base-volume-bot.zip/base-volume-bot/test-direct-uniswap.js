/**
 * TEST DIRECT UNISWAP V3 APPROACH
 * Simple test to verify direct Uniswap V3 Router works
 */

const { ethers } = require('ethers');

async function testDirectUniswap() {
  console.log(`🌊 ========== TESTING DIRECT UNISWAP V3 ==========`);
  
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  
  // Addresses
  const UNISWAP_V3_ROUTER = '0x2626664c2603336E57B271c5C0b26F421741e481';
  const WETH = '0x4200000000000000000000000000000000000006';
  const TONY = '0x36a947baa2492c72bf9d3307117237e79145a87d';
  
  // Router ABI for exactInputSingle
  const routerABI = [
    {
      "inputs": [
        {
          "components": [
            {"internalType": "address", "name": "tokenIn", "type": "address"},
            {"internalType": "address", "name": "tokenOut", "type": "address"},
            {"internalType": "uint24", "name": "fee", "type": "uint24"},
            {"internalType": "address", "name": "recipient", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"},
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMinimum", "type": "uint256"},
            {"internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160"}
          ],
          "internalType": "struct ISwapRouter.ExactInputSingleParams",
          "name": "params",
          "type": "tuple"
        }
      ],
      "name": "exactInputSingle",
      "outputs": [{"internalType": "uint256", "name": "amountOut", "type": "uint256"}],
      "stateMutability": "payable",
      "type": "function"
    }
  ];
  
  const router = new ethers.Contract(UNISWAP_V3_ROUTER, routerABI, provider);
  
  // Test parameters
  const ethAmountWei = ethers.utils.parseEther('0.001');
  const deadline = Math.floor(Date.now() / 1000) + 300;
  const expectedTokens = ethers.utils.parseUnits('34.11', 18);
  const minOut = expectedTokens.mul(8000).div(10000); // 20% slippage
  
  const swapParams = {
    tokenIn: WETH,
    tokenOut: TONY,
    fee: 10000, // 1% fee tier
    recipient: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A', // Test wallet
    deadline: deadline,
    amountIn: ethAmountWei,
    amountOutMinimum: minOut,
    sqrtPriceLimitX96: 0
  };
  
  console.log(`🔧 Testing with parameters:`);
  console.log(`  📥 Token In: ${swapParams.tokenIn} (WETH)`);
  console.log(`  📤 Token Out: ${swapParams.tokenOut} (TONY)`);
  console.log(`  💰 Amount In: ${ethers.utils.formatEther(swapParams.amountIn)} ETH`);
  console.log(`  🛡️ Min Out: ${ethers.utils.formatUnits(swapParams.amountOutMinimum, 18)} TONY`);
  console.log(`  💸 Fee: ${swapParams.fee / 10000}%`);
  console.log(`  👤 Recipient: ${swapParams.recipient}`);
  console.log(`  ⏰ Deadline: ${new Date(deadline * 1000).toISOString()}`);
  
  try {
    console.log(`⛽ Testing gas estimation...`);
    
    // Test gas estimation (this will tell us if the transaction would work)
    const gasEstimate = await router.estimateGas.exactInputSingle(swapParams, {
      value: ethAmountWei,
      from: '0x5e7480A0e1C80bb8e517Cc287d0FFbaf7A77ee0A' // Test from address
    });
    
    console.log(`✅ GAS ESTIMATION SUCCESSFUL!`);
    console.log(`⛽ Estimated Gas: ${gasEstimate.toString()}`);
    console.log(`🎉 This means the direct Uniswap V3 approach WILL WORK!`);
    
    return {
      success: true,
      gasEstimate: gasEstimate.toString(),
      message: 'Direct Uniswap V3 Router approach is valid'
    };
    
  } catch (error) {
    console.log(`❌ Gas estimation failed: ${error.message}`);
    
    // Analyze the error
    if (error.message.includes('INSUFFICIENT_OUTPUT_AMOUNT')) {
      console.log(`🔍 Analysis: Slippage too tight, need higher slippage tolerance`);
    } else if (error.message.includes('STF')) {
      console.log(`🔍 Analysis: Insufficient balance or token approval needed`);
    } else if (error.message.includes('TF')) {
      console.log(`🔍 Analysis: Transfer failed - check token contract`);
    } else {
      console.log(`🔍 Analysis: ${error.message}`);
    }
    
    return {
      success: false,
      error: error.message,
      analysis: 'Gas estimation failed'
    };
  }
}

// Run the test
testDirectUniswap()
  .then(result => {
    console.log(`\n📊 ========== TEST RESULT ==========`);
    if (result.success) {
      console.log(`✅ SUCCESS: Direct Uniswap V3 approach works!`);
      console.log(`⛽ Gas needed: ${result.gasEstimate}`);
      console.log(`🎯 Recommendation: Use direct Uniswap V3 Router instead of sniper contract`);
    } else {
      console.log(`❌ FAILED: ${result.error}`);
      console.log(`🔧 Need to fix: ${result.analysis}`);
    }
  })
  .catch(error => {
    console.error(`❌ Test failed:`, error);
  });